import json
import sqlite3
from types import SimpleNamespace

import pandas as pd
import pytest

from agents.journal_agent import JournalAgent
from core.llm import apply_verdict, parse_verdict, review
from core.models import AgentReport, TradePlan
from tests.conftest import make_candles

T0 = pd.Timestamp("2026-01-05 10:00", tz="UTC")


def mk_plan(side="LONG", entry_type="MARKET", entry=100.0, stop=99.0, tp1=102.0, tp2=104.0, size=10.0, risk=10.0):
    return TradePlan(side=side, ts=T0.isoformat(), price=entry, atr=1.0, entry_type=entry_type, entry=entry,
                     stop=stop, tp1=tp1, tp2=tp2, rr=2.0, size=size, risk_usd=risk, approved=True)


def paper_journal(cfg):
    cfg["journal"]["paper_mode"] = True
    return JournalAgent(cfg, ":memory:")


def settle_all(j, rows):
    df = make_candles(rows, start="2026-01-05 10:00")
    return j.settle(df, 15, df.index[-1] + pd.Timedelta(minutes=15))


# ---------------------------------------------------------------- paper trading
def test_paper_trade_runs_to_tp2_and_is_booked(cfg):
    j = paper_journal(cfg)
    tid = j.record_signal(mk_plan(), {})
    assert j.get(tid)["status"] == "open"
    done = settle_all(j, [(100, 100.5, 99.5, 100.2), (100.2, 102.5, 100.1, 102.0), (102, 104.5, 101.5, 104.0)])
    t = j.get(tid)
    assert done and t["status"] == "closed" and t["r_mult"] == pytest.approx(3.0)
    assert t["notes"] == "paper: TP2" and t["pnl_usd"] == pytest.approx(30.0)
    s = j.stats()
    assert s["trades"] == 1 and s["win_rate"] == 1.0 and s["total_pnl"] == pytest.approx(30.0)


def test_settle_is_idempotent_and_incremental(cfg):
    j = paper_journal(cfg)
    tid = j.record_signal(mk_plan(), {})
    df = make_candles([(100, 100.5, 99.5, 100.2), (100.2, 100.8, 99.6, 100.4), (100.4, 102.5, 100.2, 102.0)],
                      start="2026-01-05 10:00")
    j.settle(df.iloc[:2], 15, df.index[1] + pd.Timedelta(minutes=15))
    assert j.get(tid)["status"] == "open"
    j.settle(df.iloc[:2], 15, df.index[1] + pd.Timedelta(minutes=15))     # same data again: nothing changes
    sim = json.loads(j.get(tid)["sim"])
    assert sim["age"] == 2
    j.settle(df, 15, df.index[2] + pd.Timedelta(minutes=15))
    assert json.loads(j.get(tid)["sim"])["tp1_hit"] is True


def test_only_closed_candles_are_used(cfg):
    j = paper_journal(cfg)
    tid = j.record_signal(mk_plan(), {})
    df = make_candles([(100, 100.5, 98.0, 98.5)], start="2026-01-05 10:00")      # would stop the trade...
    j.settle(df, 15, T0 + pd.Timedelta(minutes=5))                               # ...but is still forming
    assert j.get(tid)["status"] == "open"


def test_candle_before_the_decision_is_ignored(cfg):
    j = paper_journal(cfg)
    tid = j.record_signal(mk_plan(), {})
    df = make_candles([(100, 100.5, 95.0, 96.0)], start="2026-01-05 09:45")      # opened BEFORE the decision
    j.settle(df, 15, T0 + pd.Timedelta(hours=1))
    assert j.get(tid)["status"] == "open"


def test_limit_order_pending_then_filled(cfg):
    j = paper_journal(cfg)
    tid = j.record_signal(mk_plan(entry_type="LIMIT", entry=100.0), {})
    assert j.get(tid)["status"] == "pending"
    settle_all(j, [(101, 101.5, 100.6, 101.0)])
    assert j.get(tid)["status"] == "pending"
    settle_all(j, [(101, 101.5, 100.6, 101.0), (101, 101.2, 99.8, 100.4)])
    assert j.get(tid)["status"] == "open" and j.get(tid)["taken_ts"]


def test_risk_state_counts_active_and_daily_results(cfg):
    j = paper_journal(cfg)
    j.record_signal(mk_plan(), {})
    assert j.risk_state(T0).open_trades == 1 and j.risk_state(T0).trades_today == 1
    settle_all(j, [(100, 100.5, 98.5, 99.0)])                  # stopped out: -$10
    st = j.risk_state(T0 + pd.Timedelta(hours=1))
    assert st.open_trades == 0 and st.daily_pnl == pytest.approx(-10) and st.loss_streak == 1
    assert j.risk_state(T0 + pd.Timedelta(days=1)).daily_pnl == 0


# ---------------------------------------------------------------- manual journaling
def test_manual_flow_take_close(cfg):
    cfg["journal"]["paper_mode"] = False
    j = JournalAgent(cfg, ":memory:")
    tid = j.record_signal(mk_plan(), {})
    assert j.get(tid)["status"] == "signal" and j.risk_state(T0).open_trades == 0
    j.take(tid, T0)
    assert j.risk_state(T0).open_trades == 1
    closed = j.close(tid, 101.0, T0 + pd.Timedelta(hours=1))
    assert closed["pnl_usd"] == pytest.approx(10.0) and closed["r_mult"] == pytest.approx(1.0)
    with pytest.raises(ValueError):
        j.close(tid, 101.0)


def test_skip_and_recent_signal_dedupe(cfg):
    cfg["journal"]["paper_mode"] = False
    j = JournalAgent(cfg, ":memory:")
    tid = j.record_signal(mk_plan(), {})
    assert j.recent_signal("LONG", 60, T0 + pd.Timedelta(minutes=30))
    assert not j.recent_signal("SHORT", 60, T0 + pd.Timedelta(minutes=30))
    assert not j.recent_signal("LONG", 60, T0 + pd.Timedelta(hours=3))
    j.skip(tid)
    assert j.get(tid)["status"] == "skipped"


def test_old_database_without_sim_column_is_migrated(tmp_path, cfg):
    path = str(tmp_path / "old.db")
    db = sqlite3.connect(path)
    db.execute("CREATE TABLE trades(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, side TEXT, entry_type TEXT, "
               "entry REAL, stop REAL, tp1 REAL, tp2 REAL, size REAL, risk_usd REAL, rr REAL, score REAL, "
               "confidence REAL, status TEXT, taken_ts TEXT, exit_ts TEXT, exit_price REAL, pnl_usd REAL, "
               "r_mult REAL, reports TEXT, notes TEXT)")
    db.commit()
    db.close()
    j = JournalAgent(cfg, path)
    assert j.stats()["trades"] == 0
    j.record_signal(mk_plan(), {})


# ---------------------------------------------------------------- Claude reviewer: veto-only
def reports():
    return {"liquidity": AgentReport("liquidity", 0.5, 0.6, "sweep")}


def test_parse_verdict_is_strict():
    assert parse_verdict('{"verdict": "reject", "reasons": ["too close"]}')["verdict"] == "reject"
    assert parse_verdict('Sure! {"verdict": "approve", "reasons": []} done')["verdict"] == "approve"
    assert parse_verdict('{"verdict": "buy more!"}') is None
    assert parse_verdict("no json here") is None
    assert parse_verdict("") is None


def test_reject_blocks_the_plan(cfg):
    p = apply_verdict(mk_plan(), {"verdict": "reject", "reasons": ["weak"]}, cfg)
    assert not p.approved and any("AI reviewer" in v for v in p.vetoes)


def test_reduce_halves_and_never_enlarges(cfg):
    p = mk_plan(size=10.0, risk=100.0)
    apply_verdict(p, {"verdict": "reduce", "reasons": ["doubt"]}, cfg)
    assert p.size == pytest.approx(5.0) and p.risk_usd == pytest.approx(50.0) and p.approved
    q = mk_plan(size=10.0, risk=100.0)
    apply_verdict(q, {"verdict": "approve", "reasons": []}, cfg)
    assert q.size == 10.0 and q.risk_usd == 100.0


def fake_client(text):
    msg = SimpleNamespace(content=[SimpleNamespace(text=text)])
    return SimpleNamespace(messages=SimpleNamespace(create=lambda **kw: msg))


def test_review_with_fake_client(cfg):
    p = mk_plan()
    v = review(p, reports(), cfg, client=fake_client('{"verdict": "reject", "reasons": ["stop in a pool"]}'))
    assert v["verdict"] == "reject" and not p.approved


def test_review_ignores_garbage_and_errors_and_unapproved_plans(cfg):
    p = mk_plan()
    assert review(p, reports(), cfg, client=fake_client("I think you should go all in")) is None and p.approved
    boom = SimpleNamespace(messages=SimpleNamespace(create=lambda **kw: (_ for _ in ()).throw(RuntimeError("x"))))
    assert review(mk_plan(), reports(), cfg, client=boom) is None
    blocked = mk_plan()
    blocked.approved = False
    assert review(blocked, reports(), cfg, client=fake_client('{"verdict": "approve"}')) is None


def test_llm_is_off_without_key_or_flag(cfg, monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    cfg["llm"]["review"] = True
    assert review(mk_plan(), reports(), cfg) is None
