import time

import pandas as pd
import pytest

from agents.options_agent import OptionsAgent
from core import deribit, options as ox
from core.models import AgentReport, MarketSnapshot
from tests.conftest import make_candles

NOW = int(time.time() * 1000)
H = 3_600_000
S = 2400.0


def snap(price=S, source="test"):
    df = make_candles([(price, price + 1, price - 1, price)] * 30)
    return MarketSnapshot("ETHUSDT", price, {"15m": df}, None, None, None, source, pd.Timestamp.now(tz="UTC"))


def chain(hours=24, strikes=range(2000, 2900, 100), call_oi=None, put_oi=None, iv=0.6, put_iv=None):
    """One expiry. call_oi / put_oi: dict strike -> OI in ETH (default: nothing)."""
    out = []
    for k in strikes:
        for kind, oi_map, v in (("C", call_oi or {}, iv), ("P", put_oi or {}, put_iv or iv)):
            out.append({"expiry_ms": NOW + int(hours * H), "strike": float(k), "kind": kind, "oi": float(oi_map.get(k, 0.0)), "iv": v, "spot": S})
    return out


def agent(cfg, opts=None, error=None):
    return OptionsAgent(cfg, fetch=lambda: {"options": opts or [], "error": error})


# ---------- parsing and maths ----------
def test_parse_rows_reads_deribit_names_and_drops_junk():
    rows = [{"instrument_name": "ETH-29NOV26-3000-C", "open_interest": 120.5, "mark_iv": 62.5, "underlying_price": 2400.0},
            {"instrument_name": "ETH-6DEC26-2500-P", "open_interest": 10, "mark_iv": 55, "underlying_price": 2400.0},
            {"instrument_name": "ETH-PERPETUAL", "open_interest": 1, "mark_iv": 1, "underlying_price": 1},
            {"instrument_name": "ETH-29NOV26-3000-C", "open_interest": 1}]            # no underlying price
    o = ox.parse_rows(rows)
    assert len(o) == 2 and o[0]["kind"] == "C" and o[0]["strike"] == 3000 and o[0]["iv"] == pytest.approx(0.625)
    assert o[1]["kind"] == "P" and o[1]["oi"] == 10


def test_max_pain_is_the_strike_where_holders_lose_most():
    opts = chain(strikes=[2300, 2400, 2500], call_oi={2300: 50, 2400: 200, 2500: 50}, put_oi={2300: 50, 2400: 200, 2500: 50})
    assert ox.max_pain(opts) == 2400
    skew = chain(strikes=[2300, 2400, 2500], call_oi={2300: 100}, put_oi={2300: 1})
    assert ox.max_pain(skew) == 2300


def test_gamma_is_highest_at_the_money_and_delta_is_sane():
    T = 7 / 365
    assert ox.gamma(2400, 2400, T, 0.6) > ox.gamma(2400, 3000, T, 0.6) > 0
    assert ox.delta(2400, 2400, T, 0.6, "C") == pytest.approx(0.5, abs=0.06)
    assert ox.delta(2400, 2400, T, 0.6, "P") == pytest.approx(-0.5, abs=0.06)


def test_calls_make_gamma_positive_and_puts_negative():
    assert sum(ox.gex_at(chain(call_oi={2500: 500}), S, NOW).values()) > 0
    assert sum(ox.gex_at(chain(put_oi={2300: 500}), S, NOW).values()) < 0


def test_gamma_flip_found_between_put_and_call_clusters():
    opts = chain(hours=72, call_oi={2600: 800}, put_oi={2200: 800})
    flip = ox.gamma_flip(opts, S, NOW)
    assert flip is not None and 2200 < flip < 2600


def test_risk_reversal_is_negative_when_puts_are_richer():
    opts = chain(hours=24 * 20, strikes=range(1600, 3400, 100))
    flat = ox.risk_reversal(opts, S, NOW)
    assert flat and abs(flat["rr25"]) < 1.0
    rich = []
    for o in opts:
        rich.append({**o, "iv": o["iv"] + (0.10 if o["kind"] == "P" else 0.0)})
    assert ox.risk_reversal(rich, S, NOW)["rr25"] < -5


# ---------- agent ----------
BIG = {k: 20000 for k in range(2000, 2900, 100)}      # lots of OI everywhere so the expiry counts


def test_max_pain_above_price_pulls_long_and_below_pulls_short(cfg):
    up = agent(cfg, chain(hours=20, call_oi={2400: 5000, 2700: 8000}, put_oi={2700: 20000})).analyze(snap())
    dn = agent(cfg, chain(hours=20, call_oi={2100: 20000}, put_oi={2100: 5000, 2400: 8000})).analyze(snap())
    assert up.details["max_pain"] > S and up.bias > 0
    assert dn.details["max_pain"] < S and dn.bias < 0
    assert not up.details.get("no_data") and "max pain" in up.summary


def test_pull_is_ignored_for_tiny_open_interest_or_far_expiries(cfg):
    tiny = agent(cfg, chain(hours=20, call_oi={2700: 5}, put_oi={2700: 5})).analyze(snap())
    far = agent(cfg, chain(hours=24 * 20, call_oi={2700: 20000}, put_oi={2700: 20000})).analyze(snap())
    assert tiny.details["components"]["pull"] == 0 and far.details["components"]["pull"] == 0


def test_call_wall_just_above_price_leans_short_and_put_wall_below_leans_long(cfg):
    cw = agent(cfg, chain(hours=24 * 20, call_oi={2440: 30000}, strikes=[2200, 2300, 2440, 2600])).analyze(snap())
    pw = agent(cfg, chain(hours=24 * 20, put_oi={2360: 30000}, strikes=[2200, 2360, 2500, 2600])).analyze(snap())
    assert cw.details["call_wall"] == 2440 and cw.details["components"]["walls"] < 0
    assert pw.details["put_wall"] == 2360 and pw.details["components"]["walls"] > 0


def test_negative_gamma_weakens_the_max_pain_pull(cfg):
    pos = agent(cfg, chain(hours=20, call_oi={2700: 20000, 2800: 20000}, put_oi={2700: 100})).analyze(snap())
    neg = agent(cfg, chain(hours=20, call_oi={2700: 20000}, put_oi={2700: 100, 2300: 50000})).analyze(snap())
    assert pos.details["gamma_positive"] and not neg.details["gamma_positive"]
    assert pos.details["components"]["pull"] > 0 and neg.details["components"]["pull"] > 0
    for r, k in ((pos, 1.0), (neg, 0.7)):             # negative gamma: the pull is multiplied by 0.7 before it enters the bias
        c = r.details["components"]
        assert r.bias == pytest.approx(max(-1, min(1, 0.5 * c["pull"] * k + 0.3 * c["walls"] + 0.2 * c["sentiment"])), abs=1e-3)


def test_crowded_puts_lean_long_at_the_extreme_only(cfg):
    base = chain(hours=24 * 20, strikes=range(1600, 3400, 100))
    rich = [{**o, "iv": o["iv"] + (0.10 if o["kind"] == "P" else 0.0), "oi": 100.0} for o in base]
    calm = [{**o, "oi": 100.0} for o in base]
    assert agent(cfg, rich).analyze(snap()).details["components"]["sentiment"] > 0
    assert agent(cfg, calm).analyze(snap()).details["risk_reversal"]["rr25"] == pytest.approx(0, abs=1.0)


def test_demo_stale_errors_and_switch_are_left_out(cfg):
    ok = chain(hours=20, call_oi={2700: 20000})
    assert agent(cfg, ok).analyze(snap(source="synthetic-demo")).details["no_data"]
    old = snap()
    old = MarketSnapshot(old.symbol, old.price, old.candles, None, None, None, "test", pd.Timestamp.now(tz="UTC") - pd.Timedelta(days=2))
    assert agent(cfg, ok).analyze(old).details["no_data"]
    r = agent(cfg, error={"kind": "network", "msg": "could not reach Deribit"}).analyze(snap())
    assert r.details["no_data"] and "Deribit" in r.summary and r.bias == 0 and r.confidence == 0
    cfg2 = {**cfg, "options": {**(cfg.get("options") or {}), "enabled": False}}
    assert OptionsAgent(cfg2, fetch=lambda: {"options": ok, "error": None}).analyze(snap()).details["no_data"]


def test_confidence_stays_modest(cfg):
    r = agent(cfg, chain(hours=2, call_oi={2700: 90000}, put_oi={2700: 90000})).analyze(snap())
    assert 0 <= r.confidence <= 0.5 and -1 <= r.bias <= 1


# ---------- client ----------
def test_client_caches_and_reports_errors():
    deribit.clear_cache()
    calls = []

    def ok():
        calls.append(1)
        return [{"instrument_name": "ETH-29NOV27-3000-C", "open_interest": 5, "mark_iv": 60, "underlying_price": 2400}]

    cfg = {"options": {"currency": "ETH", "cache_seconds": 300}}
    a = deribit.options(cfg, now=1000.0, fetch=lambda cur: ok())
    b = deribit.options(cfg, now=1100.0, fetch=lambda cur: ok())
    assert a["error"] is None and len(a["options"]) == 1 and len(calls) == 1 and b is a
    deribit.clear_cache()

    def boom(cur):
        raise deribit.DeribitError("network", "could not reach Deribit (ConnectionError)")

    e = deribit.options(cfg, now=2000.0, fetch=boom)
    assert e["options"] == [] and e["error"]["kind"] == "network"
    deribit.clear_cache()
    empty = deribit.options(cfg, now=3000.0, fetch=lambda cur: [{"instrument_name": "ETH-PERPETUAL"}])
    assert empty["error"]["kind"] == "format"
    deribit.clear_cache()


def test_chart_draws_max_pain_and_gamma_walls(cfg):
    from core.charts import build_chart
    from tests.test_system import system
    s = system(cfg, 4)
    full = s.data.snapshot(limit=700)
    snap, reports, plan = s.replay(full, full.candles["15m"].index[-40] + pd.Timedelta(minutes=15))
    p = snap.price
    reports["options"] = AgentReport("options", 0.1, 0.3, "x", {"max_pain": p * 1.004, "call_wall": p * 1.006, "put_wall": p * 0.994,
                                                               "gamma_flip": p * 0.99})
    fig = build_chart(snap, reports, plan, "15m", "Africa/Algiers")
    text = " ".join(a.text or "" for a in fig.layout.annotations)
    assert "max pain" in text and "call wall" in text and "put wall" in text
