import numpy as np
import pytest

from agents.pattern_agent import PatternAgent
from core.indicators import atr
from core.patterns import find_patterns
from tests.conftest import make_candles, make_snap


def path(points, per=12, pad=40):
    """Piecewise-linear closes through the waypoints, with a flat run-up so the ATR is stable."""
    closes = list(np.linspace(points[0] - 4, points[0], pad, endpoint=False)) + [points[0]]   # a ramp: no accidental pivots
    for a, b in zip(points[:-1], points[1:]):
        closes += list(np.linspace(a, b, per + 1)[1:])
    return make_candles([(c, c + 0.25, c - 0.25, c) for c in closes])


def found(df, k=3, max_age=14):
    return find_patterns(df, float(atr(df).iloc[-1]), k, max_age, "15m")


def names(df, **kw):
    return {(p["name"], p["status"]) for p in found(df, **kw)}


def converge(u0, u1, l0, l1, legs=6, per=10):
    """Zig-zag whose highs lie on one straight line and lows on another."""
    n = legs * per
    up = lambda t: u0 + (u1 - u0) * t / n
    lo = lambda t: l0 + (l1 - l0) * t / n
    pts, t = [lo(0)], 0
    for j in range(1, legs + 1):
        t = j * per
        pts.append(up(t) if j % 2 else lo(t))
    return pts, up, lo


# ---------------------------------------------------------------- tops and bottoms
def test_double_top_broken_and_forming():
    assert ("double top", "broken") in names(path([100, 110, 103, 110.2, 95]))
    assert ("double top", "forming") in names(path([100, 110, 103, 110.2, 104]))


def test_double_bottom_is_the_mirror():
    ps = found(path([110, 100, 107, 99.8, 118]))
    p = next(p for p in ps if p["name"] == "double bottom")
    assert p["dir"] == 1 and p["status"] == "broken" and p["target"] > p["break_level"] > p["stop_ref"]


def test_double_top_needs_two_similar_peaks():
    assert not [p for p in found(path([100, 110, 103, 114, 95])) if p["name"] == "double top"]


def test_head_and_shoulders_and_inverse():
    p = next(p for p in found(path([100, 108, 103, 115, 103.2, 108.3, 95])) if p["name"] == "head and shoulders")
    assert p["dir"] == -1 and p["status"] == "broken" and p["target"] < p["break_level"] < p["stop_ref"]
    q = next(p for p in found(path([115, 107, 112, 100, 112.2, 107.1, 125])) if p["name"] == "inverse head and shoulders")
    assert q["dir"] == 1 and q["target"] > q["break_level"] > q["stop_ref"]


def test_a_pattern_broken_long_ago_is_not_reported():
    df = path([100, 110, 103, 110.2, 95, 94, 93, 92, 91])
    assert not [p for p in found(df, max_age=6) if p["name"] == "double top"]


# ---------------------------------------------------------------- flags
def test_bull_and_bear_flags():
    closes = [100] * 40 + list(np.linspace(100, 120, 16)) + [119, 118, 117.5, 117, 116.8, 117.2, 116.9, 117.5, 117.1, 117.3] + [121.0, 122]
    df = make_candles([(c, c + 0.3, c - 0.3, c) for c in closes])
    p = next(p for p in found(df, max_age=6) if p["name"] == "bull flag")
    assert p["dir"] == 1 and p["status"] == "broken" and p["target"] > 130
    closes = [100] * 40 + list(np.linspace(100, 80, 16)) + [81, 82, 82.5, 83, 83.2, 82.8, 83.1, 82.5, 82.9, 82.7] + [79, 78]
    df = make_candles([(c, c + 0.3, c - 0.3, c) for c in closes])
    p = next(p for p in found(df, max_age=6) if p["name"] == "bear flag")
    assert p["dir"] == -1 and p["target"] < 70


# ---------------------------------------------------------------- triangles and wedges
@pytest.mark.parametrize("u0,u1,l0,l1,name,leg_to", [
    (110, 110, 100, 108, "ascending triangle", 126),
    (110, 102, 100, 100, "descending triangle", 84),
    (112, 106, 100, 104, "symmetrical triangle", 120),
    (112, 118, 100, 114, "rising wedge", 96),
    (120, 108, 112, 104, "falling wedge", 128),
])
def test_triangles_and_wedges_break(u0, u1, l0, l1, name, leg_to):
    pts, up, lo = converge(u0, u1, l0, l1, legs=7)
    df = path(pts + [leg_to], per=10)
    ps = [p for p in found(df, max_age=14) if p["name"] == name]
    assert ps, f"{name} not found: {names(df)}"
    p = ps[0]
    assert p["status"] == "broken" and p["dir"] == (1 if leg_to > pts[-1] else -1)
    assert p["target"] is not None and (p["target"] - p["break_level"]) * p["dir"] > 0


def test_forming_triangle_leans_its_usual_way():
    pts, up, lo = converge(110, 110, 100, 108, legs=7)
    df = path(pts + [pts[-1] - 0.5], per=10)          # touched the top line again, still inside: not broken
    p = [p for p in found(df) if p["name"] == "ascending triangle"]
    assert p and p[0]["status"] == "forming" and p[0]["dir"] == 1


def test_random_walk_rarely_produces_patterns():
    hits = 0
    for seed in range(10):
        c = 100 + np.cumsum(np.random.default_rng(seed).normal(0, 0.5, 600))
        df = make_candles([(x, x + 0.4, x - 0.4, x) for x in c])
        for end in range(300, 600, 15):
            sub = df.iloc[:end]
            hits += any(p["status"] == "broken" for p in found(sub, k=4, max_age=6))
    assert hits <= 0.25 * 10 * 20          # <25% of random windows (and in practice far fewer)


def test_no_lookahead_future_candles_do_not_change_past_patterns():
    df = path([100, 110, 103, 110.2, 95])
    cut = df.iloc[:-8]
    again = find_patterns(cut, float(atr(cut).iloc[-1]), 3, 14, "15m")
    full = find_patterns(df, float(atr(df).iloc[-1]), 3, 14, "15m")
    assert all(p["status"] == "forming" for p in again if p["name"] == "double top")
    assert any(p["status"] == "broken" for p in full if p["name"] == "double top")


# ---------------------------------------------------------------- agent
def test_agent_bias_follows_the_break(cfg):
    df = path([100, 110, 103, 110.2, 95], per=12)
    r = PatternAgent(cfg).analyze(make_snap(df))
    assert r.bias < -0.3 and r.details["breakout"]["name"] == "double top"
    up = path([110, 100, 107, 99.8, 118])
    assert PatternAgent(cfg).analyze(make_snap(up)).bias > 0.3


def test_agent_without_patterns_stays_out_of_the_score(cfg):
    df = make_candles([(100, 100.3, 99.7, 100)] * 400)
    r = PatternAgent(cfg).analyze(make_snap(df))
    assert r.details["no_data"] and r.bias == 0
