import pandas as pd

from agents.orderbook_agent import OrderBookAgent
from core.levels import load_walls, parse_walls, save_walls_text
from core.models import MarketSnapshot
from tests.conftest import make_candles


def snap_at(price=2400.0, book=None, ts=None):
    df = make_candles([(price, price + 1, price - 1, price)] * 30)
    ts = ts or pd.Timestamp.now(tz="UTC")
    return MarketSnapshot("ETHUSDT", price, {"15m": df}, None, None, None, "test", ts, book)


def book(bid_qty=100.0, ask_qty=100.0, wall=None, price=2400.0):
    """Even ladder every 0.1 USD for 500 levels each side; optional extra wall {'side','price','qty'}."""
    bids = [[price - 0.05 - 0.1 * i, bid_qty / 50] for i in range(500)]
    asks = [[price + 0.05 + 0.1 * i, ask_qty / 50] for i in range(500)]
    if wall:
        (bids if wall["side"] == "bid" else asks).append([wall["price"], wall["qty"]])
    return {"bids": bids, "asks": asks}


def test_balanced_book_is_neutral(cfg):
    rep = OrderBookAgent(cfg).analyze(snap_at(book=book()))
    assert abs(rep.bias) < 0.05 and not rep.details.get("no_data")


def test_bid_heavy_book_leans_long_and_ask_heavy_short(cfg):
    assert OrderBookAgent(cfg).analyze(snap_at(book=book(bid_qty=300))).bias > 0.2
    assert OrderBookAgent(cfg).analyze(snap_at(book=book(ask_qty=300))).bias < -0.2


def test_live_wall_is_found_with_its_side_and_size(cfg):
    b = book(wall={"side": "ask", "price": 2402.0, "qty": 800.0})       # ~ $1.9M
    rep = OrderBookAgent(cfg).analyze(snap_at(book=b))
    w = [x for x in rep.details["walls"] if x["source"] == "live"]
    assert w and w[0]["side"] == "ask" and abs(w[0]["price"] - 2402.0) <= 0.5 and w[0]["usd"] > 1.5e6
    assert rep.bias < 0 and "ask" in rep.summary


def test_no_data_is_flagged_so_the_manager_skips_it(cfg, tmp_path):
    cfg["orderbook"]["walls_file"] = str(tmp_path / "none.txt")
    rep = OrderBookAgent(cfg).analyze(snap_at(book=None))
    assert rep.details["no_data"] and rep.bias == 0 and rep.confidence == 0


def test_manager_leaves_no_data_agents_out_of_the_score(cfg):
    from agents.manager_agent import ManagerAgent
    from agents.risk_agent import RiskAgent
    from core.models import AgentReport, RiskState
    m = ManagerAgent(cfg, RiskAgent(cfg))
    s = snap_at()
    base = {"liquidity": AgentReport("liquidity", 0.5, 0.8, "", {"clusters": [], "atr": 1.0}),
            "structure": AgentReport("structure", 0.5, 0.8, "", {"zones": []})}
    ob = AgentReport("orderbook", 0.0, 0.0, "none", {"no_data": True})
    a = m.decide(s, base, RiskState(), s.ts).score
    b = m.decide(s, {**base, "orderbook": ob}, RiskState(), s.ts).score
    assert a == b


def test_manual_walls_parse_and_infer_side():
    got = parse_walls("# c\n3955 ask 48.5\n2225 bid 20m\n2449.95 12\nbad line\n2500\n")
    assert [(w["price"], w["side"], w["usd"]) for w in got] == [
        (3955.0, "ask", 48.5e6), (2225.0, "bid", 20e6), (2449.95, None, 12e6), (2500.0, None, 10e6)]


def test_manual_wall_near_price_moves_the_bias_far_one_does_not(cfg, tmp_path):
    f = tmp_path / "w.txt"
    cfg["orderbook"]["walls_file"] = str(f)
    f.write_text("2410 ask 30\n")                                    # 0.4% above price: resistance
    near = OrderBookAgent(cfg).analyze(snap_at())
    assert near.bias < -0.1 and "manual wall" in near.summary
    f.write_text("3955 ask 48.5\n")                                  # 65% away: shown, not scored
    far = OrderBookAgent(cfg).analyze(snap_at())
    assert far.details.get("no_data") and far.details["walls"][0]["price"] == 3955.0


def test_manual_walls_are_not_used_when_replaying_the_past(cfg, tmp_path):
    f = tmp_path / "w.txt"
    f.write_text("2410 ask 30\n")
    cfg["orderbook"]["walls_file"] = str(f)
    rep = OrderBookAgent(cfg).analyze(snap_at(ts=pd.Timestamp("2026-01-05 12:00", tz="UTC")))
    assert rep.details.get("no_data")                                # no look-ahead from today's walls


def test_vanishing_walls_lower_confidence(cfg):
    agent = OrderBookAgent(cfg)
    t0 = pd.Timestamp.now(tz="UTC")
    for i in range(3):
        w = {"side": "bid", "price": 2397.0 - i * 0.7, "qty": 800.0}
        agent.analyze(snap_at(book=book(wall=w), ts=t0 + pd.Timedelta(seconds=30 * (2 * i))))
        agent.analyze(snap_at(book=book(), ts=t0 + pd.Timedelta(seconds=30 * (2 * i + 1))))   # wall pulled, price unchanged
    rep = agent.analyze(snap_at(book=book(wall={"side": "bid", "price": 2397.0, "qty": 800.0}), ts=t0 + pd.Timedelta(minutes=10)))
    assert rep.details["pulled"] >= 2 and "suspicion" in rep.summary


def test_save_walls_roundtrip(tmp_path):
    f = tmp_path / "w.txt"
    assert save_walls_text(str(f), "3955 ask 48\nnonsense") == 1
    assert load_walls(str(f))[0]["usd"] == 48e6 and load_walls(str(tmp_path / "x.txt")) == []


def test_coinglass_check_command_reports_plan_limits_without_printing_the_key(monkeypatch, capsys, tmp_path):
    import main

    class R:
        def __init__(self, body): self._b, self.ok, self.status_code, self.text = body, True, 200, ""
        def json(self): return self._b

    def fake_get(url, params=None, headers=None, timeout=None):
        assert headers["CG-API-KEY"] == "SECRETKEY123"
        if "heatmap" in url:
            return R({"code": "40004", "msg": "Upgrade plan", "data": None})
        return R({"code": "0", "msg": "success", "data": [1, 2, 3]})

    monkeypatch.setattr("requests.get", fake_get)
    monkeypatch.setenv("COINGLASS_API_KEY", "SECRETKEY123")
    main.cmd_coinglass(None, {"market": {"symbol": "ETHUSDT"}})
    out = capsys.readouterr().out
    assert "SECRETKEY123" not in out and "does not include" in out and "[OK  ] key check" in out
    monkeypatch.delenv("COINGLASS_API_KEY")
    main.cmd_coinglass(None, {"market": {"symbol": "ETHUSDT"}})
    assert "COINGLASS_API_KEY" in capsys.readouterr().out
