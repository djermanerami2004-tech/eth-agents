import pandas as pd
import pytest

from agents.risk_agent import RiskAgent
from core.models import AgentReport, RiskState, TradePlan

NOW = pd.Timestamp("2026-01-05 10:00", tz="UTC")


def plan(entry=100.0, stop=98.0, atr=2.0, rr=2.0, side="LONG"):
    return TradePlan(side=side, entry=entry, stop=stop, atr=atr, rr=rr, tp1=entry + 2 * (entry - stop),
                     tp2=entry + 3 * (entry - stop))


def test_sizes_to_the_risk_budget(cfg):
    p = RiskAgent(cfg).evaluate(plan(), None, RiskState(), NOW)
    assert p.approved, p.vetoes
    assert p.risk_usd == pytest.approx(100.0, abs=0.5)      # 0.5% of 20,000
    assert p.size == pytest.approx(50.0)


def test_outside_trading_hours_is_vetoed(cfg):
    p = RiskAgent(cfg).evaluate(plan(), None, RiskState(), pd.Timestamp("2026-01-05 03:00", tz="UTC"))
    assert not p.approved and any("Outside allowed trading hours" in v for v in p.vetoes)


def test_daily_loss_limit(cfg):
    p = RiskAgent(cfg).evaluate(plan(), None, RiskState(daily_pnl=-400.0), NOW)   # 2% of 20,000
    assert not p.approved and any("Daily loss limit" in v for v in p.vetoes)


def test_total_drawdown_limit(cfg):
    p = RiskAgent(cfg).evaluate(plan(), None, RiskState(total_pnl=-1000.0), NOW)  # 5% of 20,000
    assert any("Total drawdown" in v for v in p.vetoes)


def test_daily_budget_shrinks_the_size(cfg):
    p = RiskAgent(cfg).evaluate(plan(), None, RiskState(daily_pnl=-350.0), NOW)   # only $50 of budget left
    assert not p.approved or p.risk_usd < 60


def test_max_trades_and_loss_streak_and_open_trade(cfg):
    ra = RiskAgent(cfg)
    assert any("Max trades" in v for v in ra.evaluate(plan(), None, RiskState(trades_today=3), NOW).vetoes)
    assert any("losses in a row" in v for v in ra.evaluate(plan(), None, RiskState(loss_streak=2), NOW).vetoes)
    assert any("already active" in v for v in ra.evaluate(plan(), None, RiskState(open_trades=1), NOW).vetoes)


def test_news_veto_is_respected(cfg):
    news = AgentReport("news", 0, 1, "BLACKOUT: FOMC", veto=True)
    p = RiskAgent(cfg).evaluate(plan(), news, RiskState(), NOW)
    assert not p.approved and any("BLACKOUT" in v for v in p.vetoes)


def test_low_reward_to_risk_and_bad_stops(cfg):
    ra = RiskAgent(cfg)
    assert any("Reward/risk" in v for v in ra.evaluate(plan(rr=1.0), None, RiskState(), NOW).vetoes)
    assert any("too wide" in v for v in ra.evaluate(plan(stop=90.0), None, RiskState(), NOW).vetoes)
    assert any("too tight" in v for v in ra.evaluate(plan(stop=99.9), None, RiskState(), NOW).vetoes)
    assert any("Invalid" in v for v in ra.evaluate(plan(stop=100.0), None, RiskState(), NOW).vetoes)


def test_leverage_cap_reduces_size(cfg):
    # $100 risk with a 3-dollar stop on a $3000 coin = 33 ETH ($100k) -> capped at 2x of $20k = 13.33 ETH
    p = RiskAgent(cfg).evaluate(plan(entry=3000, stop=2997, atr=5.0), None, RiskState(), NOW)
    assert p.size == pytest.approx(13.33, abs=0.01)
    assert p.size * 3000 <= 20000 * 2.0 + 1
    assert p.approved and p.risk_usd == pytest.approx(40.0, abs=0.5)


def test_leverage_cap_skips_trades_that_would_risk_too_little(cfg):
    p = RiskAgent(cfg).evaluate(plan(entry=3000, stop=2998.5, atr=3.0), None, RiskState(), NOW)
    assert not p.approved and any("Leverage cap" in v for v in p.vetoes)


def test_no_side_is_never_approved(cfg):
    p = RiskAgent(cfg).evaluate(plan(side="NONE"), None, RiskState(), NOW)
    assert not p.approved
