import pytest

from core.tradesim import SimParams, SimTrade, advance

P = SimParams(wait_bars=8, max_bars=48, tp1_fraction=0.5, spread_usd=0.0, slippage_usd=0.0)


def long_trade(state="open", **kw):
    d = dict(side="LONG", entry=100.0, stop=99.0, tp1=102.0, tp2=104.0, units=10.0, risk_usd=10.0, state=state)
    d.update(kw)
    return SimTrade(**d)


def short_trade(state="open"):
    return SimTrade(side="SHORT", entry=100.0, stop=101.0, tp1=98.0, tp2=96.0, units=10.0, risk_usd=10.0, state=state)


def test_stop_loss_is_minus_one_r():
    t = advance(long_trade(), 100.5, 98.9, 99.0, P)
    assert t.state == "closed" and t.exit_reason == "stop"
    assert t.pnl_usd == pytest.approx(-10) and t.r == pytest.approx(-1)


def test_tp1_then_break_even_stop():
    t = long_trade()
    advance(t, 102.1, 100.2, 101.5, P)           # TP1: half closed at +2
    assert t.state == "open" and t.tp1_hit and t.cur_stop == 100.0 and t.remaining == pytest.approx(0.5)
    advance(t, 101.0, 99.9, 100.2, P)            # back to break-even: remainder out at 0
    assert t.state == "closed" and t.exit_reason == "break-even stop"
    assert t.pnl_usd == pytest.approx(10) and t.r == pytest.approx(1.0)


def test_tp1_then_tp2():
    t = long_trade()
    advance(t, 102.1, 100.2, 101.5, P)
    advance(t, 104.2, 101.0, 104.0, P)
    assert t.exit_reason == "TP2" and t.r == pytest.approx(3.0)


def test_tp2_not_counted_on_the_tp1_candle():
    t = long_trade()
    advance(t, 105.0, 100.2, 104.5, P)           # candle reaches TP1 and TP2: only TP1 is credited
    assert t.state == "open" and t.tp1_hit


def test_stop_beats_target_in_same_candle():
    t = advance(long_trade(), 102.5, 98.5, 100.0, P)
    assert t.exit_reason == "stop" and t.r == pytest.approx(-1)


def test_short_side_mirrors_long():
    t = short_trade()
    advance(t, 100.2, 97.9, 98.2, P)
    assert t.tp1_hit and t.cur_stop == 100.0
    advance(t, 98.2, 95.9, 96.5, P)
    assert t.exit_reason == "TP2" and t.r == pytest.approx(3.0)
    s = advance(short_trade(), 101.2, 99.0, 100.0, P)
    assert s.exit_reason == "stop" and s.r == pytest.approx(-1)


def test_limit_order_expires_unfilled():
    t = long_trade(state="pending")
    for _ in range(8):
        advance(t, 101.5, 100.5, 101.0, P)       # never trades down to 100
    assert t.state == "expired" and "not filled" in t.exit_reason


def test_limit_order_cancelled_if_target_reached_first():
    t = long_trade(state="pending")
    advance(t, 102.5, 100.5, 102.0, P)
    assert t.state == "expired" and "target" in t.exit_reason


def test_no_target_credit_on_the_fill_candle():
    t = long_trade(state="pending")
    advance(t, 103.0, 99.5, 102.5, P)            # fills AND "reaches" TP1 in one candle: unknowable order
    assert t.state == "open" and not t.tp1_hit


def test_stop_can_trigger_on_the_fill_candle():
    t = long_trade(state="pending")
    advance(t, 100.5, 98.5, 99.0, P)
    assert t.state == "closed" and t.exit_reason == "stop"


def test_time_stop_closes_at_candle_close():
    p = SimParams(max_bars=3, spread_usd=0.0, slippage_usd=0.0)
    t = long_trade()
    for _ in range(3):
        advance(t, 100.8, 99.4, 100.5, p)
    assert t.exit_reason == "time stop" and t.pnl_usd == pytest.approx(5.0)


def test_costs_are_charged():
    p = SimParams(spread_usd=1.0, slippage_usd=0.3)
    t = advance(long_trade(), 100.5, 98.9, 99.0, p)
    assert t.pnl_usd == pytest.approx(-10 - 10 - 3) and t.r == pytest.approx(-2.3)


def test_closed_trade_ignores_more_candles():
    t = advance(long_trade(), 100.5, 98.9, 99.0, P)
    pnl = t.pnl_usd
    advance(t, 110, 90, 100, P)
    assert t.pnl_usd == pnl


def test_roundtrip_serialisation():
    t = long_trade()
    advance(t, 102.1, 100.2, 101.5, P, ts="2026-01-05 08:00:00+00:00")
    t2 = SimTrade.from_dict(t.to_dict())
    assert t2 == t
