import numpy as np
import pandas as pd
import pytest

from agents.btc_agent import BtcAgent
from agents.manager_agent import ManagerAgent
from agents.regime_agent import RegimeAgent
from agents.risk_agent import RiskAgent
from agents.volume_profile_agent import VolumeProfileAgent, profile
from core.models import AgentReport, MarketSnapshot
from tests.conftest import make_candles, make_snap


def frame(closes, spread=0.4, vol=100.0, freq="15min"):
    rows = [(c, c + spread, c - spread, c, vol, vol / 2) for c in closes]
    idx = pd.date_range("2026-01-01", periods=len(rows), freq=freq, tz="UTC")
    return pd.DataFrame(rows, columns=["open", "high", "low", "close", "volume", "taker_buy_base"], index=idx)


def snap_of(entry, htf=None, ref=None, price=None):
    htf = htf if htf is not None else entry
    return MarketSnapshot("ETHUSDT", float(price or entry["close"].iloc[-1]), {"15m": entry, "1h": htf}, None, None, None, "test",
                          entry.index[-1] + pd.Timedelta(minutes=15), None, ref)


# ------------------------------------------------------------------ regime
def test_trend_range_and_squeeze_are_told_apart(cfg):
    n = 400
    trend = frame(1000 + np.arange(n) * 0.2 + np.random.default_rng(1).normal(0, 1.0, n) * (0.5 + np.arange(n) * 0.01), spread=0.6)   # volatility rising: not a squeeze
    h_trend = frame(1000 + np.arange(n) * 4.0 + np.random.default_rng(2).normal(0, 2.0, n), spread=2.0, freq="1h")
    r = RegimeAgent(cfg).analyze(snap_of(trend, h_trend))
    assert r.details["regime"] == "trend" and r.bias > 0 and r.details["trend_direction"] == 1
    assert r.details["fit"]["trend_pullback"] > 1 > r.details["fit"]["sweep_reversal"]
    noise = np.random.default_rng(1).normal(0, 1.0, n) * (0.5 + np.arange(n) * 0.01)
    down = RegimeAgent(cfg).analyze(snap_of(frame(1000 - np.arange(n) * 0.2 + noise, spread=0.6),
                                            frame(1000 - np.arange(n) * 4.0 + np.random.default_rng(2).normal(0, 2.0, n), spread=2.0, freq="1h")))
    assert down.details["regime"] == "trend" and down.bias < 0

    rng = np.random.default_rng(3)
    chop = frame(100 + 3 * np.sin(np.arange(n) / 3.0) + rng.normal(0, 0.8, n), spread=0.8)
    h_chop = frame(100 + 3 * np.sin(np.arange(n) / 2.0) + rng.normal(0, 0.8, n), spread=1.5, freq="1h")
    r = RegimeAgent(cfg).analyze(snap_of(chop, h_chop))
    assert r.details["regime"] == "range" and r.bias == 0 and r.details["fit"]["sweep_reversal"] > 1

    wide = 100 + np.cumsum(np.random.default_rng(4).normal(0, 0.6, n))
    tight = np.r_[wide[:-40], wide[-41] + np.random.default_rng(5).normal(0, 0.02, 40)]
    r = RegimeAgent(cfg).analyze(snap_of(frame(tight), h_chop))
    assert r.details["regime"] == "squeeze" and r.details["fit"]["pattern_breakout"] > 1


def test_regime_is_not_in_the_score_by_default_but_reorders_setups(cfg):
    assert cfg["weights"]["regime"] == 0.0
    from core.breakdown import contributions
    reps = {"regime": AgentReport("regime", 0.6, 0.7, "x", {"regime": "trend", "fit": {}}),
            "liquidity": AgentReport("liquidity", 0.5, 0.5, "x", {})}
    c = contributions(cfg["weights"], reps)
    assert c["regime"]["contribution"] == 0.0 and c["liquidity"]["share"] == pytest.approx(1.0)


def test_manager_ranks_setups_by_regime_fit(cfg):
    from strategies.base import Setup, Strategy
    class A(Strategy):
        name = "trend_pullback"; agents = ()
        def detect(self, snap, reports, ctx): return Setup("trend_pullback", 1, "MARKET", ctx.price, ctx.price - 3, 0.60, "a")
    class B(Strategy):
        name = "sweep_reversal"; agents = ()
        def detect(self, snap, reports, ctx): return Setup("sweep_reversal", 1, "MARKET", ctx.price, ctx.price - 3, 0.66, "b")
    df = make_candles([(100.0, 100.4, 99.6, 100.0)] * 120)
    snap = make_snap(df)

    def run(regime, fit):
        m = ManagerAgent(cfg, RiskAgent(cfg)); m.strategies = [A(cfg), B(cfg)]
        reps = {"liquidity": AgentReport("liquidity", 0.8, 0.8, "x", {"atr": 1.0}), "structure": AgentReport("structure", 0.8, 0.8, "x", {}),
                "orderflow": AgentReport("orderflow", 0.8, 0.8, "x", {}),
                "regime": AgentReport("regime", 0, 0, "x", {"regime": regime, "fit": fit})}
        from core.models import RiskState
        return m.decide(snap, reps, RiskState(), pd.Timestamp("2026-01-01 12:00", tz="UTC"))
    assert run("mixed", {}).strategy == "sweep_reversal"                                              # higher base quality wins
    plan = run("trend", {"trend_pullback": 1.15, "sweep_reversal": 0.85})                            # the trend suits the pullback
    assert plan.strategy == "trend_pullback"
    assert next(r for r in plan.setups if r["strategy"] == "sweep_reversal")["regime_fit"] == 0.85


# ------------------------------------------------------------------ volume profile
def test_profile_finds_the_poc_and_the_value_area(cfg):
    closes = [100.0] * 150 + list(np.linspace(100, 110, 20)) + [110.0] * 22
    df = frame(closes, spread=0.2, vol=100.0)
    df.loc[df.index[:150], "volume"] = 300.0                     # most volume traded near 100
    edges, vol = profile(df, 50)
    assert abs(((edges[:-1] + edges[1:]) / 2)[vol.argmax()] - 100.0) < 0.8
    r = VolumeProfileAgent(cfg).analyze(snap_of(df, price=100.1))
    assert r.details["poc"] == pytest.approx(100.0, abs=0.8) and r.details["val"] <= r.details["poc"] <= r.details["vah"]


def test_inside_value_area_leans_to_the_poc_and_acceptance_leans_with_the_move(cfg):
    base = [100.0 + d for d in [-1.0, -0.5, 0, 0, 0, 0, 0.5, 1.0, 0, 0] * 15] + [100.0] * 10
    inside = frame(base + [100.2] * 5)
    r = VolumeProfileAgent(cfg).analyze(snap_of(inside))
    assert r.details["state"] == "inside" and np.sign(r.bias) == np.sign(r.details["poc"] - 100.2)     # leans toward the POC
    accepted = frame(base + [104.0, 104.5, 105.0, 105.2, 105.5])
    r = VolumeProfileAgent(cfg).analyze(snap_of(accepted))
    assert r.details["state"] == "accepted_above" and r.bias > 0
    failed = frame(base + [104.0, 104.2, 104.0, 103.9, 100.4, 100.3])
    r = VolumeProfileAgent(cfg).analyze(snap_of(failed))
    assert r.details["state"] == "reentered" and r.bias < 0


def test_volume_profile_without_volume_stays_out(cfg):
    df = frame([100.0] * 200, vol=0.0)
    assert VolumeProfileAgent(cfg).analyze(snap_of(df)).details["no_data"]


# ------------------------------------------------------------------ BTC
def btc_pair(corr_noise=0.3, n=400, seed=1, btc_jump=0.0, eth_follow=1.0):
    rng = np.random.default_rng(seed)
    r_b = rng.normal(0, 0.002, n)
    r_b[-4:] += btc_jump / 4
    r_e = 1.0 * r_b * np.r_[np.ones(n - 4), np.full(4, eth_follow)] + corr_noise * rng.normal(0, 0.002, n)
    idx = pd.date_range("2026-01-01", periods=n, freq="15min", tz="UTC")
    mk = lambda r, p0: frame(p0 * np.exp(np.cumsum(r)), spread=0.001 * p0)
    eth, btc = mk(r_e, 3000.0), mk(r_b, 65000.0)
    h = lambda d: d.resample("1h").agg({"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum", "taker_buy_base": "sum"}).dropna()
    return eth, {"15m": btc, "1h": h(btc)}, h(eth)


def test_btc_lag_leans_toward_the_catch_up_and_scales_with_correlation(cfg):
    eth, ref, h = btc_pair(btc_jump=0.02, eth_follow=0.0)            # BTC +2% in an hour, ETH did not move
    r = BtcAgent(cfg).analyze(snap_of(eth, h, ref))
    assert r.details["correlation"] > 0.6 and r.details["catch_up"] > 0.3 and r.bias > 0.2
    eth2, ref2, h2 = btc_pair(btc_jump=-0.02, eth_follow=0.0)
    assert BtcAgent(cfg).analyze(snap_of(eth2, h2, ref2)).bias < -0.2
    eth3, ref3, h3 = btc_pair(btc_jump=0.02, eth_follow=1.0)         # ETH followed: nothing left to catch
    assert abs(BtcAgent(cfg).analyze(snap_of(eth3, h3, ref3)).details["catch_up"]) < 0.3


def test_btc_decoupled_or_missing_stays_out(cfg):
    eth, ref, h = btc_pair(corr_noise=12.0)
    r = BtcAgent(cfg).analyze(snap_of(eth, h, ref))
    assert r.details["no_data"] and "decoupled" in r.summary
    assert BtcAgent(cfg).analyze(snap_of(eth, h, None)).details["no_data"]


def test_snapshot_until_cuts_btc_candles_too(cfg):
    from core.pipeline import TradingSystem
    snap = TradingSystem(cfg, demo=True, seed=3, journal_path=":memory:").data.snapshot()
    assert snap.ref and set(snap.ref) == {"15m", "1h"}
    t = snap.candles["15m"].index[-50] + pd.Timedelta(minutes=15)
    cut = snap.until(t)
    assert cut.ref["15m"].index[-1] + pd.Timedelta(minutes=15) <= t and cut.ref["1h"].index[-1] + pd.Timedelta(hours=1) <= t


def test_demo_btc_is_correlated_with_eth_but_does_not_predict_it(cfg):
    from core.pipeline import TradingSystem
    snap = TradingSystem(cfg, demo=True, seed=5, journal_path=":memory:").data.snapshot()
    e, b = snap.candles["15m"]["close"], snap.ref["15m"]["close"]
    re_, rb = np.log(e).diff().dropna(), np.log(b).diff().dropna()
    idx = re_.index.intersection(rb.index)
    assert np.corrcoef(re_[idx], rb[idx])[0, 1] > 0.5
    assert abs(np.corrcoef(rb[idx].values[:-1], re_[idx].values[1:])[0, 1]) < 0.06          # BTC's past says nothing about ETH's next candle
