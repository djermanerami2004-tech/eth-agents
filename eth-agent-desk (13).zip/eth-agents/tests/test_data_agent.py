"""The sandbox that built this project cannot reach Binance, so the live data path is tested against
a mocked HTTP layer that returns Binance-shaped payloads. Run `python main.py check` on your own PC to
test the real connection."""
import pandas as pd
import pytest

import agents.data_agent as da
from agents.data_agent import DataAgent


class Resp:
    def __init__(self, data, status=200):
        self._d, self.status_code = data, status
        self.ok = status < 400

    def json(self):
        return self._d

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


def tf_min(iv):
    return int(iv[:-1]) * {"m": 1, "h": 60, "d": 1440}[iv[-1]]


def kline_rows(interval_min, n=60):
    end = pd.Timestamp.now(tz="UTC").floor(f"{interval_min}min")
    rows = []
    for i in range(n):
        t0 = end - pd.Timedelta(minutes=interval_min * (n - i))
        p = 2500 + i
        rows.append([int(t0.timestamp() * 1000), str(p), str(p + 2), str(p - 2), str(p + 1), "100.5",
                     int((t0 + pd.Timedelta(minutes=interval_min)).timestamp() * 1000) - 1, "0", 10,
                     "60.25", "0", "0"])
    return rows


@pytest.fixture(autouse=True)
def no_sleep(monkeypatch):
    monkeypatch.setattr(da.time, "sleep", lambda s: None)


def test_live_snapshot_parses_binance_payloads(cfg, monkeypatch):
    def fake_get(url, params=None, timeout=None, **kw):
        if url.endswith("/fapi/v1/klines"):
            return Resp(kline_rows(tf_min(params["interval"])))
        if url.endswith("/futures/data/openInterestHist"):
            return Resp([{"sumOpenInterest": "1000", "timestamp": int(pd.Timestamp.now(tz="UTC").timestamp() * 1000) - 900000}])
        if url.endswith("/fapi/v1/premiumIndex"):
            return Resp({"markPrice": "2561.5", "lastFundingRate": "0.0001"})
        if url.endswith("/futures/data/globalLongShortAccountRatio"):
            return Resp([{"longShortRatio": "1.3"}])
        if url.endswith("/fapi/v1/depth"):
            return Resp({"bids": [["2561.4", "10"], ["2561.3", "5"]], "asks": [["2561.6", "8"], ["2561.7", "2"]]})
        raise AssertionError(url)

    monkeypatch.setattr(da.requests, "get", fake_get)
    snap = DataAgent(cfg).snapshot()
    assert snap.book == {"bids": [[2561.4, 10.0], [2561.3, 5.0]], "asks": [[2561.6, 8.0], [2561.7, 2.0]]}
    assert snap.until(snap.ts - pd.Timedelta(hours=1)).book is None      # the past has no order book
    assert snap.source == "binance-live" and snap.price == 2561.5
    assert {"15m", "1h", "4h", "1d"} <= set(snap.candles)
    assert snap.funding == 0.0001 and snap.long_short_ratio == 1.3 and snap.oi is not None
    df = snap.candles["15m"]
    assert {"open", "high", "low", "close", "volume", "taker_buy_base"} <= set(df.columns)
    assert df["taker_buy_base"].iloc[-1] == 60.25 and df.index.tz is not None
    # only fully closed candles are exposed
    assert df.index[-1] + pd.Timedelta(minutes=15) <= snap.ts


def test_falls_back_to_the_spot_mirror(cfg, monkeypatch):
    def fake_get(url, params=None, timeout=None, **kw):
        if "data-api.binance.vision" in url:
            return Resp(kline_rows(tf_min(params["interval"])))
        return Resp({}, status=503)

    monkeypatch.setattr(da.requests, "get", fake_get)
    snap = DataAgent(cfg).snapshot()
    assert snap.source == "binance-spot-fallback" and snap.funding is None and snap.oi is None
    assert len(snap.candles["15m"]) > 10


def test_blocked_region_gives_a_clear_error(cfg, monkeypatch):
    monkeypatch.setattr(da.requests, "get", lambda *a, **k: Resp({}, status=451))
    with pytest.raises(RuntimeError) as e:
        DataAgent(cfg).snapshot()
    assert "451" in str(e.value) or "blocks" in str(e.value)
