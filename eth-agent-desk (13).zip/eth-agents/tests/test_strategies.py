from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

from agents.manager_agent import ManagerAgent
from agents.risk_agent import RiskAgent
from core.indicators import atr, ema
from core.models import AgentReport, RiskState
from strategies import build_strategies
from strategies.bos_retest import BosRetest
from strategies.consensus import Consensus
from strategies.range_breakout import RangeBreakout
from strategies.sweep_reversal import SweepReversal
from strategies.trend_pullback import TrendPullback
from tests.conftest import make_candles, make_snap


def ctx_for(df, score=0.3):
    return SimpleNamespace(price=float(df["close"].iloc[-1]), atr=float(atr(df).iloc[-1]), df=df, score=score)


def mtf_report(hb, bias=None):
    return AgentReport("mtf", hb if bias is None else bias, 0.8, "test", {"htf_bias": hb, "per_tf": {}})


# ---------------------------------------------------------------- sweep reversal
def test_sweep_strategy_uses_the_liquidity_sweep(cfg):
    df = make_candles([(100, 101, 99, 100)] * 60)
    rep = {"liquidity": AgentReport("liquidity", 0.8, 0.8, "s", {"sweep": {"direction": 1, "level": 95, "extreme": 94.2, "strength": 0.9}})}
    s = SweepReversal(cfg).detect(make_snap(df), rep, ctx_for(df))
    assert s.side == 1 and s.stop_ref == 94.2 and s.name == "sweep_reversal"
    assert SweepReversal(cfg).detect(make_snap(df), {"liquidity": AgentReport("liquidity", 0, 0, "", {"sweep": None})}, ctx_for(df)) is None


# ---------------------------------------------------------------- trend pullback
def pullback_frame(direction=1):
    n_up, n_pb = 150, 15
    closes = list(100 + direction * np.arange(n_up) * 0.2) + list(100 + direction * (n_up * 0.2 - np.arange(1, n_pb + 1) * 0.3))
    rows = [(c - direction * 0.05, c + 0.3, c - 0.3, c) for c in closes]
    df = make_candles(rows)
    e50 = float(ema(df["close"], 50).iloc[-1])
    # last candle: dips through the EMA50 and closes back in the trend direction
    rows[-1] = (e50 - direction * 0.8, e50 + (0.6 if direction == 1 else 1.0), e50 - (1.0 if direction == 1 else 0.6),
                e50 + direction * 0.5)
    return make_candles(rows)


@pytest.mark.parametrize("d", [1, -1])
def test_trend_pullback_to_ema(cfg, d):
    df = pullback_frame(d)
    rep = {"mtf": mtf_report(0.8 * d), "structure": AgentReport("structure", 0, 0, "", {"zones": []})}
    s = TrendPullback(cfg).detect(make_snap(df), rep, ctx_for(df))
    assert s is not None and s.side == d and s.name == "trend_pullback"
    assert (s.stop_ref - s.entry) * d < 0


def test_trend_pullback_needs_the_higher_timeframe_trend(cfg):
    df = pullback_frame(1)
    st = AgentReport("structure", 0, 0, "", {"zones": []})
    assert TrendPullback(cfg).detect(make_snap(df), {"mtf": mtf_report(0.1), "structure": st}, ctx_for(df)) is None
    assert TrendPullback(cfg).detect(make_snap(df), {"mtf": mtf_report(-0.8), "structure": st}, ctx_for(df)) is None


def test_trend_pullback_needs_a_rejection_candle(cfg):
    df = pullback_frame(1)
    df.iloc[-1, df.columns.get_loc("close")] = df.iloc[-1]["open"] - 0.2      # bearish last candle
    rep = {"mtf": mtf_report(0.8), "structure": AgentReport("structure", 0, 0, "", {"zones": []})}
    assert TrendPullback(cfg).detect(make_snap(df), rep, ctx_for(df)) is None


# ---------------------------------------------------------------- break of structure + retest
def bos_rows(retest=True):
    rows = [(101, 101.6, 100.4, 101)] * 30
    rows += [(101, 101.4, 100.6, 101.2), (101.2, 101.8, 101, 101.6), (101.6, 102.2, 101.4, 102.0),
             (102, 102.5, 101.8, 102.0),                                    # swing high 102.5
             (102, 102.2, 101.6, 101.8), (101.8, 102.0, 101.4, 101.6), (101.6, 101.9, 101.3, 101.5)]
    rows += [(101.5, 102, 101.2, 101.6)] * 6
    rows += [(101.8, 103.4, 101.7, 103.2),                                  # breaks 102.5
             (103.2, 104.0, 103.0, 103.8), (103.8, 104.2, 103.5, 104.0),
             (104, 104.0, 103.2, 103.3), (103.3, 103.4, 102.7, 102.9)]
    rows.append((102.9, 103.3, 102.6, 103.1) if retest else (103.0, 104.5, 102.95, 104.3))
    return rows


def test_bos_retest_long(cfg):
    df = make_candles(bos_rows())
    s = BosRetest(cfg).detect(make_snap(df), {"mtf": mtf_report(0.5)}, ctx_for(df))
    assert s is not None and s.side == 1 and s.name == "bos_retest" and s.stop_ref < 102.5


def test_bos_without_retest_is_ignored(cfg):
    df = make_candles(bos_rows(retest=False))
    assert BosRetest(cfg).detect(make_snap(df), {"mtf": mtf_report(0.5)}, ctx_for(df)) is None


def test_bos_retest_short_mirror(cfg):
    rows = [(200 - o, 200 - l, 200 - h, 200 - c) for (o, h, l, c) in bos_rows()]
    df = make_candles(rows)
    s = BosRetest(cfg).detect(make_snap(df), {"mtf": mtf_report(-0.5)}, ctx_for(df))
    assert s is not None and s.side == -1


def test_bos_retest_refuses_to_trade_against_the_big_trend(cfg):
    df = make_candles(bos_rows())
    assert BosRetest(cfg).detect(make_snap(df), {"mtf": mtf_report(-0.6)}, ctx_for(df)) is None


# ---------------------------------------------------------------- Asian range breakout
def range_rows(buy=210.0, vol=300.0, close=101.8):
    rows = []
    for i in range(28):                                         # 00:00-06:45 UTC, tight 100-101 range
        rows.append((100.5, 101.0, 100.0, 100.5 + (0.2 if i % 2 else -0.2)))
    rows += [(100.5, 100.9, 100.2, 100.6)] * 8                  # 07:00-08:45 inside the range
    rows.append((100.8, 102.0, 100.7, close))                   # 09:00 breakout
    df = make_candles(rows, start="2026-01-06 00:00")
    df.iloc[-1, df.columns.get_loc("volume")] = vol
    df.iloc[-1, df.columns.get_loc("taker_buy_base")] = buy
    return df


def test_range_breakout_long(cfg):
    df = range_rows()
    s = RangeBreakout(cfg).detect(make_snap(df), {"mtf": mtf_report(0.2)}, ctx_for(df))
    assert s is not None and s.side == 1 and s.stop_ref == pytest.approx(100.5)


def test_range_breakout_needs_volume_and_flow(cfg):
    for df in (range_rows(vol=100.0, buy=70.0), range_rows(buy=100.0)):     # no volume / sellers behind it
        assert RangeBreakout(cfg).detect(make_snap(df), {"mtf": mtf_report(0.2)}, ctx_for(df)) is None


def test_range_breakout_ignored_outside_trading_hours_and_wide_ranges(cfg):
    df = range_rows()
    cfg["strategies"]["range_breakout"]["trade_until"] = 8
    assert RangeBreakout(cfg).detect(make_snap(df), {"mtf": mtf_report(0.2)}, ctx_for(df)) is None
    cfg["strategies"]["range_breakout"]["trade_until"] = 17
    cfg["strategies"]["range_breakout"]["max_range_pct"] = 0.5
    assert RangeBreakout(cfg).detect(make_snap(df), {"mtf": mtf_report(0.2)}, ctx_for(df)) is None


def test_range_breakout_against_big_trend_is_ignored(cfg):
    df = range_rows()
    assert RangeBreakout(cfg).detect(make_snap(df), {"mtf": mtf_report(-0.5)}, ctx_for(df)) is None


# ---------------------------------------------------------------- registry + manager
def test_strategies_can_be_switched_off(cfg):
    names = lambda: [s.name for s in build_strategies(cfg)]
    assert set(names()) == {"sweep_reversal", "session_sweep", "trend_pullback", "bos_retest", "range_breakout", "pattern_breakout", "consensus"}
    cfg["strategies"]["bos_retest"]["enabled"] = False
    cfg["strategies"]["consensus"]["enabled"] = False
    assert set(names()) == {"sweep_reversal", "session_sweep", "trend_pullback", "range_breakout", "pattern_breakout"}


def manager_reports(sweep=None, mtf_hb=0.0, bias=0.0):
    return {"liquidity": AgentReport("liquidity", bias, 0.8, "liq", {"clusters": [], "atr": 1.0, "sweep": sweep}),
            "structure": AgentReport("structure", bias, 0.8, "st", {"zones": []}),
            "orderflow": AgentReport("orderflow", bias, 0.8, "of"),
            "mtf": mtf_report(mtf_hb)}


def test_manager_labels_the_plan_with_its_strategy(cfg):
    df = bos_rows()
    snap = make_snap(make_candles(df))
    rep = manager_reports(mtf_hb=0.5, bias=0.4)
    plan = ManagerAgent(cfg, RiskAgent(cfg)).decide(snap, rep, RiskState(), snap.ts)
    assert plan.side == "LONG" and plan.strategy in ("bos_retest", "consensus")
    assert plan.reasons[0].startswith("LONG market - " + plan.strategy)


def test_new_strategies_trade_with_a_weaker_composite_score_than_consensus(cfg):
    snap = make_snap(make_candles(bos_rows()))
    rep = manager_reports(mtf_hb=0.5, bias=0.1)               # weak agreement: composite well below 0.22
    plan = ManagerAgent(cfg, RiskAgent(cfg)).decide(snap, rep, RiskState(), snap.ts)
    assert plan.strategy == "bos_retest"
    cfg["strategies"]["bos_retest"]["enabled"] = False
    plan2 = ManagerAgent(cfg, RiskAgent(cfg)).decide(snap, rep, RiskState(), snap.ts)
    assert plan2.side == "NONE" and "below" in plan2.reasons[0]


def test_no_strategy_found_is_explained(cfg):
    snap = make_snap(make_candles([(100, 100.3, 99.8, 100.1)] * 80))
    plan = ManagerAgent(cfg, RiskAgent(cfg)).decide(snap, manager_reports(), RiskState(), snap.ts)
    assert plan.side == "NONE" and "no strategy found a setup" in plan.reasons[0]


# ---------------------------------------------------------------- pattern breakout
def _pattern_report(**kw):
    b = {"name": "double top", "tf": "1h", "dir": -1, "status": "broken", "since": 2, "break_level": 100.0,
         "target": 88.0, "stop_ref": 106.0, "strength": 0.8, "quality": 0.8}
    b.update(kw)
    return {"patterns": AgentReport("patterns", -0.7, 0.7, "x", {"patterns": [b], "breakout": b})}


def test_pattern_breakout_short_with_measured_move(cfg):
    from strategies.pattern_breakout import PatternBreakout
    df = make_candles([(99.6, 100, 99, 99.5)] * 60)
    s = PatternBreakout(cfg).detect(make_snap(df), _pattern_report(), ctx_for(df))
    assert s.side == -1 and s.name == "pattern_breakout" and s.stop_ref == 106.0 and s.target == 88.0


def test_pattern_breakout_does_not_chase_or_trade_a_failed_break(cfg):
    from strategies.pattern_breakout import PatternBreakout
    df = make_candles([(99.6, 100, 99, 99.5)] * 60)
    ctx = ctx_for(df)
    far = _pattern_report(break_level=100.0 + 5 * ctx.atr)                     # price already far below the break
    assert PatternBreakout(cfg).detect(make_snap(df), far, ctx) is None
    back = _pattern_report(break_level=99.5 - 2 * ctx.atr)                     # price climbed back above the line
    assert PatternBreakout(cfg).detect(make_snap(df), back, ctx) is None
    assert PatternBreakout(cfg).detect(make_snap(df), {}, ctx) is None


def test_manager_uses_the_measured_move_as_first_target(cfg):
    from strategies.base import Setup
    m = ManagerAgent(cfg, RiskAgent(cfg))
    s = Setup("pattern_breakout", -1, "MARKET", 100.0, 102.0, 0.7, "t", target=94.5)
    stop, tp1, tp2, rr = m._levels(s, 1.0, {})          # R = 2.3, so the target is 2.39R: it becomes TP1
    assert tp1 == pytest.approx(94.5) and rr == pytest.approx(5.5 / (stop - 100.0), abs=0.01) and tp2 < tp1
    s2 = Setup("pattern_breakout", -1, "MARKET", 100.0, 102.0, 0.7, "t", target=70.0)       # far target becomes TP2 (max 6R)
    stop2, a1, a2, _ = m._levels(s2, 1.0, {})
    assert a2 == pytest.approx(100.0 - 6.0 * (stop2 - 100.0)) and a1 > a2
    s3 = Setup("pattern_breakout", -1, "MARKET", 100.0, 102.0, 0.7, "t", target=99.5)       # tiny target is ignored
    assert m._levels(s3, 1.0, {})[3] >= cfg["risk"]["min_rr"]
