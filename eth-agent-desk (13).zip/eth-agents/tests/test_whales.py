import time

import pandas as pd
import pytest

from agents.whale_agent import WhaleAgent
from core import coinglass
from core.models import MarketSnapshot
from tests.conftest import make_candles


NOW_MS = int(time.time() * 1000)


def snap(price=2400.0, source="test", ts=None):
    df = make_candles([(price, price + 1, price - 1, price)] * 30)
    return MarketSnapshot("ETHUSDT", price, {"15m": df}, None, None, None, source, ts or pd.Timestamp.now(tz="UTC"))


def order(price, side="bid", usd=10e6, age_min=60, state=1, executed=0.0, end_ago_min=None, start_usd=None):
    NOW_MS = int(time.time() * 1000)             # fresh each call: ages must not drift during a long test run
    return {"price": price, "side": side, "state": state, "usd": usd, "start_usd": start_usd or usd, "executed_usd": executed,
            "start_ms": NOW_MS - int(age_min * 60_000), "end_ms": NOW_MS - int(end_ago_min * 60_000) if end_ago_min is not None else None,
            "exchange": "Binance"}


def agent(cfg, orders=None, error=None):
    return WhaleAgent(cfg, fetch=lambda: {"orders": orders or [], "error": error})


def test_bid_wall_leans_long_ask_wall_leans_short(cfg):
    up = agent(cfg, [order(2394.0, "bid", 15e6)]).analyze(snap())
    dn = agent(cfg, [order(2406.0, "ask", 15e6)]).analyze(snap())
    assert up.bias > 0.2 and dn.bias < -0.2 and not up.details.get("no_data")
    assert up.details["walls"][0]["side"] == "bid" and "nearest bid" in up.summary


def test_bigger_and_closer_walls_count_more(cfg):
    near = agent(cfg, [order(2397.0, "bid", 15e6)]).analyze(snap()).bias
    far = agent(cfg, [order(2370.0, "bid", 15e6)]).analyze(snap()).bias
    small = agent(cfg, [order(2397.0, "bid", 1.5e6)]).analyze(snap()).bias
    assert near > far > 0 and near > small > 0


def test_balanced_walls_cancel_out(cfg):
    r = agent(cfg, [order(2394.0, "bid", 12e6), order(2406.0, "ask", 12e6)]).analyze(snap())
    assert abs(r.bias) < 0.05


def test_young_and_eaten_walls_are_trusted_less(cfg):
    old = agent(cfg, [order(2394.0, "bid", 15e6, age_min=90)]).analyze(snap()).bias
    young = agent(cfg, [order(2394.0, "bid", 15e6, age_min=1)]).analyze(snap()).bias
    eaten = agent(cfg, [order(2394.0, "bid", 15e6, age_min=90, executed=30e6)]).analyze(snap()).bias
    assert old > young > 0 and old > eaten > 0


def test_orders_on_the_wrong_side_of_price_or_out_of_range_or_closed_are_ignored(cfg):
    r = agent(cfg, [order(2410.0, "bid", 15e6), order(2390.0, "ask", 15e6)]).analyze(snap())      # being crossed right now
    assert r.details["no_data"]
    assert agent(cfg, [order(2200.0, "bid", 15e6)]).analyze(snap()).details["no_data"]             # 8% away
    assert agent(cfg, [order(2394.0, "bid", 15e6, state=2)]).analyze(snap()).details["no_data"]    # finished
    assert agent(cfg, [order(2394.0, "bid", 500e3)]).analyze(snap()).details["no_data"]            # below min_usd


def test_many_cancelled_walls_lower_confidence_and_warn(cfg):
    base = agent(cfg, [order(2394.0, "bid", 15e6)]).analyze(snap())
    pulled = [order(2380.0 + i, "bid", 8e6, state=3, end_ago_min=5) for i in range(4)]
    r = agent(cfg, [order(2394.0, "bid", 15e6)] + pulled).analyze(snap())
    assert r.confidence < base.confidence and "cancelled" in r.summary and r.details["cancels"] == 4


def test_errors_demo_and_replays_stay_out_with_clear_words(cfg):
    for kind, text in (("nokey", "No Coinglass key"), ("plan", "Standard or higher"), ("key", "rejected the API key")):
        msg = {"nokey": "no COINGLASS_API_KEY in .env", "plan": "your Coinglass plan does not include large orders (it needs Standard or higher)",
               "key": "Coinglass rejected the API key (copy it again into .env, or reset it)"}[kind]
        r = agent(cfg, error={"kind": kind, "msg": msg}).analyze(snap())
        assert r.details["no_data"] and text in r.summary and r.details["error"] == kind
    assert agent(cfg, [order(2394.0)]).analyze(snap(source="synthetic(seed=1)")).details["no_data"]
    old = snap(ts=pd.Timestamp.now(tz="UTC") - pd.Timedelta(days=2))
    assert agent(cfg, [order(2394.0)]).analyze(old).details["no_data"]


# ---------------------------------------------------------------- the client
def raw(price, side=2, state=1, usd=5e6):
    return {"id": 1, "exchange_name": "Binance", "symbol": "ETHUSDT", "limit_price": price, "start_time": NOW_MS - 3_600_000,
            "start_quantity": 100.0, "start_usd_value": usd, "current_quantity": 100.0, "current_usd_value": usd, "current_time": NOW_MS,
            "executed_volume": 0.0, "executed_usd_value": 0.0, "trade_count": 0, "order_side": side, "order_state": state}


class Resp:
    def __init__(self, body, status=200):
        self._b, self.status_code, self.ok, self.text = body, status, status == 200, "x"

    def json(self):
        if isinstance(self._b, Exception):
            raise self._b
        return self._b


@pytest.fixture(autouse=True)
def fresh_cache():
    coinglass.clear_cache()
    yield
    coinglass.clear_cache()


def test_client_sends_the_documented_request_and_parses_the_answer(cfg, monkeypatch):
    seen = {}

    def fake_get(url, params=None, headers=None, timeout=None):
        seen.update(url=url, params=params, headers=headers)
        return Resp({"code": "0", "msg": "success", "data": [raw(2394.0, 2), raw(2406.0, 1), {"garbage": 1}]})
    monkeypatch.setattr("requests.get", fake_get)
    monkeypatch.setenv("COINGLASS_API_KEY", "k-123")
    res = coinglass.large_orders(cfg)
    assert seen["url"].endswith("/api/futures/orderbook/large-limit-order") and seen["params"] == {"exchange": "Binance", "symbol": "ETHUSDT"}
    assert seen["headers"]["CG-API-KEY"] == "k-123"
    assert res["error"] is None and [(o["side"], o["price"]) for o in res["orders"]] == [("bid", 2394.0), ("ask", 2406.0)]


def test_client_caches_and_remembers_plan_errors(cfg, monkeypatch):
    calls = []
    monkeypatch.setenv("COINGLASS_API_KEY", "k")
    monkeypatch.setattr("requests.get", lambda *a, **k: calls.append(1) or Resp({"code": "40004", "msg": "Upgrade plan"}))
    assert coinglass.large_orders(cfg)["error"]["kind"] == "plan"
    assert coinglass.large_orders(cfg, now=time.time() + 600)["error"]["kind"] == "plan"
    assert len(calls) == 1                                           # no second request for 30 minutes
    coinglass.clear_cache()
    calls.clear()
    monkeypatch.setattr("requests.get", lambda *a, **k: calls.append(1) or Resp({"code": "0", "data": [raw(2394.0)]}))
    coinglass.large_orders(cfg)
    coinglass.large_orders(cfg, now=time.time() + 30)
    assert len(calls) == 1                                           # 60 s cache
    coinglass.large_orders(cfg, now=time.time() + 90)
    assert len(calls) == 2


@pytest.mark.parametrize("body,status,kind", [({"code": "40001", "msg": "invalid api key"}, 200, "key"),
                                              ({"code": "40003", "msg": "rate limit"}, 429, "rate"),
                                              (ValueError("no json"), 200, "format"),
                                              ({"code": "9", "msg": "weird"}, 200, "format")])
def test_client_error_kinds(cfg, monkeypatch, body, status, kind):
    monkeypatch.setenv("COINGLASS_API_KEY", "k")
    monkeypatch.setattr("requests.get", lambda *a, **k: Resp(body, status))
    assert coinglass.large_orders(cfg)["error"]["kind"] == kind


def test_client_without_key_and_network_failure(cfg, monkeypatch):
    monkeypatch.delenv("COINGLASS_API_KEY", raising=False)
    assert coinglass.large_orders(cfg)["error"]["kind"] == "nokey"
    import requests
    monkeypatch.setenv("COINGLASS_API_KEY", "k")

    def boom(*a, **k):
        raise requests.ConnectionError("down")
    monkeypatch.setattr("requests.get", boom)
    assert coinglass.large_orders(cfg)["error"]["kind"] == "network"


def test_key_is_never_part_of_an_error_message(cfg, monkeypatch):
    monkeypatch.setenv("COINGLASS_API_KEY", "SECRET-KEY-VALUE")
    monkeypatch.setattr("requests.get", lambda *a, **k: Resp({"code": "40001", "msg": "invalid api key SECRET-KEY-VALUE"}))
    assert "SECRET-KEY-VALUE" not in str(coinglass.large_orders(cfg))
