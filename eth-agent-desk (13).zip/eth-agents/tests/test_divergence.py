import numpy as np

from agents.divergence_agent import DivergenceAgent
from core.divergence import find_divergences
from core.indicators import atr
from tests.conftest import make_candles, make_snap


def seg(a, b, n):
    return list(np.linspace(a, b, n + 1)[1:])


def frame(closes, spread=0.3):
    return make_candles([(c, c + spread, c - spread, c) for c in closes])


def divs(df, k=3, max_age=12, **kw):
    return find_divergences(df, float(atr(df).iloc[-1]), k, max_age, "15m", **kw)


BEAR = [100.0] * 20 + seg(100, 101, 10) + seg(101, 112, 10) + seg(112, 106, 10) + seg(106, 113, 22) + seg(113, 110, 8)
BULL = [100.0] * 20 + seg(100, 99, 10) + seg(99, 88, 10) + seg(88, 94, 10) + seg(94, 87, 22) + seg(87, 90, 8)


def test_regular_bearish_divergence_higher_high_lower_rsi():
    d = [x for x in divs(frame(BEAR)) if x["kind"] == "regular"]
    assert len(d) == 1 and d[0]["dir"] == -1 and d[0]["price_2"] > d[0]["price_1"] and d[0]["rsi_2"] < d[0]["rsi_1"]
    assert d[0]["points"][0][0] < d[0]["points"][1][0]


def test_regular_bullish_divergence_lower_low_higher_rsi():
    d = [x for x in divs(frame(BULL)) if x["kind"] == "regular"]
    assert len(d) == 1 and d[0]["dir"] == 1 and d[0]["price_2"] < d[0]["price_1"] and d[0]["rsi_2"] > d[0]["rsi_1"]


def test_hidden_bullish_divergence_higher_low_lower_rsi():
    path = [100.0] * 20 + seg(100, 125, 30) + seg(125, 122, 10) + seg(122, 133, 10) + seg(133, 127, 2) + seg(127, 129, 8)
    d = [x for x in divs(frame(path)) if x["dir"] == 1]
    assert d and d[0]["kind"] == "hidden" and d[0]["price_2"] > d[0]["price_1"] and d[0]["rsi_2"] < d[0]["rsi_1"]
    assert not [x for x in divs(frame(path), hidden=False) if x["dir"] == 1]            # switchable


def test_a_failed_divergence_is_dropped():
    failed = BEAR[:-8] + seg(BEAR[-9], 116, 8)              # price kept rising above the second high
    assert not [x for x in divs(frame(failed)) if x["dir"] == -1 and x["kind"] == "regular"]


def test_old_divergence_is_dropped():
    old = BEAR + seg(BEAR[-1], 108, 30)
    assert not [x for x in divs(frame(old), max_age=12) if x["kind"] == "regular"]


def test_no_lookahead_the_second_pivot_must_be_confirmed():
    cut = frame(BEAR).iloc[:-8]                              # the second high is not yet confirmed here
    assert not [x for x in divs(cut) if x["kind"] == "regular" and x["dir"] == -1]


def test_volume_delta_agreement_adds_quality():
    df = frame(BEAR)
    base = [x for x in divs(df) if x["kind"] == "regular"][0]
    strong = df.copy()
    strong["taker_buy_base"] = 50.0
    i2 = int(np.argmax(df["high"].values[40:]) + 40)
    strong.iloc[i2 - 2:i2 + 3, strong.columns.get_loc("taker_buy_base")] = 10.0    # sellers dominate the second peak
    better = [x for x in divs(strong) if x["kind"] == "regular"][0]
    assert better["delta_confirms"] and better["quality"] >= base["quality"]


def test_agent_bias_and_silence(cfg):
    r = DivergenceAgent(cfg).analyze(make_snap(frame(BEAR)))
    assert r.bias < -0.2 and not r.details.get("no_data") and r.details["divergences"]
    assert DivergenceAgent(cfg).analyze(make_snap(frame(BULL))).bias > 0.2
    flat = DivergenceAgent(cfg).analyze(make_snap(make_candles([(100, 100.3, 99.7, 100)] * 300)))
    assert flat.details["no_data"] and flat.bias == 0


def test_random_walks_rarely_show_a_fresh_regular_divergence_signal(cfg):
    hits, total = 0, 0
    for seed in range(8):
        c = 100 + np.cumsum(np.random.default_rng(seed).normal(0, 0.5, 600))
        df = frame(c, 0.4)
        for end in range(300, 600, 10):
            total += 1
            hits += any(x["kind"] == "regular" for x in divs(df.iloc[:end]))
    assert hits / total < 0.35         # a divergence is a normal thing to find in noise; it must not be everywhere
