import numpy as np
import pandas as pd
import pytest

from agents.liquidity_agent import LiquidityAgent
from agents.news_agent import NewsAgent
from agents.orderflow_agent import OrderFlowAgent
from agents.structure_agent import StructureAgent
from core.indicators import atr, resample, session_vwap, swings
from core.smc import find_fvgs
from core.models import AgentReport
from tests.conftest import make_candles, make_snap


def flat_rows(n, lo=96.0, hi=98.0):
    return [(97.0, hi, lo, 97.0)] * n


# ---------------------------------------------------------------- indicators
def test_swings_never_confirm_the_last_candles():
    rng = np.random.default_rng(1)
    c = 100 + np.cumsum(rng.normal(0, 1, 200))
    df = make_candles([(x, x + 1, x - 1, x) for x in c])
    sh, sl = swings(df, 3, 3)
    assert sh.iloc[-3:].isna().all() and sl.iloc[-3:].isna().all()


def test_swings_do_not_change_when_the_future_changes():
    rng = np.random.default_rng(2)
    c = 100 + np.cumsum(rng.normal(0, 1, 120))
    df = make_candles([(x, x + 1, x - 1, x) for x in c])
    a, _ = swings(df.iloc[:100], 3, 3)
    b, _ = swings(df, 3, 3)
    # a swing confirmed with data up to bar 99 must be identical when later bars are appended
    pd.testing.assert_series_equal(a.dropna(), b.iloc[:100].dropna())


def test_vwap_resets_each_utc_day():
    df = make_candles([(100, 101, 99, 100)] * 4 + [(200, 201, 199, 200)] * 4, start="2026-01-05 23:00")
    v = session_vwap(df)
    assert v.iloc[3] == pytest.approx(100, abs=1) and v.iloc[-1] == pytest.approx(200, abs=1)


def test_atr_positive_and_resample_aggregates():
    df = make_candles([(100, 102, 98, 101)] * 8, freq="15min")
    assert (atr(df) > 0).all()
    h = resample(df, 60)
    assert len(h) == 2 and h["high"].iloc[0] == 102 and h["volume"].iloc[0] == 400


def test_fvg_detected_and_dropped_when_filled():
    rows = [(10, 11, 9, 10.5), (10.5, 12, 10.4, 11.8), (11.8, 14, 11.5, 13.5), (13.5, 14, 13, 13.8)]
    f = find_fvgs(make_candles(rows))
    assert f and f[0]["kind"] == "bull" and (f[0]["low"], f[0]["high"]) == (11, 11.5)
    filled = rows + [(13.8, 13.9, 10.5, 11.0)]
    assert find_fvgs(make_candles(filled)) == []


# ---------------------------------------------------------------- liquidity
def test_manual_level_sweep_above_gives_short_bias(cfg):
    cfg["liquidity"]["manual_levels"] = [{"price": 100.0, "strength": 1.0}]
    rows = flat_rows(60) + [(98, 101.0, 97.5, 98.2)]     # wick through 100, close back below
    rep = LiquidityAgent(cfg).analyze(make_snap(make_candles(rows)))
    assert rep.details["sweep"]["direction"] == -1 and rep.bias < -0.4
    assert rep.details["sweep"]["extreme"] == pytest.approx(101.0)


def test_manual_level_sweep_below_gives_long_bias(cfg):
    cfg["liquidity"]["manual_levels"] = [{"price": 95.0, "strength": 1.0}]
    rows = flat_rows(60) + [(96, 96.5, 94.0, 96.2)]
    rep = LiquidityAgent(cfg).analyze(make_snap(make_candles(rows)))
    assert rep.details["sweep"]["direction"] == 1 and rep.bias > 0.4


def test_closing_beyond_the_level_is_a_breakout_not_a_sweep(cfg):
    cfg["liquidity"]["manual_levels"] = [{"price": 100.0, "strength": 1.0}]
    rows = flat_rows(60) + [(98, 101.5, 97.5, 101.2)]
    rep = LiquidityAgent(cfg).analyze(make_snap(make_candles(rows)))
    assert rep.details["sweep"] is None


def test_modelled_clusters_are_consumed_once_price_trades_through(cfg):
    ag = LiquidityAgent(cfg)
    rng = np.random.default_rng(5)
    c = 100 + np.cumsum(rng.normal(0, 0.3, 300))
    df = make_candles([(x, x + 0.3, x - 0.3, x) for x in c])
    cl = ag.build_clusters(df, None, float(c[-1]))
    assert cl and all(0 < x["strength"] <= 1 for x in cl)
    for x in cl:
        # a surviving cluster must NOT have been traded through after most of its creation bars
        assert x["side"] in ("above", "below")


# ---------------------------------------------------------------- order flow
def test_buying_pressure_gives_positive_bias(cfg):
    df = make_candles([(100 + i * 0.05, 100.3 + i * 0.05, 99.8 + i * 0.05, 100.2 + i * 0.05) for i in range(120)],
                      buy=80.0)
    assert OrderFlowAgent(cfg).analyze(make_snap(df)).bias > 0.2


def test_selling_pressure_gives_negative_bias(cfg):
    df = make_candles([(100 - i * 0.05, 100.3 - i * 0.05, 99.8 - i * 0.05, 99.8 - i * 0.05) for i in range(120)],
                      buy=20.0)
    assert OrderFlowAgent(cfg).analyze(make_snap(df)).bias < -0.2


# ---------------------------------------------------------------- structure
def test_uptrend_gives_positive_structure_bias(cfg):
    rng = np.random.default_rng(3)
    c = 100 + np.arange(300) * 0.08 + rng.normal(0, 0.25, 300)
    df = make_candles([(x, x + 0.4, x - 0.4, x) for x in c])
    assert StructureAgent(cfg).analyze(make_snap(df)).bias > 0


# ---------------------------------------------------------------- news
def test_calendar_parsing_filters_country_and_impact():
    items = [{"title": "FOMC Statement", "country": "USD", "date": "2026-11-05T14:00:00-05:00", "impact": "High"},
             {"title": "Retail Sales", "country": "USD", "date": "2026-11-05T08:30:00-05:00", "impact": "Medium"},
             {"title": "ECB Rate", "country": "EUR", "date": "2026-11-05T13:15:00+01:00", "impact": "High"},
             {"title": "broken"}]
    out = NewsAgent.parse_calendar(items, ["USD"], ["High"], 30, 60)
    assert len(out) == 1 and out[0]["time"].startswith("2026-11-05T19:00:00")   # converted to UTC


def test_blackout_window_vetoes(cfg):
    cfg["news"]["blackouts"] = [{"time": "2026-01-05T10:00:00Z", "before_min": 30, "after_min": 60, "label": "CPI"}]
    ag = NewsAgent(cfg, offline=True)
    inside = make_snap(make_candles(flat_rows(10), start="2026-01-05 08:00"))     # snapshot time 10:30
    r = ag.analyze(inside)
    assert r.veto and "CPI" in r.summary
    outside = make_snap(make_candles(flat_rows(10), start="2026-01-05 14:00"))
    assert not ag.analyze(outside).veto


# ---------------------------------------------------------------- derivatives
from agents.derivatives_agent import DerivativesAgent  # noqa: E402
from agents.indicators_agent import IndicatorsAgent  # noqa: E402


def oi_frame(df, values):
    return pd.DataFrame({"oi": values}, index=df.index)


def test_crowded_longs_are_bearish_and_crowded_shorts_bullish(cfg):
    df = make_candles([(100, 100.3, 99.8, 100.1)] * 80)
    ag = DerivativesAgent(cfg)
    assert ag.analyze(make_snap(df, funding=0.001)).bias < -0.3
    assert ag.analyze(make_snap(df, funding=-0.001)).bias > 0.3


def test_no_derivatives_data_means_no_opinion(cfg):
    r = DerivativesAgent(cfg).analyze(make_snap(make_candles([(100, 101, 99, 100)] * 80)))
    assert r.bias == 0 and r.confidence == 0


def test_open_interest_regimes(cfg):
    n = 80
    up = make_candles([(100 + i * 0.1, 100.3 + i * 0.1, 99.8 + i * 0.1, 100.1 + i * 0.1) for i in range(n)])
    down = make_candles([(120 - i * 0.1, 120.3 - i * 0.1, 119.8 - i * 0.1, 119.9 - i * 0.1) for i in range(n)])
    rising, falling = np.linspace(1000, 1100, n), np.linspace(1100, 1000, n)
    ag = DerivativesAgent(cfg)
    assert ag.analyze(make_snap(up, oi=oi_frame(up, rising))).bias > 0.2        # new longs
    assert ag.analyze(make_snap(up, oi=oi_frame(up, falling))).bias < 0         # short covering: weak rally
    assert ag.analyze(make_snap(down, oi=oi_frame(down, rising))).bias < -0.2   # new shorts
    assert ag.analyze(make_snap(down, oi=oi_frame(down, falling))).bias > 0     # long liquidation


# ---------------------------------------------------------------- indicators
def test_indicator_values_are_sane():
    from core.indicators import bollinger, macd, rsi
    c = pd.Series(np.linspace(100, 130, 120))
    assert rsi(c).iloc[-1] > 90                                  # relentless rise
    assert rsi(c[::-1].reset_index(drop=True)).iloc[-1] < 10
    lo, mid, hi = bollinger(c)
    assert (lo.dropna() < mid.dropna()).all() and (hi.dropna() > mid.dropna()).all()
    line, sig, hist = macd(c)
    assert line.iloc[-1] > 0


def test_indicator_agent_follows_the_trend(cfg):
    rng = np.random.default_rng(8)
    up = 100 + np.arange(400) * 0.1 + rng.normal(0, 0.2, 400)
    r_up = IndicatorsAgent(cfg).analyze(make_snap(make_candles([(x, x + .4, x - .4, x) for x in up])))
    dn = 140 - np.arange(400) * 0.1 + rng.normal(0, 0.2, 400)
    r_dn = IndicatorsAgent(cfg).analyze(make_snap(make_candles([(x, x + .4, x - .4, x) for x in dn])))
    assert r_up.bias > 0.1 and r_dn.bias < -0.1 and -1 <= r_up.bias <= 1


def test_replaying_the_past_hides_todays_funding(cfg):
    df = make_candles([(100, 100.3, 99.8, 100.1)] * 80)
    snap = make_snap(df, funding=0.002, ls=2.0)
    past = snap.until(df.index[40])
    assert past.funding is None and past.long_short_ratio is None
    assert snap.until(snap.ts).funding == 0.002


# ---------------------------------------------------------------- multi-timeframe
from agents.manager_agent import ManagerAgent  # noqa: E402
from agents.mtf_agent import MultiTimeframeAgent  # noqa: E402
from agents.risk_agent import RiskAgent  # noqa: E402
from core.models import RiskState  # noqa: E402


def trending(n, slope, seed=0, freq="15min"):
    rng = np.random.default_rng(seed)
    c = 200 + np.arange(n) * slope + rng.normal(0, abs(slope) * 2 + 0.05, n)
    return make_candles([(x, x + 0.3, x - 0.3, x) for x in c], freq=freq)


def mtf_snap(slopes):
    candles = {tf: trending(150, sl, i, freq=f) for i, (tf, sl, f) in enumerate(
        [("15m", slopes[0], "15min"), ("1h", slopes[1], "1h"), ("4h", slopes[2], "4h"), ("1d", slopes[3], "1D")])}
    base = candles["15m"]
    snap = make_snap(base, candles["1h"])
    snap.candles.update(candles)
    return snap


def test_all_timeframes_up_gives_full_alignment(cfg):
    r = MultiTimeframeAgent(cfg).analyze(mtf_snap([0.1, 0.3, 0.8, 2.0]))
    assert r.bias > 0.6 and r.details["alignment"] == pytest.approx(1.0) and r.details["htf_bias"] > 0.6


def test_conflicting_timeframes_lower_alignment_and_confidence(cfg):
    ag = MultiTimeframeAgent(cfg)
    agree, mixed = ag.analyze(mtf_snap([0.1, 0.3, 0.8, 2.0])), ag.analyze(mtf_snap([-0.1, -0.3, 0.8, 2.0]))
    assert mixed.details["alignment"] < agree.details["alignment"] and mixed.confidence < agree.confidence


def test_missing_or_short_timeframes_are_skipped(cfg):
    snap = make_snap(trending(150, 0.1))
    r = MultiTimeframeAgent(cfg).analyze(snap)
    assert set(r.details["per_tf"]) == {"15m", "1h"} or set(r.details["per_tf"]) == {"15m"}
    assert "not enough data" in r.summary


def test_manager_blocks_counter_trend_trades(cfg):
    ag_rep = {"liquidity": AgentReport("liquidity", -0.9, 0.9, "sweep", {"clusters": [], "atr": 1.0}),
              "structure": AgentReport("structure", -0.9, 0.9, "x"),
              "orderflow": AgentReport("orderflow", -0.9, 0.9, "x"),
              "mtf": AgentReport("mtf", 0.8, 0.9, "all up", {"htf_bias": 0.8, "per_tf": {}})}
    snap = make_snap(make_candles([(100, 101, 99, 100)] * 80))
    mgr = ManagerAgent(cfg, RiskAgent(cfg))
    plan = mgr.decide(snap, ag_rep, RiskState(), snap.ts)
    assert plan.side == "NONE" and "higher-timeframe" in plan.reasons[0]
    cfg["mtf"]["block_against"] = 0
    assert ManagerAgent(cfg, RiskAgent(cfg)).decide(snap, ag_rep, RiskState(), snap.ts).side == "SHORT"
