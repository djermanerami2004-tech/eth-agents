"""levels.txt, session agent / session_sweep strategy, strategy leaderboard."""
import os
import time
from types import SimpleNamespace

import pandas as pd

from agents.liquidity_agent import LiquidityAgent
from agents.session_agent import SessionAgent
from core.indicators import atr
from core.levels import load_levels, parse_levels, save_levels_text
from core.metrics import leaderboard, verdict
from core.models import AgentReport
from strategies.session_sweep import SessionSweep
from tests.conftest import make_candles, make_snap


# ---------------------------------------------------------------- levels.txt
def test_parse_levels_handles_words_comments_and_junk():
    txt = "# header\n3850 strong\n3720, 0.6   # note\n3580 weak\nhello world\n\n3500\n-5\n"
    got = parse_levels(txt)
    assert [(x["price"], x["strength"]) for x in got] == [(3850.0, 1.0), (3720.0, 0.6), (3580.0, 0.4), (3500.0, 1.0)]


def test_levels_file_is_hot_reloaded_and_overrides_the_model(cfg, tmp_path):
    f = tmp_path / "lv.txt"
    cfg["liquidity"]["levels_file"] = str(f)
    df = make_candles([(100, 101, 99, 100)] * 400)
    agent = LiquidityAgent(cfg)
    snap = make_snap(df)
    assert agent._manual(100.0) == []                               # no file yet -> modelled estimate is used
    f.write_text("103 strong\n97 0.5\n")
    rep = agent.analyze(snap)
    assert {c["price"] for c in rep.details["clusters"]} == {103.0, 97.0} and "manual" in rep.summary
    f.write_text("104 strong\n")                                    # edit the file -> picked up without a restart
    os.utime(f, (time.time() + 5, time.time() + 5))
    assert {c["price"] for c in agent.analyze(snap).details["clusters"]} == {104.0}


def test_stale_levels_far_from_price_are_ignored(cfg, tmp_path):
    f = tmp_path / "lv.txt"
    f.write_text("5000 strong\n")                                   # 50x away from a price of 100
    cfg["liquidity"]["levels_file"] = str(f)
    assert LiquidityAgent(cfg)._manual(100.0) == []


def test_save_levels_text_roundtrip(tmp_path):
    f = tmp_path / "lv.txt"
    assert save_levels_text(str(f), "3000 strong\nnonsense\n2900 0.5") == 2
    assert [x["price"] for x in load_levels(str(f))] == [3000.0, 2900.0]
    assert load_levels(str(tmp_path / "missing.txt")) == []


# ---------------------------------------------------------------- session agent
def day_frame(sweep: str | None):
    """Previous day 05..22 UTC trading 100..110, today's Asia session, then London open. Optionally sweep PDH/PDL."""
    rows = []
    for i in range(96):                                  # day 1: 00:00 -> 23:45, range 95..110 (high 110 at 10:00)
        h = 110 if i == 40 else 108
        lo = 95 if i == 70 else 98
        rows.append((102, h, lo, 102))
    for i in range(28):                                  # day 2: 00:00 -> 06:45 quiet Asia
        rows.append((102, 104, 100, 102))
    for i in range(12):                                  # 07:00 -> 09:45
        rows.append((102, 104, 100, 102))
    if sweep == "pdh":                                   # wick above PDH 110 then close back
        rows[-2] = (103, 111.0, 102, 104)
        rows[-1] = (104, 105, 102, 103)
    if sweep == "pdl":
        rows[-2] = (101, 102, 94.0, 100)
        rows[-1] = (100, 102, 99, 101)
    return make_candles(rows, start="2026-03-02 00:00")


def test_session_levels_include_previous_day_and_asia(cfg):
    df = day_frame(None)
    rep = SessionAgent(cfg).analyze(make_snap(df))
    names = {x["name"] for x in rep.details["levels"]}
    assert {"PDH", "PDL", "Asia high", "Asia low"} <= names
    pdh = next(x for x in rep.details["levels"] if x["name"] == "PDH")
    assert pdh["price"] == 110.0
    assert rep.details["sweep"] is None and abs(rep.bias) < 1e-9


def test_session_agent_detects_pdh_and_pdl_sweeps(cfg):
    up = SessionAgent(cfg).analyze(make_snap(day_frame("pdh")))
    assert up.details["sweep"]["name"] == "PDH" and up.bias < 0
    dn = SessionAgent(cfg).analyze(make_snap(day_frame("pdl")))
    assert dn.details["sweep"]["name"] == "PDL" and dn.bias > 0


def test_closing_beyond_the_level_is_a_breakout_not_a_sweep(cfg):
    df = day_frame(None)
    rows = df[["open", "high", "low", "close"]].values.tolist()
    rows[-2] = (104, 112, 103, 111)                      # closes ABOVE PDH
    rows[-1] = (111, 113, 110.5, 112)
    df2 = make_candles(rows, start="2026-03-02 00:00")
    assert SessionAgent(cfg).analyze(make_snap(df2)).details["sweep"] is None


def test_session_sweep_strategy_follows_the_agent(cfg):
    df = day_frame("pdh")
    rep = {"session": SessionAgent(cfg).analyze(make_snap(df))}
    ctx = SimpleNamespace(price=float(df["close"].iloc[-1]), atr=float(atr(df).iloc[-1]), df=df, score=0.0)
    s = SessionSweep(cfg).detect(make_snap(df), rep, ctx)
    assert s.side == -1 and s.name == "session_sweep" and s.stop_ref == 111.0
    assert SessionSweep(cfg).detect(make_snap(df), {"session": AgentReport("session", 0, 0, "", {"sweep": None})}, ctx) is None


def test_session_agent_ignores_future_candles(cfg):
    full = day_frame("pdh")
    snap_a = make_snap(full.iloc[:-1])
    future = full.copy()
    future.iloc[-1, future.columns.get_loc("high")] = 999.0
    snap_b = make_snap(future.iloc[:-1])
    ra, rb = SessionAgent(cfg).analyze(snap_a), SessionAgent(cfg).analyze(snap_b)
    assert ra.bias == rb.bias and ra.details["levels"] == rb.details["levels"]


# ---------------------------------------------------------------- leaderboard
def test_verdict_is_cautious_with_few_trades():
    assert verdict(5, 2.0, 5.0).startswith("too early")
    assert verdict(40, 0.3, 1.6).startswith("promising")
    assert verdict(40, -0.2, 0.7).startswith("losing")
    assert verdict(40, 0.02, 1.0) == "no clear edge"


def test_leaderboard_ranks_by_average_r():
    t = pd.DataFrame({"strategy": ["a"] * 3 + ["b"] * 3, "r": [1.0, 1.0, -0.5, -1.0, -1.0, 0.2],
                      "pnl_usd": [10, 10, -5, -10, -10, 2]})
    lb = leaderboard(t)
    assert list(lb["strategy"]) == ["a", "b"] and "verdict" in lb
    assert leaderboard(t.iloc[0:0]).empty


# ---------------------------------------------------------------- agent popups: setups + score breakdown
def test_contributions_add_up_to_the_composite_score(cfg):
    from agents.manager_agent import ManagerAgent
    from agents.risk_agent import RiskAgent
    from core.breakdown import contributions
    from core.models import RiskState
    df = day_frame("pdh")
    snap = make_snap(df)
    reports = {"session": SessionAgent(cfg).analyze(snap),
               "orderbook": AgentReport("orderbook", 0.0, 0.0, "none", {"no_data": True}),
               "news": AgentReport("news", -0.3, 0.5, "", {})}
    plan = ManagerAgent(cfg, RiskAgent(cfg)).decide(snap, reports, RiskState(), snap.ts)
    br = contributions(cfg["weights"], reports)
    assert abs(sum(b["contribution"] for b in br.values()) - plan.score) < 0.002
    assert br["orderbook"]["used"] is False and br["orderbook"]["share"] == 0.0


def test_plan_lists_setups_that_did_not_reach_the_score(cfg):
    """A session sweep exists, but the other agents say nothing: it must still be listed, flagged as not taken."""
    from agents.manager_agent import ManagerAgent
    from agents.risk_agent import RiskAgent
    from core.models import RiskState
    cfg["strategies"]["session_sweep"]["min_score"] = 0.9           # make it impossible to reach
    df = day_frame("pdh")
    snap = make_snap(df)
    reports = {"session": SessionAgent(cfg).analyze(snap)}
    plan = ManagerAgent(cfg, RiskAgent(cfg)).decide(snap, reports, RiskState(), snap.ts)
    assert plan.side == "NONE"
    s = next(x for x in plan.setups if x["strategy"] == "session_sweep")
    assert s["status"] == "rejected" and "below" in s["reason"] and s["agents"] == ["session", "liquidations"]
    assert s["side"] == "SHORT" and s["stop"] > s["entry"] > s["tp1"] > s["tp2"]


def test_dashboard_password_gate(monkeypatch):
    from streamlit.testing.v1 import AppTest
    monkeypatch.setenv("DASHBOARD_PASSWORD", "s3cret")
    at = AppTest.from_file(str(__import__("pathlib").Path(__file__).resolve().parent.parent / "dashboard.py"), default_timeout=60).run()
    assert len(at.text_input) == 1 and not at.tabs                     # only the login form, nothing else
    at.text_input[0].set_value("wrong")
    at.button[0].click().run()
    assert any("Wrong password" in e.value for e in at.error) and not at.tabs
    at.text_input[0].set_value("s3cret")
    at.button[0].click().run()
    assert at.session_state["authed"] is True
