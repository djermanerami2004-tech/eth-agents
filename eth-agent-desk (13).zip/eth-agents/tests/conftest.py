import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

import os  # noqa: E402
os.environ["ETH_DESK_NO_STREAM"] = "1"      # tests never open a real websocket
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.config import load_config  # noqa: E402
from core.models import MarketSnapshot  # noqa: E402


@pytest.fixture
def cfg(tmp_path):
    c = load_config()
    c["journal"]["path"] = str(tmp_path / "journal.db")
    c["backtest"]["spread_usd"] = 0.0      # clean numbers in unit tests; costs have their own test
    c["backtest"]["slippage_usd"] = 0.0
    c["news"]["calendar"]["enabled"] = False
    c["llm"]["enabled"] = False
    c["llm"]["review"] = False
    return c


def make_candles(rows, start="2026-01-05 08:00", freq="15min", vol=100.0, buy=50.0) -> pd.DataFrame:
    """rows = [(open, high, low, close), ...] -> candle frame with UTC index."""
    idx = pd.date_range(start, periods=len(rows), freq=freq, tz="UTC")
    a = np.array(rows, dtype=float)
    return pd.DataFrame({"open": a[:, 0], "high": a[:, 1], "low": a[:, 2], "close": a[:, 3],
                         "volume": vol, "taker_buy_base": buy}, index=idx)


def make_snap(df15: pd.DataFrame, df1h: pd.DataFrame | None = None, **kw) -> MarketSnapshot:
    if df1h is None:
        from core.indicators import resample
        df1h = resample(df15, 60)
    ts = df15.index[-1] + pd.Timedelta(minutes=15)
    return MarketSnapshot("ETHUSDT", float(df15["close"].iloc[-1]), {"15m": df15, "1h": df1h},
                          kw.get("oi"), kw.get("funding"), kw.get("ls"), "test", ts)


@pytest.fixture
def snap_factory():
    return make_snap
