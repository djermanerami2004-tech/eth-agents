import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from core.backtest import run_backtest
from core.charts import build_chart
from core.models import MarketSnapshot, tf_minutes
from core.pipeline import TradingSystem

ROOT = Path(__file__).resolve().parent.parent


def system(cfg, seed=7):
    return TradingSystem(cfg, demo=True, seed=seed, journal_path=":memory:")


def test_demo_data_does_not_depend_on_the_requested_length(cfg):
    a = system(cfg).data.snapshot(limit=300).candles["15m"]
    b = system(cfg).data.snapshot(limit=900).candles["15m"]
    common = a.index.intersection(b.index)
    assert len(common) > 100
    np.testing.assert_allclose(a.loc[common, "close"].values, b.loc[common, "close"].values)


def test_the_future_cannot_leak_into_a_decision(cfg):
    """Replace every candle that was not yet closed at time t with garbage: the decision must not change."""
    s = system(cfg)
    full = s.data.snapshot(limit=900)
    idx = full.candles["15m"].index
    rng = np.random.default_rng(0)
    checked = 0
    for k in (400, 520, 640, 760):
        t = idx[k] + pd.Timedelta(minutes=15)
        _, rep_a, plan_a = s.replay(full, t)
        def corrupt(frames):
            out = {}
            for tf, df in frames.items():
                df = df.copy()
                fut = (df.index + pd.Timedelta(minutes=tf_minutes(tf))) > t
                for col in ("open", "high", "low", "close"):
                    df.loc[fut, col] = df.loc[fut, col] * rng.uniform(0.3, 3.0, fut.sum())
                df.loc[fut, "volume"] = 1e9
                df.loc[fut, "taker_buy_base"] = 1e9
                out[tf] = df
            return out
        bad, bad_ref = corrupt(full.candles), corrupt(full.ref)       # the BTC candles must not leak the future either
        oi = full.oi.copy() if full.oi is not None else None
        if oi is not None:
            oi.loc[oi.index > t, "oi"] = 9e12
        corrupted = MarketSnapshot(full.symbol, full.price, bad, oi, full.funding, full.long_short_ratio,
                                   full.source, full.ts, None, bad_ref)
        snap_b, rep_b, plan_b = s.replay(corrupted, t)
        assert plan_b.to_dict() == plan_a.to_dict()
        for name in rep_a:
            assert rep_a[name].bias == pytest.approx(rep_b[name].bias)
        checked += 1
    assert checked == 4


def test_every_plan_has_sane_geometry(cfg):
    """Regression: TP2 used to land closer than TP1 when only one liquidity cluster qualified."""
    n_plans = 0
    for seed in (1, 2, 3):
        s = system(cfg, seed)
        full = s.data.snapshot(limit=700)
        step = pd.Timedelta(minutes=15)
        for t in full.candles["15m"].index[-250:]:
            _, _, p = s.replay(full, t + step)
            if p.side == "NONE":
                continue
            n_plans += 1
            d = 1 if p.side == "LONG" else -1
            assert (p.stop - p.entry) * d < 0, "stop must be on the losing side"
            assert 0 < (p.tp1 - p.entry) * d < (p.tp2 - p.entry) * d, f"targets out of order: {p}"
    assert n_plans > 10


def test_approved_plans_respect_risk_limits(cfg):
    s = system(cfg, 4)
    full = s.data.snapshot(limit=700)
    for t in full.candles["15m"].index[-250:]:
        _, _, p = s.replay(full, t + pd.Timedelta(minutes=15))
        if p.approved:
            assert p.risk_usd <= cfg["account"]["size"] * cfg["risk"]["risk_per_trade_pct"] / 100 + 1
            assert p.size * p.entry <= cfg["account"]["size"] * cfg["account"]["max_leverage"] + 1
            assert 7 <= int(p.ts[11:13]) < 20
            assert p.rr >= cfg["risk"]["min_rr"]


def test_backtest_runs_and_reports(cfg):
    s = system(cfg)
    out = run_backtest(cfg, s.data.snapshot(limit=900), bars=400)
    sm = out["summary"]
    assert {"trades", "win_rate", "avg_r", "profit_factor", "max_dd_usd"} <= set(sm)
    assert out["evaluations"] > 0
    if sm["trades"]:
        assert set(out["trades"]["exit"]) <= {"stop", "TP1", "TP2", "break-even stop", "time stop"}


def test_backtest_costs_hurt(cfg):
    s = system(cfg, 3)
    full = s.data.snapshot(limit=900)
    free = run_backtest(cfg, full, bars=500)["summary"]
    cfg["backtest"]["spread_usd"], cfg["backtest"]["slippage_usd"] = 2.0, 1.0
    costly = run_backtest(cfg, full, bars=500)["summary"]
    assert free["trades"] == costly["trades"] > 0
    assert costly["total_pnl"] < free["total_pnl"]


def test_no_phantom_edge_on_a_random_market(cfg):
    """On drift-free random prices the desk must not make real money. A pooled average above +0.5R over
    100+ trades would mean the backtest is leaking the future (see README: Validation)."""
    cfg["backtest"]["spread_usd"], cfg["backtest"]["slippage_usd"] = 1.0, 0.3
    rs = []
    for seed in range(11, 17):
        s = system(cfg, seed)
        out = run_backtest(cfg, s.data.snapshot(limit=1000), bars=800)
        rs += out["trades"]["r"].tolist() if not out["trades"].empty else []
    assert len(rs) >= 30
    assert np.mean(rs) < 0.5


def test_full_cycle_records_and_settles_paper_trades(cfg):
    cfg["journal"]["paper_mode"] = True
    s = system(cfg)
    full = s.data.snapshot(limit=900)
    step = pd.Timedelta(minutes=15)
    ids = 0
    for t in full.candles["15m"].index[-300:]:
        snap = full.until(t + step)
        s.journal.settle(snap.candles["15m"], 15, snap.ts)
        reports, plan = s.analyze(snap, use_llm=False)
        if plan.approved and not s.journal.recent_signal(plan.side, 60, snap.ts):
            s.journal.record_signal(plan, reports)
            ids += 1
    st = s.journal.stats()
    assert ids > 0 and st["trades"] > 0 and st["signals"] == ids


def test_chart_builds_for_a_trade_and_for_no_trade(cfg):
    s = system(cfg, 4)
    full = s.data.snapshot(limit=700)
    shown = set()
    for t in full.candles["15m"].index[-250:]:
        snap, reports, plan = s.replay(full, t + pd.Timedelta(minutes=15))
        key = plan.side == "NONE"
        if key not in shown:
            fig = build_chart(snap, reports, plan, "15m", "Africa/Algiers")
            assert len(fig.data) >= 2
            shown.add(key)
    assert shown == {True, False}


def run_cli(*args):
    return subprocess.run([sys.executable, str(ROOT / "main.py"), *args], capture_output=True, text=True,
                          cwd=ROOT, timeout=180)


def test_cli_run_scan_and_backtest():
    r = run_cli("run", "--demo", "--no-record")
    assert r.returncode == 0 and "DECISION" in r.stdout
    r = run_cli("scan", "--demo", "--bars", "60", "--history", "400")
    assert r.returncode == 0 and "setups in the last 60 candles" in r.stdout
    r = run_cli("backtest", "--demo", "--bars", "200", "--history", "500")
    assert r.returncode == 0 and "Backtest on synthetic" in r.stdout


def test_cli_check_never_crashes():
    r = run_cli("check")
    assert r.returncode == 0 and "setup check" in r.stdout


def test_dashboard_renders_without_errors():
    st_testing = pytest.importorskip("streamlit.testing.v1")
    at = st_testing.AppTest.from_file(str(ROOT / "dashboard.py"), default_timeout=240).run()
    assert not at.exception, [e.value for e in at.exception]
    assert len(at.tabs) == 5
