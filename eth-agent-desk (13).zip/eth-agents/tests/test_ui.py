"""The dashboard's HTML blocks: icons for every agent, no raw <svg> (Streamlit's sanitiser would drop it), text escaped."""
import base64
import re

from core import ui

AGENTS = ["liquidity", "structure", "orderflow", "derivatives", "indicators", "mtf", "patterns", "divergence", "regime", "volume_profile", "btc", "session", "orderbook", "whales", "options", "liquidations", "news"]


def decode(html: str) -> list[str]:
    return [base64.b64decode(m).decode() for m in re.findall(r"data:image/svg\+xml;base64,([A-Za-z0-9+/=]+)", html)]


def test_every_agent_has_its_own_icon():
    seen = set()
    for a in AGENTS:
        assert a in ui.ICONS
        html = ui.icon_tile(a, -0.5)
        svgs = decode(html)
        assert len(svgs) == 1 and svgs[0].startswith("<svg") and "xmlns" in svgs[0]
        seen.add(tuple(ui.ICONS[a]))
    assert len(seen) == len(AGENTS)


def test_pictures_are_images_not_inline_svg():
    from types import SimpleNamespace
    plan = SimpleNamespace(side="NONE", reasons=["No trade: composite +0.09 is below 0.22"], approved=False, vetoes=[])
    blocks = [ui.header_html(True, "binance-live", "12:00 UTC", False), ui.gauge_html(-0.21, 0.22), ui.decision_html(plan, -0.21, 0.22),
              ui.rules_html(300, 400, 900, 1000, 1, 3, 0, 1, 0, 2, [], 0, 0), ui.rules_html(0, 400, 900, 1000, 1, 3, 0, 1, 0, 2, ["daily loss limit"], -400, 0),
              ui.agent_card_html("liquidity", "Liquidity", -0.3, 0.6, 0.24, "summary", 1)]
    for b in blocks:
        assert "<svg" not in b
    assert decode(blocks[1])                                          # the gauge is an image


def test_dynamic_text_is_escaped():
    html = ui.agent_card_html("news", "News", 0.0, 0.2, None, "<script>alert(1)</script>", 0)
    assert "<script>" not in html and "&lt;script&gt;" in html
    s = {"status": "rejected", "side": "LONG", "strategy": "<b>x</b>", "entry_type": "LIMIT", "entry": 100, "stop": 99, "tp1": 102, "tp2": 103,
         "rr": 2.0, "quality": 0.5, "agents": ["liquidity"], "note": "n", "reason": "r"}
    assert "<b>x</b>" not in ui.setup_html(s)


def test_gauge_needle_follows_the_score():
    short, long_ = decode(ui.gauge_html(-0.8, 0.22))[0], decode(ui.gauge_html(0.8, 0.22))[0]
    assert "rotate(-72.0 100 100)" in short and "rotate(72.0 100 100)" in long_
