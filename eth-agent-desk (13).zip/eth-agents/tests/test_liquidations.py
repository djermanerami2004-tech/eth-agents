import json
import time

import pandas as pd

from agents.liquidation_agent import LiquidationAgent
from core.liqstream import Collector, LiqStore, parse_force_order
from core.models import MarketSnapshot

MSG = {"e": "forceOrder", "E": 1_700_000_000_500,
       "o": {"s": "ETHUSDT", "S": "SELL", "o": "LIMIT", "f": "IOC", "q": "10", "p": "3000", "ap": "2990", "X": "FILLED",
             "l": "10", "z": "10", "T": 1_700_000_000_400}}


def snap(ts=None):
    return MarketSnapshot("ETHUSDT", 3000.0, {}, None, None, None, "test", ts or pd.Timestamp.now(tz="UTC"))


def agent_with(cfg, events, first_min_ago=180, beat_ago=5):
    cfg = {**cfg, "liquidations": {**cfg["liquidations"], "db": ":memory:"}}
    store = LiqStore(":memory:")
    now = time.time()
    store.set_meta("first_run", now - first_min_ago * 60)
    if beat_ago is not None:
        store.set_meta("heartbeat", now - beat_ago)
    for sec_ago, side, usd in events:
        store.add("ETHUSDT", {"ts_ms": int((now - sec_ago) * 1000), "side": side, "price": 3000.0, "qty": usd / 3000, "usd": usd})
    return LiquidationAgent(cfg, store)


def test_parse_sell_is_a_liquidated_long_and_uses_average_price():
    ev = parse_force_order(json.dumps(MSG))
    assert ev["side"] == "long_liq" and ev["ts_ms"] == 1_700_000_000_400
    assert ev["price"] == 2990.0 and ev["qty"] == 10.0 and ev["usd"] == 29900.0


def test_parse_buy_is_a_liquidated_short_and_wrapper_and_junk():
    m = json.loads(json.dumps(MSG)); m["o"]["S"] = "BUY"
    assert parse_force_order(m)["side"] == "short_liq"
    assert parse_force_order({"stream": "x", "data": m})["side"] == "short_liq"
    assert parse_force_order("not json") is None
    assert parse_force_order({"e": "trade"}) is None
    assert parse_force_order({"e": "forceOrder", "o": {"S": "BUY"}}) is None


def test_store_ignores_duplicates_and_filters_by_time():
    s = LiqStore(":memory:")
    ev = parse_force_order(MSG)
    s.add("ETHUSDT", ev); s.add("ETHUSDT", ev)
    assert len(s.since("ETHUSDT", 0)) == 1
    assert s.since("ETHUSDT", ev["ts_ms"] + 1) == []
    assert s.since("BTCUSDT", 0) == []


def test_collector_handle_stores_events_and_beats(cfg):
    cfg["liquidations"]["db"] = ":memory:"
    c = Collector(cfg)
    assert c.handle(json.dumps(MSG)) is True
    assert c.handle("junk") is False
    assert len(c.store.since("ETHUSDT", 0)) == 1
    assert c.store.get_meta("heartbeat") is not None and c.store.get_meta("first_run") is not None


def test_not_running_warming_up_and_replay_are_left_out(cfg):
    r = agent_with(cfg, [], beat_ago=None).analyze(snap())
    assert r.details["no_data"] and "not running" in r.summary
    r = agent_with(cfg, [], beat_ago=900).analyze(snap())
    assert r.details["no_data"] and "not running" in r.summary
    r = agent_with(cfg, [], first_min_ago=5).analyze(snap())
    assert r.details["no_data"] and "collecting" in r.summary
    past = snap(pd.Timestamp.now(tz="UTC") - pd.Timedelta(days=3))
    r = agent_with(cfg, [(10, "long_liq", 9e6)]).analyze(past)
    assert r.details["no_data"] and "backtest" in r.summary


def test_quiet_and_mixed_markets_have_no_opinion(cfg):
    quiet = agent_with(cfg, [(60, "long_liq", 200_000)]).analyze(snap())
    assert quiet.details["no_data"] and quiet.details["phase"] == "quiet" and quiet.bias == 0
    mixed = agent_with(cfg, [(60, "long_liq", 2_000_000), (50, "short_liq", 1_800_000)]).analyze(snap())
    assert mixed.details["no_data"] and mixed.details["phase"] == "mixed"


def test_running_long_liquidation_cascade_leans_short(cfg):
    ev = [(m * 60 + 10, "long_liq", 1_000_000) for m in range(0, 6)]       # still heavy in the last minutes
    r = agent_with(cfg, ev).analyze(snap())
    assert r.details["phase"] == "cascade" and not r.details.get("no_data")
    assert r.bias < 0 and 0 < r.confidence <= 1


def test_spent_long_liquidation_flush_leans_long(cfg):
    ev = [(m * 60 + 10, "long_liq", 1_500_000) for m in range(6, 11)]      # big a few minutes ago, nothing since
    r = agent_with(cfg, ev).analyze(snap())
    assert r.details["phase"] == "exhausted"
    assert r.bias > 0.3


def test_spent_short_squeeze_leans_short_and_running_one_leans_long(cfg):
    spent = agent_with(cfg, [(m * 60 + 10, "short_liq", 1_500_000) for m in range(6, 11)]).analyze(snap())
    assert spent.details["phase"] == "exhausted" and spent.bias < -0.3
    running = agent_with(cfg, [(m * 60 + 10, "short_liq", 1_000_000) for m in range(0, 6)]).analyze(snap())
    assert running.details["phase"] == "cascade" and running.bias > 0


def test_burst_needs_to_beat_the_normal_level(cfg):
    # a busy market: $2M every 15 minutes for hours. The same $2M now is normal, not a burst.
    hist = [(m * 60 + 30, "long_liq", 2_000_000) for m in range(20, 170, 15)]
    now_burst = [(60, "long_liq", 2_000_000)]
    r = agent_with(cfg, hist + now_burst).analyze(snap())
    assert r.details["no_data"] and r.details["phase"] == "quiet"
    assert r.details["threshold_usd"] > 2_000_000


def test_demo_pipeline_includes_the_agent_as_no_data(cfg):
    from core.pipeline import TradingSystem
    res = TradingSystem(cfg, demo=True, journal_path=":memory:").run_once(record=False)
    assert res.reports["liquidations"].details["no_data"]
    assert "liquidations" in cfg["weights"]


def test_demo_source_is_left_out_even_if_the_stream_runs(cfg):
    a = agent_with(cfg, [(m * 60 + 10, "long_liq", 1_000_000) for m in range(6)])
    s = snap(); s.source = "synthetic(seed=7)"
    r = a.analyze(s)
    assert r.details["no_data"] and "Demo" in r.summary
