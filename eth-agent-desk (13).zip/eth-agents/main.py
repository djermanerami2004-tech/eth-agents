#!/usr/bin/env python3
"""ETH Agent Desk - command line interface.

  python main.py check                      test your setup (internet, Binance, calendar, Telegram, Claude key)
  python main.py run --demo                 one full cycle on synthetic data (works offline)
  python main.py run                        one full cycle on live Binance data
  python main.py loop --every 300           repeat every 5 minutes, track paper trades, send Telegram alerts
  python main.py backtest --bars 1500       walk-forward test of the whole agent stack (with trading costs)
  python main.py scan --bars 400            list every moment in the recent past where the desk would have traded
  python main.py journal list|stats|take ID|skip ID|close ID PRICE
  python main.py liqstream                  run the live liquidation listener on its own (the loop starts one anyway)
  python main.py dashboard                  open the visual dashboard in your browser
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

from core.config import load_config
from core.pipeline import TradingSystem

ROOT = Path(__file__).resolve().parent


def _system(args, cfg, **kw) -> TradingSystem:
    return TradingSystem(cfg, demo=args.demo, seed=args.seed, **kw)


def cmd_run(args, cfg):
    system = _system(args, cfg)
    try:
        res = system.run_once(record=not args.no_record, notify=args.notify)
    except RuntimeError as e:
        sys.exit(f"Could not get market data: {e}\nTip: run `python main.py check`, or try `--demo`.")
    print(res.text)
    if args.demo:
        print("\n[demo data is random - it shows how the desk works, not how the strategy performs]")


def cmd_loop(args, cfg):
    system = _system(args, cfg)
    print(f"Desk running every {args.every}s. Ctrl+C to stop.")
    last, fails, alerted = None, 0, False
    beat = ROOT / "data" / "heartbeat"
    beat.parent.mkdir(exist_ok=True)
    while True:
        try:
            res = system.run_once(record=True, notify=True)
            beat.write_text(str(time.time()))                # the Docker health check and `check` read this
            if alerted:
                system.notifier.send("ETH Agent Desk: data is flowing again.")
            fails, alerted = 0, False
            key = (res.plan.side, res.plan.approved, round(res.plan.entry, 1))
            if key != last or args.verbose or res.settled:
                print("\n" + "=" * 70 + "\n" + res.text)
                last = key
            else:
                print(f"[{res.plan.ts[11:16]}] no change ({res.plan.side})")
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"cycle failed: {e}", file=sys.stderr)
            fails += 1
            if fails >= 5 and not alerted:                   # one Telegram message, not one per failed cycle
                alerted = system.notifier.send(f"ETH Agent Desk: {fails} cycles in a row failed ({str(e)[:150]}). "
                                               f"No signals until this is fixed.") or True
        try:
            time.sleep(args.every)
        except KeyboardInterrupt:
            break


def cmd_liqstream(args, cfg):
    """Stand-alone liquidation listener (the loop and the dashboard also start one by themselves)."""
    from core.liqstream import Collector
    try:
        import websocket  # noqa: F401
    except ImportError:
        sys.exit("Missing package. Run: pip install -r requirements.txt")
    col = Collector(cfg)
    col.start()
    print(f"Listening for {cfg['market']['symbol']} liquidations on Binance, saving to {col.store.path}. Ctrl+C to stop.")
    seen = 0
    try:
        while True:
            time.sleep(10)
            now = int(time.time() * 1000)
            evs = col.store.since(cfg["market"]["symbol"], now - 600_000)
            new = [e for e in evs if e["ts_ms"] > seen]
            for e in new:
                print(f"{time.strftime('%H:%M:%S', time.gmtime(e['ts_ms'] / 1000))}  "
                      f"{'LONG liquidated ' if e['side'] == 'long_liq' else 'SHORT liquidated'} {e['price']:.1f}  ${e['usd'] / 1e3:,.0f}k")
            if new:
                seen = new[-1]["ts_ms"]
            if not col.connected:
                print(f"(not connected{': ' + col.last_error if col.last_error else ''} - retrying)")
    except KeyboardInterrupt:
        col.stop()


def cmd_backtest(args, cfg):
    from core.backtest import run_backtest
    system = _system(args, cfg, journal_path=":memory:")
    full = system.data.snapshot(limit=max(args.history, args.bars + 200))
    out = run_backtest(cfg, full, bars=args.bars)
    s, p = out["summary"], out["params"]
    print(f"Backtest on {full.source}, last {args.bars} x {cfg['market']['entry_tf']} candles "
          f"({out['evaluations']} decisions)")
    print(f"Costs: spread ${p.spread_usd}/ETH, slippage ${p.slippage_usd}/ETH on stops | TP1 closes "
          f"{p.tp1_fraction:.0%}, stop to break-even, rest runs to TP2")
    print(f"Trades {s['trades']} | win rate {s['win_rate']:.0%} | avg R {s['avg_r']:+.2f} | "
          f"profit factor {s['profit_factor']:.2f} | total {s['total_r']:+.1f}R (${s['total_pnl']:+.0f}) | "
          f"max drawdown {s['max_dd_r']:.1f}R (${s['max_dd_usd']:.0f}, {s['max_dd_pct']:.1f}%) | "
          f"longest losing streak {s['longest_loss_streak']}")
    if args.demo:
        print("NOTE: demo data is a random walk with NO edge. Results here only prove the code runs.")
    elif s["trades"] < 100:
        print(f"NOTE: only {s['trades']} trades - far too few to say anything about the strategy. "
              f"Use more history and paper trade before trusting it.")
    if not out["trades"].empty:
        bs = out["by_strategy"].copy()
        bs["win_rate"] = (bs["win_rate"] * 100).round(0).astype(int).astype(str) + "%"
        print("\nBy strategy (R = multiples of the money risked per trade):")
        print(bs.round(2).to_string(index=False))
        print()
        print(out["trades"].tail(12).to_string(index=False))
        if args.save:
            out["trades"].to_csv(args.save, index=False)
            print(f"Saved trades to {args.save}")


def cmd_scan(args, cfg):
    system = _system(args, cfg, journal_path=":memory:")
    full = system.data.snapshot(limit=max(args.history, args.bars + 200))
    tf = cfg["market"]["entry_tf"]
    from core.models import tf_minutes
    import pandas as pd
    step = pd.Timedelta(minutes=tf_minutes(tf))
    times = full.candles[tf].index[-args.bars:]
    found = 0
    for t in times:
        snap, reports, plan = system.replay(full, t + step)
        if plan.side != "NONE" and (plan.approved or args.all):
            found += 1
            tag = "APPROVED" if plan.approved else "blocked: " + "; ".join(plan.vetoes)[:70]
            print(f"{plan.ts[:16]}  {plan.strategy:<14} {plan.side:<5} {plan.entry_type:<6} entry {plan.entry:.1f} stop {plan.stop:.1f} "
                  f"tp1 {plan.tp1:.1f} RR {plan.rr}  {tag}")
    print(f"{found} setups in the last {args.bars} candles ({full.source})")


def cmd_journal(args, cfg):
    system = TradingSystem(cfg, demo=False)
    j = system.journal
    if args.action == "list":
        print(j.list(30).to_string(index=False))
    elif args.action == "stats":
        for k, v in j.stats().items():
            print(f"{k:>20}: {v:.2f}" if isinstance(v, float) else f"{k:>20}: {v}")
        if j.stats()["trades"] < 30:
            print("\n(fewer than 30 closed trades - too early to judge the strategy)")
    elif args.action == "take":
        j.take(int(args.id))
        print(f"Trade {args.id} marked as taken.")
    elif args.action == "skip":
        j.skip(int(args.id))
        print(f"Trade {args.id} skipped.")
    elif args.action == "close":
        t = j.close(int(args.id), float(args.price))
        print(f"Trade {args.id} closed: PnL ${t['pnl_usd']:.2f} ({t['r_mult']:+.2f}R)")


def cmd_check(args, cfg):
    import os
    import requests
    ok = lambda b: "OK  " if b else "FAIL"
    print("ETH Agent Desk - setup check\n")
    m = cfg["market"]
    for name, url in (("Binance futures", m["exchange_url"].rstrip("/") + "/fapi/v1/ping"),
                      ("Binance spot mirror", "https://data-api.binance.vision/api/v3/ping")):
        try:
            r = requests.get(url, timeout=8)
            print(f"[{ok(r.ok)}] {name}: HTTP {r.status_code}" + ("  (blocked in your country/IP)" if r.status_code == 451 else ""))
        except Exception as e:
            print(f"[FAIL] {name}: {type(e).__name__}")
    c = cfg["news"].get("calendar") or {}
    if c.get("enabled"):
        try:
            r = requests.get(c["url"], timeout=8)
            print(f"[{ok(r.ok)}] economic calendar: HTTP {r.status_code}")
        except Exception as e:
            print(f"[FAIL] economic calendar: {type(e).__name__} (add blackouts by hand in config.yaml)")
    try:
        import websocket  # noqa: F401
        from websocket import create_connection
        from core.liqstream import DEFAULT_URLS
        stream = m["symbol"].lower() + "@forceOrder"
        good = None
        for u in (cfg.get("liquidations", {}) or {}).get("urls") or DEFAULT_URLS:
            try:
                create_connection(u.format(stream=stream), timeout=8).close()
                good = u
                break
            except Exception:
                continue
        print(f"[{ok(bool(good))}] Binance liquidation stream" + ("" if good else "  (the liquidations agent will report 'not running')"))
    except ImportError:
        print("[FAIL] websocket-client not installed (pip install -r requirements.txt): liquidation stream unavailable")
    t = cfg["telegram"]
    print(f"[{ok(bool(t.get('token') and t.get('chat_id')))}] Telegram keys in .env"
          + ("" if t.get("enabled") else "  (telegram.enabled is false)"))
    print(f"[{ok(bool(os.getenv('ANTHROPIC_API_KEY')))}] ANTHROPIC_API_KEY in .env"
          + ("" if cfg["llm"].get("enabled") or cfg["llm"].get("review") else "  (llm features are off - optional)"))
    a, r = cfg["account"], cfg["risk"]
    print(f"\nAccount ${a['size']:,} | risk/trade {r['risk_per_trade_pct']}% = ${a['size'] * r['risk_per_trade_pct'] / 100:,.0f}"
          f" | daily stop {r['max_daily_loss_pct']}% | total stop {r['max_total_drawdown_pct']}%")
    print("Compare these with YOUR prop firm's rules. Keep them tighter than the firm's.")
    print(f"Contract size {a['contract_size']} ETH per lot, spread assumption ${cfg['backtest']['spread_usd']}/ETH "
          f"- both must match your broker.")


def cmd_coinglass(args, cfg):
    """Tries the Coinglass API endpoints this desk would use and shows what YOUR plan allows.
    Full raw answers are saved in data/coinglass_samples/ so a parser can be written against the real format."""
    import json
    import os
    import requests
    from core.config import ROOT
    key = os.getenv("COINGLASS_API_KEY", "").strip()
    if not key:
        print("No COINGLASS_API_KEY found. Add this line to your .env file (never share it):\n  COINGLASS_API_KEY=your_key_here")
        return
    base = "https://open-api-v4.coinglass.com"
    sym = cfg["market"]["symbol"]
    tests = [
        ("key check (supported pairs)", "/api/futures/supported-exchange-pairs", {}),
        ("liquidation heatmap (model1)", "/api/futures/liquidation/heatmap/model1", {"exchange": "Binance", "symbol": sym, "range": "3d"}),
        ("liquidation map", "/api/futures/liquidation/map", {"exchange": "Binance", "symbol": sym, "interval": "1d"}),
        ("large limit orders", "/api/futures/orderbook/large-limit-order", {"exchange": "Binance", "symbol": sym}),
    ]
    out_dir = ROOT / "data" / "coinglass_samples"
    out_dir.mkdir(parents=True, exist_ok=True)
    print("Coinglass API check (your key is never printed)\n")
    for name, path, params in tests:
        try:
            r = requests.get(base + path, params=params, headers={"CG-API-KEY": key, "accept": "application/json"}, timeout=20)
            try:
                body = r.json()
            except ValueError:
                body = {"raw": r.text[:300]}
            code, msg = str(body.get("code", "")), body.get("msg", "")
            good = r.ok and code == "0"
            hint = ""
            if code == "40004":
                hint = "  <- your plan does not include this endpoint"
            elif code == "40001":
                hint = "  <- invalid key (copy it again, or reset it)"
            elif code == "40003":
                hint = "  <- rate limit, wait a minute"
            print(f"[{'OK  ' if good else 'FAIL'}] {name}: HTTP {r.status_code}, code {code or '-'} {msg}{hint}")
            if good:
                (out_dir / (path.strip("/").replace("/", "_") + ".json")).write_text(json.dumps(body)[:400000], encoding="utf-8")
                d = body.get("data")
                if "large-limit-order" in path and isinstance(d, list):
                    from core.coinglass import clean
                    o = clean(d)
                    print(f"       {len(d)} records, {len(o)} parsed, {sum(1 for x in o if x['state'] == 1)} open - the whale agent can use this")
                print("       data:", (f"list of {len(d)}" if isinstance(d, list) else f"keys {list(d)[:8]}" if isinstance(d, dict) else type(d).__name__))
        except Exception as e:
            print(f"[FAIL] {name}: {type(e).__name__}: {e}")
    print(f"\nIf some are OK, send me the files in {out_dir} (they contain market data only, not your key).")


def cmd_deribit(args, cfg):
    """Checks that Deribit's public options data can be reached from this machine and read, and prints what the agent sees."""
    from core.deribit import options
    res = options(cfg)
    if res["error"]:
        print(f"[FAIL] {res['error']['msg']}")
        print("If this machine cannot reach www.deribit.com (some networks block it), run the desk from a server that can.")
        return
    from core import options as ox
    import time
    now = int(time.time() * 1000)
    o = res["options"]
    print(f"[OK] {len(o)} option contracts read from Deribit")
    for exp, rs in list(ox.by_expiry(o, now).items())[:5]:
        print(f"  {time.strftime('%d %b %Y', time.gmtime(exp / 1000))}: {len(rs)} contracts, max pain {ox.max_pain(rs)}, put/call {ox.put_call_ratio(rs):.2f}")


def cmd_dashboard(args, cfg):
    try:
        subprocess.run([sys.executable, "-m", "streamlit", "run", str(ROOT / "dashboard.py")], check=True)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        sys.exit(f"Could not start the dashboard ({e}). Install it with: pip install -r requirements.txt")


def main():
    p = argparse.ArgumentParser(description="ETH Agent Desk")
    p.add_argument("--config", default=None)
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp):
        sp.add_argument("--demo", action="store_true", help="use synthetic data (no internet)")
        sp.add_argument("--seed", type=int, default=7)

    r = sub.add_parser("run", help="one full cycle"); common(r)
    r.add_argument("--no-record", action="store_true"); r.add_argument("--notify", action="store_true")
    r.set_defaults(fn=cmd_run)

    l = sub.add_parser("loop", help="run continuously"); common(l)
    l.add_argument("--every", type=int, default=300); l.add_argument("--verbose", action="store_true")
    l.set_defaults(fn=cmd_loop)

    b = sub.add_parser("backtest", help="walk-forward backtest"); common(b)
    b.add_argument("--bars", type=int, default=600)
    b.add_argument("--history", type=int, default=1000, help="candles to download (live mode max ~1000)")
    b.add_argument("--save", default=None, help="write the trade list to this CSV file")
    b.set_defaults(fn=cmd_backtest)

    s = sub.add_parser("scan", help="list past setups"); common(s)
    s.add_argument("--bars", type=int, default=300)
    s.add_argument("--history", type=int, default=1000)
    s.add_argument("--all", action="store_true", help="also show setups blocked by the risk agent")
    s.set_defaults(fn=cmd_scan)

    j = sub.add_parser("journal", help="trade journal")
    j.add_argument("action", choices=["list", "stats", "take", "skip", "close"])
    j.add_argument("id", nargs="?"); j.add_argument("price", nargs="?")
    j.set_defaults(fn=cmd_journal)

    sub.add_parser("check", help="test your setup").set_defaults(fn=cmd_check)
    sub.add_parser("liqstream", help="run the liquidation listener on its own").set_defaults(fn=cmd_liqstream)
    sub.add_parser("deribit", help="check that Deribit options data can be read").set_defaults(fn=cmd_deribit)
    sub.add_parser("coinglass", help="test your Coinglass API key and plan").set_defaults(fn=cmd_coinglass)
    sub.add_parser("dashboard", help="open the dashboard").set_defaults(fn=cmd_dashboard)

    args = p.parse_args()
    cfg = load_config(args.config)
    args.fn(args, cfg)


if __name__ == "__main__":
    main()
