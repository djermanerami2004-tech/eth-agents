# ETH Agent Desk

A team of specialised agents that analyse ETH (liquidity sweeps, market structure, order flow, news), size the trade
under strict risk rules, and hand you a **signal** (entry, stop, two targets) or "no trade".
It does **not** place orders. You stay in control, which also keeps you on the right side of most prop-firm
automation rules (check yours).

```
          ┌─ Liquidity ─┐
 Data ───►├─ Structure ─┤──► Manager ──► Risk (VETO) ──► [Claude reviewer, optional] ──► Plan ──► Journal
 (Binance)├─ Order flow ┤   (one plan)    sizes + limits    can only reject / halve               paper-tracks
          └─ News ──────┘                                                                          + Telegram
```

## Quick start

**Windows:** install Python 3.10+ (tick "Add to PATH"), then double-click `scripts\setup.bat`, then `scripts\run_dashboard.bat`.
**Linux/macOS:** `bash scripts/setup.sh` then `.venv/bin/python main.py dashboard`.

```
python main.py check                  # tests internet, Binance, calendar, Telegram, Claude key
python main.py run --demo             # one full cycle, works offline
python main.py run                    # one cycle on live Binance data
python main.py loop --every 300       # keep running, track paper trades, send alerts
python main.py backtest --bars 900    # walk-forward test with trading costs
python main.py scan --bars 400        # every moment the desk would have traded recently
python main.py journal stats          # paper-trading results
python main.py dashboard              # visual dashboard (chart, agents, backtest, journal)
pytest                                # 85+ tests
```

## Edit `config.yaml` first
| Setting | Why |
|---|---|
| `account.size`, `risk.*` | Keep them **tighter** than your prop firm's daily-loss / drawdown rules. Read the rules yourself. |
| `account.contract_size`, `lot_step`, `max_leverage` | Must match your broker's ETH CFD specs. |
| `backtest.spread_usd` | Your broker's real spread. With tight stops, costs decide everything. |
| `levels.txt` (or `liquidity.manual_levels`) | Paste the clusters you read on Coinglass, one per line (`3850 strong`, `3720 0.6`). They override the modelled estimate and are re-read automatically; you can also edit them in the dashboard sidebar. |
| `strategies.*` | Switch each setup type on/off (`enabled: false`) and set its own `min_score`. |
| `account.profit_target_pct` | Optional: your firm's profit target, shown as a progress bar. |
| `news.blackouts` | Extra no-trade windows (the weekly USD high-impact calendar is fetched automatically). |
| `risk.allowed_sessions_utc` | Default 07:00-20:00 UTC. Dashboard shows times in `market.display_tz`. |
| `telegram`, `llm` | Optional. Keys go in `.env`, never in the config. |

## What each agent does
- **Data**: candles (entry + higher timeframe), open interest, funding, long/short ratio. Falls back to the spot mirror if futures are unreachable.
- **Liquidity**: *models* where leveraged longs/shorts get liquidated (like a heatmap), drops levels price already traded through, and detects a **sweep** (wick through a level, close back on the original side; a breakout is not a sweep).
- **Structure**: trend on two timeframes, BOS/CHoCH, premium/discount, fair value gaps, order blocks.
- **Order flow**: delta/CVD from Binance taker-buy volume, session VWAP, CVD divergence.
- **Derivatives**: funding rate (crowding, contrarian at extremes), open interest read together with price (new longs / new shorts / short covering / long liquidation), long/short ratio.
- **Indicators**: RSI, MACD, EMA 20/50, Bollinger %B and ATR volatility on the entry and higher timeframe.
- **Multi-timeframe**: trend (EMA + swing structure) on 15m, 1h, 4h and 1d, weighted toward the higher timeframes, plus an alignment score. The manager blocks trades that fight the higher-timeframe trend (`mtf.block_against` in `config.yaml`, set 0 to switch off).
- **Sessions**: previous-day high/low and the Asia / London / New York ranges (UTC). A level that nothing has traded beyond since it formed, then gets wicked through and closed back inside, is a session sweep.
- **Order book**: resting limit orders ("walls") and bid/ask imbalance from Binance depth, live only. Binance only shows the area right next to price (a fraction of a percent for ETH), so far walls like the ones on Coinglass "Large orders" go into `walls.txt` (`3955 ask 48.5`) or the dashboard sidebar. It tracks how long walls stand and lowers its confidence when walls vanish before price reaches them (spoofing). There is no order-book history, so backtests leave this agent out.
- **News**: automatic blackout windows around high-impact USD events, plus headline sentiment.
- **Risk** (veto power): size from risk %, daily/total loss, trades per day, loss streak, one active trade, hours, stop/RR sanity, leverage cap.
- **Manager**: weighted vote and agreement rules, then entry (sweep or zone), stop, TP1 (nearest liquidity 1.5-3R else 2R), TP2.
- **Journal**: SQLite. `paper_mode` tracks every approved signal automatically with the same rules as the backtest.
- **Claude (optional)**: explains the plan and acts as a sceptical reviewer that may only reject or halve a trade, never enlarge or create one.

## Market regime, volume profile, BTC
- **Market regime** (`agents/regime_agent.py`): trend, range, squeeze or mixed, from the 1h ADX and efficiency ratio and the 15m Bollinger band width. It is a context agent with weight 0: it adds nothing to the composite score. Instead the manager multiplies each setup's quality by the `regime.fit` table (config.yaml) when it ranks the setups that already passed, so trend followers rank higher in a trend and sweep reversals in a range. It never creates or blocks a trade. Give it a weight above 0 if you also want the trend direction to vote.
- **Volume profile** (`agents/volume_profile_agent.py`): POC, value area and volume nodes of the last 2 days, from candle volume spread over each candle's range (an approximation of a tick profile). Inside the value area it leans back to the POC, after a failed move back into it it leans toward the POC, after 3+ closes outside it leans with the move. Drawn on the chart in light blue.
- **BTC** (`agents/btc_agent.py`): BTC trend against its 1h EMA20, plus a catch-up signal when BTC moved and ETH (given its beta) has not followed yet, scaled by the 24h correlation. Silent when ETH is decoupled (`btc.min_corr`) or when BTC candles are missing (`market.ref_symbol`). In demo mode BTC is generated from the ETH candles of the same candle only, so it is correlated but cannot predict ETH.
All three work on candles, so they are included in backtests.

## Chart patterns
The **Chart patterns** agent finds double top / double bottom, head & shoulders (and inverse), bull / bear flags, ascending / descending / symmetrical triangles and rising / falling wedges on the 15m and 1h candles (`core/patterns.py`, rules written in ATR units). Pivots need 3-4 candles on each side to be confirmed, so a pattern is only ever found from candles that had already closed. A candle CLOSE through the trigger line (neckline, trendline, flag edge) is a break: the bias follows the break, the measured move is the target and the pattern's other side is the invalidation. A pattern that is still forming only leans slightly. Found patterns are drawn on the chart in purple (dotted while forming) and listed in the agent's popup. The **pattern_breakout** strategy trades a fresh break (skips it if price already ran more than `max_chase_atr` past the line) and its stop and first target come from the pattern. Patterns appear in random data too - that is what random walks do - so judge them by the Strategies tab and your own backtests, not by how they look. Tune it in the `patterns:` block of `config.yaml`.

## Liquidation stream (live)
The **Liquidations** agent listens to Binance's free forced-liquidation feed (`@forceOrder`, no key) and keeps the events in `data/liquidations.db`. The loop and the dashboard start the listener themselves; `python main.py liqstream` runs it alone and prints every liquidation. A burst (several times the normal 15-minute amount) of liquidated longs or shorts is read in two phases: still running = cascade, leans with the forced flow with low confidence; slowed to a third of its peak = spent flush, leans the other way. Both rules are heuristics, not measured edge. Binance keeps no liquidation history for you, so the agent is live only and is left out of backtests, and it needs about 15 minutes of listening before it speaks. Liquidations the chart shows as x marks (red = longs liquidated, green = shorts). Tune it in the `liquidations:` block of `config.yaml`.

## Run it 24/7
See `deploy/DEPLOY.md`: a one-script setup for an Ubuntu server (systemd services that restart themselves) or `docker compose up -d --build`, phone access through Tailscale, an optional `DASHBOARD_PASSWORD`, a Telegram alert when data stops, and `scripts/healthcheck.py`.

## Look and feel
Dark theme (`.streamlit/config.toml` plus the styles in `core/ui.py`): a score gauge with the trade threshold marked, one icon per agent, a bias bar for each agent, price strips (stop / entry / targets) for setups, and an account-rules panel. Icons and the gauge are drawn as images because Streamlit removes inline SVG from custom HTML.

## Agent popups
Every agent card on the Desk tab has a **Details & setups** button. The popup shows the agent's bias, confidence, weight and how many points it adds to the composite score,
every setup that a strategy built on that agent found (with entry, stop, targets, RR and why it was or was not taken, even when the composite score is too low), and the agent's raw data.
The "All setups found this cycle" box under the cards lists every setup on the desk. The indicative levels of setups that were not taken have not been through the risk agent.

## Strategies (what the manager can trade)
Each strategy proposes at most one setup; the manager checks it against the multi-timeframe gate and the agents' agreement, picks the best, and the risk agent can still veto. Every trade is tagged with its strategy, and the dashboard's **Strategies** tab ranks them by average R with a cautious verdict (nothing is called promising before 30 trades).

| Strategy | Idea |
|---|---|
| `sweep_reversal` | Wick through a liquidity cluster, close back inside |
| `session_sweep` | Same, for the previous-day high/low and Asia / London highs and lows |
| `trend_pullback` | Higher timeframes agree on a trend, price pulls back to a zone / EMA50 |
| `bos_retest` | Break of a swing high/low, retest, hold |
| `range_breakout` | First volume-confirmed close outside the Asian range |
| `pattern_breakout` | A chart pattern was just broken by a candle close; stop at the pattern's invalidation, first target = measured move |
| `consensus` | No pattern, just a strong weighted agreement of all agents |

More setups are not more profit. Keep only the strategies whose paper-trade record earns it.

## RSI divergence (`agents/divergence_agent.py`)
Compares RSI pivots with price pivots on 15m and 1h. Regular divergence (price makes a higher high but RSI a lower high, or the mirror for lows) warns of a turn; hidden
divergence (higher low with a lower RSI low, or the mirror) hints the trend continues. Only pivots confirmed by `pivot_bars` candles on each side count (no look-ahead), a divergence
older than `max_age_bars` or one price has already broken through is dropped. Tune or switch hidden off in the `divergence:` block of `config.yaml`. Pink dashed lines on the chart.
It is a heuristic: divergences fail often in strong trends, the manager only gives it a small weight (0.06).

## Whale orders from Coinglass (`agents/whale_agent.py`)
Reads large resting limit orders (>= `min_usd`, within `range_pct` of price) from the Coinglass API: a big bid wall below price leans long, a big ask wall above leans short,
and walls that are fresh or being cancelled are flagged (possible spoofing). Needs the **Standard plan or higher**; Hobbyist/Startup return a plan error and the agent just says
"no data" (walls.txt stays the fallback). Run `python main.py coinglass` to check your plan and to save raw sample answers to `data/coinglass_samples/`.
Built from the documented field names and tested with mocked answers, NOT yet against the live API: send me a sample file if the numbers look wrong.
Walls appear as dashed lines on the chart. Live only, left out of backtests.

## ETH options from Deribit (`agents/options_agent.py`)
Free public data, no key. Reads every ETH option on Deribit and works out three things (all heuristics, none a proven edge):
- **Max pain** of the next expiries (the strike where option holders lose most). Close to an expiry with big open interest, price tends to drift toward it. The pull counts
  more the closer the expiry and the bigger its open interest; tiny or far expiries are ignored.
- **Gamma walls**: strikes where dealer gamma is concentrated. A big call wall just above price tends to cap it, a big put wall just below tends to hold it. Total gamma negative =
  moves can accelerate, so the max-pain pull is trusted less (x0.7). This assumes dealers are long calls / short puts, which Deribit does not tell us, so it is a rough map.
- **Sentiment extremes**: 25-delta risk reversal and put/call open interest, only at extremes (crowded puts = mild long, crowded calls = mild short), small weight.
Weight 0.05, live only (Deribit has no history, so backtests leave it out). Chart: gold dotted max pain, red/green dotted call/put wall, grey gamma flip.
Run `python main.py deribit` once to check your machine can reach Deribit. Tune everything in the `options:` block of `config.yaml`.

## Coinglass API (optional, paid)
Put `COINGLASS_API_KEY=...` in `.env` and run `python main.py coinglass`. It tries the heatmap, liquidation map and large-orders endpoints and tells you which your plan
allows (code 40004 = plan too low). Per Coinglass's docs the liquidation heatmap and map need the Professional plan; the cheaper plans cover basic data only. Until you have
a plan that includes them, paste levels into `levels.txt` / `walls.txt` instead.

## Trade rules used by backtest AND paper journal (`core/tradesim.py`)
Limit orders expire after 8 candles; a stop and target in the same candle counts as a stop; no target credit on the candle a
limit order fills; TP1 closes 50% and moves the stop to break-even; time stop after 48 candles; spread and slippage charged.

## Validation: what was actually tested
- **85+ automated tests**, including a check that corrupting every not-yet-closed candle never changes a decision (no look-ahead).
- **Random-market test**: drift-free random price paths with full costs. Engine alone: -0.19R per trade (563 trades, t = -3.1). With all strategies on
  (16 paths, ~350 trades): between -0.18R and -0.03R depending on the run, never significantly positive. On data with no edge the system does not
  invent profit. Small per-strategy samples swing by +-0.2R from noise alone, which is why the leaderboard waits for 30+ trades. (An earlier version showed +0.24R on trending synthetic data and +0.09R with optimistic
  fills; both were test-data and engine flaws, now fixed.)
- Bugs found and fixed while testing: TP2 sometimes closer than TP1; breakouts mislabelled as sweeps; demo data changing with the amount requested.

## What was NOT tested (be honest with yourself)
- **Live Binance access**: the build environment could not reach Binance. The live code is tested against mocked responses only. Run `python main.py check` on your PC.
- **Real edge**: no result here says the strategy makes money on real ETH. Backtest on real data (`--history 1000`), then **paper trade for several weeks (100+ trades)** before risking a funded account.
- The liquidity map is an estimate, not Coinglass data. "Setup score" is a heuristic, not a win probability.
- Costs matter: with a $8 stop a $1 spread is already 0.12R. Prefer wider stops (raise `min_stop_atr`) if backtests die on costs.

## Layout
```
main.py            CLI            dashboard.py   Streamlit app        config.yaml   all settings
agents/            data, liquidity, structure, patterns, regime, volume_profile, btc, orderflow, derivatives, indicators, mtf, session, orderbook, liquidations, news, risk, manager, journal
strategies/        sweep_reversal, session_sweep, trend_pullback, bos_retest, range_breakout, pattern_breakout, consensus
levels.txt         your Coinglass liquidation levels (hot-reloaded)
walls.txt          your Coinglass large-order walls (hot-reloaded)
core/              models, levels, indicators, smc, tradesim, backtest, metrics, charts, llm, notifier, synthetic, pipeline
scripts/           setup + launch helpers        tests/   pytest suite        data/   journal database
```
Add an agent: subclass `BaseAgent` (`agents/base.py`), return an `AgentReport`, add it in `core/pipeline.py` and a weight in `config.yaml`.

*Signals only. Not financial advice. Trading CFDs can lose more than you expect.*
