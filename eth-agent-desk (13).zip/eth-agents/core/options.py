"""ETH options maths from Deribit's public book summary (free, no API key).

Instrument names look like ETH-29NOV24-3000-C. Per Deribit's docs, open_interest of an option is counted in the underlying
(ETH), mark_iv is in percent and underlying_price is in USD. Everything here is a pure function of that data, so it is easy
to test. Interest rate is taken as 0 (fine for crypto at these horizons).

Dealer assumption for gamma: the usual convention is that dealers are long the calls and short the puts customers hold,
so call gamma counts positive and put gamma negative. That is an ASSUMPTION (Deribit does not say who is on which side),
so treat the gamma map as a rough picture of where hedging flows may pin or accelerate price, not as a fact.
"""
from __future__ import annotations

import math
import re
from datetime import datetime, timezone

_NAME = re.compile(r"^[A-Z]+-(\d{1,2}[A-Z]{3}\d{2})-(\d+(?:\.\d+)?)-([CP])$")
SECONDS_PER_YEAR = 365 * 24 * 3600


def parse_rows(rows: list[dict]) -> list[dict]:
    """Deribit book-summary rows -> [{expiry_ms, strike, kind 'C'|'P', oi, iv, spot}] (rows that do not parse are dropped)."""
    out = []
    for r in rows:
        try:
            m = _NAME.match(str(r["instrument_name"]).upper())
            if not m:
                continue
            exp = datetime.strptime(m.group(1), "%d%b%y").replace(hour=8, tzinfo=timezone.utc)   # Deribit options expire 08:00 UTC
            iv, oi, spot = float(r.get("mark_iv") or 0), float(r.get("open_interest") or 0), float(r["underlying_price"])
            if spot <= 0:
                continue
            out.append({"expiry_ms": int(exp.timestamp() * 1000), "strike": float(m.group(2)), "kind": m.group(3),
                        "oi": oi, "iv": iv / 100.0, "spot": spot})
        except (KeyError, TypeError, ValueError):
            continue
    return out


def _cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _d1(S: float, K: float, T: float, iv: float) -> float:
    return (math.log(S / K) + 0.5 * iv * iv * T) / (iv * math.sqrt(T))


def gamma(S: float, K: float, T: float, iv: float) -> float:
    if T <= 0 or iv <= 0 or S <= 0 or K <= 0:
        return 0.0
    d1 = _d1(S, K, T, iv)
    return math.exp(-0.5 * d1 * d1) / math.sqrt(2 * math.pi) / (S * iv * math.sqrt(T))


def delta(S: float, K: float, T: float, iv: float, kind: str) -> float:
    if T <= 0 or iv <= 0:
        return 0.0
    c = _cdf(_d1(S, K, T, iv))
    return c if kind == "C" else c - 1.0


def years(expiry_ms: int, now_ms: int) -> float:
    return max(0.0, (expiry_ms - now_ms) / 1000 / SECONDS_PER_YEAR)


def by_expiry(opts: list[dict], now_ms: int) -> dict[int, list[dict]]:
    d: dict[int, list[dict]] = {}
    for o in opts:
        if o["expiry_ms"] > now_ms:
            d.setdefault(o["expiry_ms"], []).append(o)
    return dict(sorted(d.items()))


def max_pain(opts: list[dict]) -> float | None:
    """The strike where the total payout to option holders at expiry is smallest."""
    strikes = sorted({o["strike"] for o in opts if o["oi"] > 0})
    if not strikes:
        return None
    best, best_pay = None, None
    for s in strikes:
        pay = sum(o["oi"] * (max(0.0, s - o["strike"]) if o["kind"] == "C" else max(0.0, o["strike"] - s)) for o in opts)
        if best_pay is None or pay < best_pay:
            best, best_pay = s, pay
    return best


def put_call_ratio(opts: list[dict]) -> float | None:
    c = sum(o["oi"] for o in opts if o["kind"] == "C")
    p = sum(o["oi"] for o in opts if o["kind"] == "P")
    return None if c <= 0 else p / c


def gex_at(opts: list[dict], S: float, now_ms: int) -> dict[float, float]:
    """Net dealer gamma per strike in USD for a 1% move of spot S (calls +, puts -)."""
    g: dict[float, float] = {}
    for o in opts:
        T = years(o["expiry_ms"], now_ms)
        if T <= 0 or o["iv"] <= 0 or o["oi"] <= 0:
            continue
        v = gamma(S, o["strike"], T, o["iv"]) * o["oi"] * S * S * 0.01
        g[o["strike"]] = g.get(o["strike"], 0.0) + (v if o["kind"] == "C" else -v)
    return g


def gamma_flip(opts: list[dict], S: float, now_ms: int, span: float = 0.15, steps: int = 61) -> float | None:
    """Price nearest to spot where total net gamma changes sign (None if it does not within +-span)."""
    pts = []
    for i in range(steps):
        p = S * (1 - span + 2 * span * i / (steps - 1))
        pts.append((p, sum(gex_at(opts, p, now_ms).values())))
    cross = [(a[0] + (b[0] - a[0]) * (0 - a[1]) / (b[1] - a[1]))
             for a, b in zip(pts, pts[1:]) if a[1] != b[1] and (a[1] < 0) != (b[1] < 0)]
    return min(cross, key=lambda x: abs(x - S)) if cross else None


def risk_reversal(opts: list[dict], S: float, now_ms: int, min_days: float = 7.0) -> dict | None:
    """25-delta risk reversal (call IV minus put IV, in vol points) and ATM IV on the nearest expiry at least min_days away.
    Negative = puts are richer than calls (hedging / fear)."""
    for exp, rows in by_expiry(opts, now_ms).items():
        T = years(exp, now_ms)
        if T * 365 < min_days:
            continue
        calls = [o for o in rows if o["kind"] == "C" and o["iv"] > 0]
        puts = [o for o in rows if o["kind"] == "P" and o["iv"] > 0]
        if len(calls) < 3 or len(puts) < 3:
            continue
        c25 = min(calls, key=lambda o: abs(delta(S, o["strike"], T, o["iv"], "C") - 0.25))
        p25 = min(puts, key=lambda o: abs(delta(S, o["strike"], T, o["iv"], "P") + 0.25))
        atm = min(calls, key=lambda o: abs(o["strike"] - S))
        return {"expiry_ms": exp, "days": T * 365, "rr25": (c25["iv"] - p25["iv"]) * 100, "atm_iv": atm["iv"] * 100,
                "call25_strike": c25["strike"], "put25_strike": p25["strike"]}
    return None
