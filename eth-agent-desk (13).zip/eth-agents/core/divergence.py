"""RSI divergence from confirmed swing pivots (pure functions, no look-ahead).

Regular divergence (reversal): price makes a higher high while RSI makes a lower high (bearish), or price a lower low
while RSI a higher low (bullish). Hidden divergence (continuation): price a higher low with RSI a lower low (bullish),
or a lower high with RSI a higher high (bearish). Pivots are the same confirmed swings used everywhere else (they need
`k` candles on each side), so a divergence is only reported once its second pivot is confirmed. It is invalidated when
price closes beyond the second pivot (the move it warned about did not happen).
Optional confirmation: the aggressive-volume delta between the two pivots also diverges.
"""
from __future__ import annotations

import pandas as pd

from core.indicators import candle_delta, rsi, swings


def find_divergences(df: pd.DataFrame, a: float, k: int = 3, max_age: int = 12, tf: str = "", rsi_len: int = 14,
                     min_gap: float = 2.0, hidden: bool = True, min_bars: int = 5, max_bars: int = 60,
                     zone_high: float = 58.0, zone_low: float = 42.0) -> list[dict]:
    """Divergences whose second pivot was confirmed at most `max_age` candles ago and not yet invalidated."""
    n = len(df)
    if n < 60 or a <= 0:
        return []
    r = rsi(df["close"], rsi_len).values
    close = df["close"].values
    sh, sl = swings(df, k, k)
    highs = [(i, float(v)) for i, v in enumerate(sh.values) if v == v and i >= rsi_len * 2]
    lows = [(i, float(v)) for i, v in enumerate(sl.values) if v == v and i >= rsi_len * 2]
    delta = candle_delta(df).values if "taker_buy_base" in df else None
    out = []

    def rsi_at(i, fn):                                   # RSI extreme within +-1 candle of the pivot candle
        return float(fn(r[max(0, i - 1):i + 2]))

    def check(piv, is_high):
        if len(piv) < 2:
            return
        (i1, p1), (i2, p2) = piv[-2], piv[-1]
        if not min_bars <= i2 - i1 <= max_bars or n - 1 - (i2 + k) > max_age:
            return
        fn = max if is_high else min
        r1, r2 = rsi_at(i1, fn), rsi_at(i2, fn)
        price_up = p2 > p1 + 0.1 * a
        price_dn = p2 < p1 - 0.1 * a
        rsi_up, rsi_dn = r2 > r1, r2 < r1
        if is_high:
            if price_up and rsi_dn and r1 >= zone_high:
                kind, d, name = "regular", -1, "bearish RSI divergence"
            elif hidden and price_dn and rsi_up:
                kind, d, name = "hidden", -1, "hidden bearish RSI divergence"
            else:
                return
        else:
            if price_dn and rsi_up and r1 <= zone_low:
                kind, d, name = "regular", 1, "bullish RSI divergence"
            elif hidden and price_up and rsi_dn:
                kind, d, name = "hidden", 1, "hidden bullish RSI divergence"
            else:
                return
        if (d == -1 and (close[i2 + 1:] > p2).any()) or (d == 1 and (close[i2 + 1:] < p2).any()):
            return                                        # price closed beyond the second pivot: it failed
        gap = abs(r2 - r1)
        if gap < min_gap:
            return
        q = 0.45 + 0.25 * min(1.0, gap / 10.0) + 0.1 * min(1.0, abs(p2 - p1) / (2 * a))
        delta_ok = False
        if delta is not None:
            c1, c2 = float(delta[max(0, i1 - 2):i1 + 3].sum()), float(delta[max(0, i2 - 2):i2 + 3].sum())
            # regular: buying pressure fades on a bearish divergence / selling fades on a bullish one; hidden: the reverse
            delta_ok = (c2 < c1) if (d == -1) == (kind == "regular") else (c2 > c1)
            q += 0.12 if delta_ok else 0.0
        if kind == "hidden":
            q *= 0.8
        out.append({"name": name, "kind": kind, "dir": d, "tf": tf, "since": n - 1 - (i2 + k), "quality": float(min(1.0, q)),
                    "rsi_1": r1, "rsi_2": r2, "price_1": p1, "price_2": p2, "delta_confirms": bool(delta_ok),
                    "points": [(int(df.index[i1].timestamp() * 1000), p1), (int(df.index[i2].timestamp() * 1000), p2)]})

    check(highs, True)
    check(lows, False)
    return out
