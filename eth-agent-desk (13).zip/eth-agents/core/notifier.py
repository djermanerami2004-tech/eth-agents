from __future__ import annotations

import requests


class Notifier:
    """Prints to console; also sends to Telegram when enabled and configured."""

    def __init__(self, cfg: dict):
        t = cfg["telegram"]
        self.enabled = bool(t.get("enabled") and t.get("token") and t.get("chat_id"))
        self.token, self.chat_id = t.get("token"), t.get("chat_id")

    def send(self, text: str) -> bool:
        if not self.enabled:
            return False
        try:
            r = requests.post(f"https://api.telegram.org/bot{self.token}/sendMessage",
                              json={"chat_id": self.chat_id, "text": text}, timeout=10)
            return r.ok
        except Exception:
            return False
