"""Live liquidation feed from Binance (free, no API key) stored in a small SQLite file.

Binance pushes every forced liquidation of a symbol on the `<symbol>@forceOrder` stream. A background thread
listens and writes the events to data/liquidations.db, so the desk loop, the dashboard and a stand-alone
`python main.py liqstream` can all share the same history. Duplicate events are ignored, so running two
collectors at once is harmless.

Side convention (Binance): a forced SELL closes a LONG position, a forced BUY closes a SHORT position.
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from pathlib import Path

HEARTBEAT_STALE_S = 150          # no ping/pong/message for this long = the collector is not running

DEFAULT_URLS = [
    "wss://fstream.binance.com/market/ws/{stream}",    # new endpoint (liquidations live on the /market tier)
    "wss://fstream.binance.com/ws/{stream}",           # legacy endpoint, kept as a fallback
]


def parse_force_order(msg) -> dict | None:
    """One raw websocket message -> {ts_ms, side ('long_liq'|'short_liq'), price, qty, usd} or None."""
    try:
        d = json.loads(msg) if isinstance(msg, (str, bytes, bytearray)) else msg
        if isinstance(d, dict) and "data" in d and "o" not in d:     # combined-stream wrapper
            d = d["data"]
        if not isinstance(d, dict) or d.get("e") != "forceOrder":
            return None
        o = d["o"]
        price = float(o.get("ap") or 0) or float(o["p"])
        qty = float(o.get("z") or 0) or float(o["q"])
        if price <= 0 or qty <= 0:
            return None
        side = "long_liq" if o["S"].upper() == "SELL" else "short_liq"
        return {"ts_ms": int(o.get("T") or d.get("E")), "side": side, "price": price, "qty": qty, "usd": price * qty}
    except (KeyError, TypeError, ValueError):
        return None


class LiqStore:
    def __init__(self, path: str):
        self.path = path
        if path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self.con = sqlite3.connect(path, timeout=15, check_same_thread=False)
        if path != ":memory:":
            self.con.execute("PRAGMA journal_mode=WAL")
        self.con.executescript("""
            CREATE TABLE IF NOT EXISTS liq(symbol TEXT, ts_ms INTEGER, side TEXT, price REAL, qty REAL, usd REAL,
                                           UNIQUE(symbol, ts_ms, side, price, qty));
            CREATE INDEX IF NOT EXISTS liq_ts ON liq(symbol, ts_ms);
            CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v REAL);
        """)
        self.con.commit()

    def add(self, symbol: str, ev: dict) -> None:
        with self._lock:
            self.con.execute("INSERT OR IGNORE INTO liq VALUES (?,?,?,?,?,?)",
                             (symbol, ev["ts_ms"], ev["side"], ev["price"], ev["qty"], ev["usd"]))
            self.con.commit()

    def since(self, symbol: str, ts_ms: int, until_ms: int | None = None) -> list[dict]:
        q, a = "SELECT ts_ms, side, price, qty, usd FROM liq WHERE symbol=? AND ts_ms>=?", [symbol, int(ts_ms)]
        if until_ms is not None:
            q += " AND ts_ms<=?"
            a.append(int(until_ms))
        with self._lock:
            rows = self.con.execute(q + " ORDER BY ts_ms", a).fetchall()
        return [dict(ts_ms=r[0], side=r[1], price=r[2], qty=r[3], usd=r[4]) for r in rows]

    def set_meta(self, k: str, v: float) -> None:
        with self._lock:
            self.con.execute("INSERT OR REPLACE INTO meta VALUES (?,?)", (k, float(v)))
            self.con.commit()

    def get_meta(self, k: str) -> float | None:
        with self._lock:
            r = self.con.execute("SELECT v FROM meta WHERE k=?", (k,)).fetchone()
        return None if r is None else float(r[0])

    def beat(self) -> None:
        now = time.time()
        if self.get_meta("first_run") is None:
            self.set_meta("first_run", now)
        self.set_meta("heartbeat", now)

    def prune(self, keep_hours: float) -> None:
        with self._lock:
            self.con.execute("DELETE FROM liq WHERE ts_ms < ?", (int((time.time() - keep_hours * 3600) * 1000),))
            self.con.commit()


def db_path(cfg: dict) -> str:
    p = (cfg.get("liquidations", {}) or {}).get("db", "data/liquidations.db")
    if p == ":memory:" or os.path.isabs(p):
        return p
    from core.config import ROOT
    return str(ROOT / p)


class Collector(threading.Thread):
    """Keeps one websocket open and writes liquidation events to the store. Reconnects by itself."""

    def __init__(self, cfg: dict):
        super().__init__(daemon=True, name="liq-collector")
        self.cfg = cfg
        self.symbol = cfg["market"]["symbol"]
        self.c = cfg.get("liquidations", {}) or {}
        self.store = LiqStore(db_path(cfg))
        self.urls = list(self.c.get("urls") or DEFAULT_URLS)
        self.stop_flag = threading.Event()
        self.connected = False
        self.last_error = ""
        self._ws = None
        self._last_prune = time.time()

    def handle(self, msg) -> bool:
        """Process one raw message (also used directly by the tests)."""
        ev = parse_force_order(msg)
        self.store.beat()
        if ev is None:
            return False
        self.store.add(self.symbol, ev)
        if time.time() - self._last_prune > 3600:
            self._last_prune = time.time()
            self.store.prune(float(self.c.get("keep_hours", 48)))
        return True

    def run(self) -> None:                      # pragma: no cover - needs the real network
        import websocket
        stream = self.symbol.lower() + "@forceOrder"
        i, delay = 0, 2.0
        while not self.stop_flag.is_set():
            url = self.urls[i % len(self.urls)].format(stream=stream)
            opened = {"t": None}

            def on_open(ws):
                self.connected = True
                opened["t"] = time.time()
                self.store.beat()

            ws = websocket.WebSocketApp(url, on_open=on_open, on_message=lambda ws, m: self.handle(m),
                                        on_pong=lambda ws, m: self.store.beat(),
                                        on_error=lambda ws, e: setattr(self, "last_error", str(e)))
            self._ws = ws
            try:
                ws.run_forever(ping_interval=20, ping_timeout=10)
            except Exception as e:
                self.last_error = str(e)
            self.connected = False
            if opened["t"] and time.time() - opened["t"] > 60:      # it worked for a while: retry the same URL quickly
                delay = 2.0
            else:                                   # never got going: try the other URL, back off
                i += 1
                delay = min(delay * 2, 60.0)
            self.stop_flag.wait(delay)

    def stop(self) -> None:
        self.stop_flag.set()
        if self._ws is not None:
            try:
                self._ws.close()
            except Exception:
                pass


_collector: Collector | None = None
_guard = threading.Lock()


def ensure_running(cfg: dict) -> Collector | None:
    """Start the background collector once per process (no-op if disabled or ETH_DESK_NO_STREAM is set)."""
    global _collector
    c = cfg.get("liquidations", {}) or {}
    if not c.get("enabled", True) or not c.get("autostart", True) or os.getenv("ETH_DESK_NO_STREAM"):
        return None
    with _guard:
        if _collector is None or not _collector.is_alive():
            try:
                import websocket  # noqa: F401
            except ImportError:
                return None
            _collector = Collector(cfg)
            _collector.start()
        return _collector
