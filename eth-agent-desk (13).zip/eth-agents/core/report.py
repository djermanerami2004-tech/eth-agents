from __future__ import annotations

from core.models import AgentReport, TradePlan


def format_plan(symbol: str, tf: str, plan: TradePlan, reports: dict[str, AgentReport],
                narrative: str | None = None) -> str:
    L = [f"{symbol} {tf} | {plan.ts[:16].replace('T', ' ')} UTC | price {plan.price:.2f} | ATR {plan.atr:.2f}"]
    if plan.side == "NONE":
        L.append("DECISION: NO TRADE")
    else:
        status = "APPROVED" if plan.approved else "BLOCKED BY RISK"
        L.append(f"DECISION: {plan.side} ({plan.entry_type.lower()}) [{plan.strategy}] - {status}")
        L.append(f"Entry {plan.entry:.2f} | Stop {plan.stop:.2f} | TP1 {plan.tp1:.2f} | TP2 {plan.tp2:.2f} | RR {plan.rr}")
        L.append(f"Size {plan.size} lots | Risk ${plan.risk_usd:.0f} | Setup score {plan.confidence:.0%} (heuristic, not a win probability)")
        for v in plan.vetoes:
            L.append(f"  VETO: {v}")
    L.append("")
    L.append("Agents:")
    for r in reports.values():
        L.append(f"  {r.agent:<10} {r.bias:+.2f} (conf {r.confidence:.2f})  {r.summary}")
    if plan.reasons and plan.side == "NONE":
        L.append("")
        L.append(plan.reasons[0])
    if narrative:
        L.append("")
        L.append(narrative)
    return "\n".join(L)
