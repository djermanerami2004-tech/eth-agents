"""Deribit public API client (no key needed): GET /api/v2/public/get_book_summary_by_currency?currency=ETH&kind=option.

Answers are cached (options OI changes slowly) and a failure is remembered briefly so a dashboard that refreshes often does
not hammer the API. This module is only ever asked for LIVE data: the endpoint has no history.
"""
from __future__ import annotations

import threading
import time

from core.options import parse_rows

BASE = "https://www.deribit.com"
PATH = "/api/v2/public/get_book_summary_by_currency"
_lock = threading.Lock()
_cache: dict = {}


class DeribitError(Exception):
    def __init__(self, kind: str, msg: str):
        super().__init__(msg)
        self.kind = kind           # 'network' | 'format' | 'rate'


def _fetch(currency: str, timeout: float = 20.0) -> list[dict]:
    import requests
    try:
        r = requests.get(BASE + PATH, params={"currency": currency, "kind": "option"}, timeout=timeout,
                         headers={"accept": "application/json"})
    except requests.RequestException as e:
        raise DeribitError("network", f"could not reach Deribit ({type(e).__name__})")
    if r.status_code == 429:
        raise DeribitError("rate", "Deribit rate limit hit, waiting a bit")
    try:
        body = r.json()
    except ValueError:
        raise DeribitError("format", f"Deribit answered HTTP {r.status_code} with something that is not JSON")
    if isinstance(body.get("result"), list):
        return body["result"]
    err = body.get("error") or {}
    raise DeribitError("format", f"Deribit answered HTTP {r.status_code} {str(err.get('message', ''))[:80]}")


def options(cfg: dict, now: float | None = None, fetch=None) -> dict:
    """{'options': [...], 'error': None|{'kind','msg'}} (cached, never raises)."""
    c = cfg.get("options", {}) or {}
    cur = str(c.get("currency", "ETH"))
    now = now if now is not None else time.time()
    ttl = float(c.get("cache_seconds", 300))
    with _lock:
        hit = _cache.get(cur)
    if hit and now - hit["t"] < hit["ttl"]:
        return hit["result"]
    try:
        res, life = {"options": parse_rows((fetch or _fetch)(cur)), "error": None}, ttl
        if not res["options"]:
            raise DeribitError("format", "Deribit returned no options that could be read")
    except DeribitError as e:
        res, life = {"options": [], "error": {"kind": e.kind, "msg": str(e)}}, (120 if e.kind == "rate" else 60)
    with _lock:
        _cache[cur] = {"t": now, "ttl": life, "result": res}
    return res


def clear_cache() -> None:
    with _lock:
        _cache.clear()
