"""HTML building blocks for the dashboard's look (pure functions that return strings, so they can be tested without Streamlit).
Every dynamic text goes through html.escape."""
from __future__ import annotations

import base64
from html import escape

GREEN, RED, AMBER, MUTED, BLUE = "#2DD4A7", "#FF6B7A", "#F5B544", "#8B98A8", "#5B9DFF"
TEXT, SOFT, PANEL, PANEL2, BORDER = "#E6EDF3", "#B6C2D0", "#0F1520", "#121C29", "#1E2A3A"


def _circ(cx: float, cy: float, r: float) -> str:
    return f"M{cx - r:g} {cy:g}a{r:g} {r:g} 0 1 0 {2 * r:g} 0a{r:g} {r:g} 0 1 0 {-2 * r:g} 0"


NONE = "M0 0"
ICONS: dict[str, list[str]] = {   # up to three stroke paths on a 24x24 grid
    "liquidity": ["M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z", NONE, NONE],
    "structure": ["M3 18l5-7 4 4 5-9 4 6", NONE, NONE],
    "orderflow": ["M7 4v14M3 14l4 4 4-4", "M17 20V6M13 10l4-4 4 4", NONE],
    "derivatives": ["M19 5 5 19", _circ(7, 7, 2.2), _circ(17, 17, 2.2)],
    "indicators": ["M4 7h10M18 7h2M4 17h2M10 17h10", _circ(16, 7, 2), _circ(8, 17, 2)],
    "mtf": ["M12 3 3 8l9 5 9-5-9-5z", "M3 13l9 5 9-5", NONE],
    "session": [_circ(12, 12, 9), "M12 7v5l3 2", NONE],
    "orderbook": ["M4 6h12M4 12h16M4 18h9", NONE, NONE],
    "divergence": ["M3 8l8 2 10-5", "M3 18l8-5 10 3", NONE],
    "whales": ["M3 14c0-4 4-7 9-7s9 3 9 7-4 5-9 5c-2 0-3.8-.5-5.2-1.4L3 19z", "M16 11h.01", "M12 7V4M9 8 7 5"],
    "options": ["M4 19V9M10 19V5M16 19v-7M22 19V8", "M3 19h19", NONE],
    "regime": ["M3 12c3-8 5-8 8 0s5 8 8 0 1.5-2.5 2-3", NONE, NONE],
    "volume_profile": ["M4 4v16", "M4 6h9M4 10h14M4 14h6M4 18h11", NONE],
    "btc": ["M8 5h6a3 3 0 0 1 0 6H8zM8 11h7a3 3 0 0 1 0 6H8zM8 5v12", "M10 3v2M13 3v2M10 17v2M13 17v2", NONE],
    "patterns": ["M3 6l4 12 5-9 5 9 4-12", NONE, NONE],
    "liquidations": ["M13 2 4 14h7l-1 8 9-12h-7l1-8z", NONE, NONE],
    "news": ["M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8", "M10 20a2 2 0 0 0 4 0", NONE],
}


def svg_img(svg: str, w: int, h: int, alt: str = "") -> str:
    """Streamlit's HTML sanitiser drops inline <svg>, so pictures are embedded as an <img> with a data URI instead."""
    b64 = base64.b64encode(svg.encode("utf-8")).decode("ascii")
    return f'<img src="data:image/svg+xml;base64,{b64}" width="{w}" height="{h}" alt="{escape(alt)}" style="display:block">'


def direction(bias: float) -> tuple[str, str]:
    """(label, colour) for a bias value."""
    if bias > 0.1:
        return "LONG", GREEN
    if bias < -0.1:
        return "SHORT", RED
    return "NEUTRAL", MUTED


def icon_svg(name: str, color: str, size: int = 20) -> str:
    p = ICONS.get(name, [NONE, NONE, NONE])
    paths = "".join(f'<path d="{d}"/>' for d in p)
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" '
           f'stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{paths}</svg>')
    return svg_img(svg, size, size, name)


def icon_tile(name: str, bias: float, size: int = 34, icon: int = 20) -> str:
    label, col = direction(bias)
    bg = "#172131" if label == "NEUTRAL" else col + "1F"
    stroke = "#9FB4CC" if label == "NEUTRAL" else col
    return (f'<div style="width:{size}px;height:{size}px;border-radius:{round(size * .3)}px;background:{bg};display:flex;'
            f'align-items:center;justify-content:center;flex:none">{icon_svg(name, stroke, icon)}</div>')


def chip(text: str, color: str, solid: bool = False) -> str:
    if solid:
        return (f'<span style="font-size:11px;font-weight:700;letter-spacing:.06em;padding:4px 9px;border-radius:6px;'
                f'color:#0A0E14;background:{color}">{escape(text)}</span>')
    return (f'<span style="font-size:11px;font-weight:700;letter-spacing:.06em;padding:4px 9px;border-radius:999px;'
            f'color:{color};border:1px solid {color}55;background:{color}14;white-space:nowrap">{escape(text)}</span>')


CSS = f"""<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap');
:root{{--green:{GREEN};--red:{RED};--amber:{AMBER};--muted:{MUTED};--panel:{PANEL};--border:{BORDER}}}
.stApp{{background:radial-gradient(1200px 500px at 85% -10%,rgba(91,157,255,.10),transparent 60%),
  radial-gradient(900px 420px at 0% 0%,rgba(45,212,167,.07),transparent 55%),#0A0E14;font-family:Inter,system-ui,sans-serif}}
h1,h2,h3,h4{{font-family:Inter,system-ui,sans-serif!important;letter-spacing:-0.01em}}
[data-testid="stSidebar"]{{background:#0C121B;border-right:1px solid #1B2533}}
[data-testid="stHeader"]{{background:transparent}}
div[data-testid="stTabs"] button[role="tab"]{{min-height:44px;font-weight:600;color:{MUTED}}}
div[data-testid="stTabs"] button[role="tab"][aria-selected="true"]{{color:#fff}}
div[data-testid="stVerticalBlockBorderWrapper"]:has(.agent-card-marker){{background:{PANEL};border:1px solid {BORDER};border-radius:16px;
  transition:transform .18s ease,border-color .18s ease,box-shadow .18s ease}}
div[data-testid="stVerticalBlockBorderWrapper"]:has(.agent-card-marker):hover{{transform:translateY(-2px);border-color:#34495F;box-shadow:0 12px 32px rgba(0,0,0,.4)}}
.stButton>button{{min-height:40px;border-radius:10px;background:#121923;border:1px solid #243246;color:#C9D4E0;font-weight:600;
  transition:background .15s ease,border-color .15s ease,color .15s ease}}
.stButton>button:hover{{background:#1B2738;border-color:#4A6280;color:#fff}}
.stButton>button:focus-visible{{outline:2px solid {BLUE};outline-offset:2px}}
div[data-testid="stPlotlyChart"]{{background:{PANEL};border:1px solid {BORDER};border-radius:18px;padding:8px}}
.ui-card{{background:{PANEL};border:1px solid {BORDER};border-radius:18px;padding:20px;transition:border-color .18s ease}}
.ui-card:hover{{border-color:#34495F}}
.mono{{font-family:'JetBrains Mono',monospace}}
@keyframes pulse{{0%{{box-shadow:0 0 0 0 rgba(45,212,167,.55)}}100%{{box-shadow:0 0 0 10px rgba(45,212,167,0)}}}}
@keyframes sweep{{0%{{transform:scaleX(0)}}100%{{transform:scaleX(1)}}}}
.live-dot{{animation:pulse 1.8s ease-out infinite}}
.bar{{transform-origin:left center;animation:sweep .8s cubic-bezier(.2,.8,.2,1) both}}
@media (prefers-reduced-motion:reduce){{*{{animation:none!important;transition:none!important}}}}
</style>"""


def header_html(live: bool, source: str, ts_text: str, demo: bool) -> str:
    pill_col = GREEN if live else AMBER
    label = f"Live &middot; {escape(source)} &middot; {escape(ts_text)}" if live else f"Demo data &middot; {escape(ts_text)}"
    dot = f'<span class="live-dot" style="width:8px;height:8px;border-radius:50%;background:{pill_col};display:inline-block"></span>'
    return f"""<div style="display:flex;flex-wrap:wrap;align-items:center;gap:12px 24px;padding:2px 0 14px;border-bottom:1px solid #1B2533">
  <div style="display:flex;align-items:center;gap:12px">
    <div style="width:38px;height:38px;border-radius:11px;background:linear-gradient(135deg,{GREEN},{BLUE});display:flex;align-items:center;justify-content:center">
      {svg_img('<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#06121C" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h4l3-8 4 16 3-8h4"/></svg>', 22, 22, "logo")}</div>
    <div><div style="font-size:17px;font-weight:700;color:{TEXT}">ETH Agent Desk</div>
    <div style="font-size:12px;color:{MUTED}">Signals only - no orders are placed</div></div></div>
  <div style="flex-grow:1"></div>
  <div style="display:flex;align-items:center;gap:8px;padding:7px 12px;border-radius:999px;background:{pill_col}12;border:1px solid {pill_col}55;font-size:13px;color:{pill_col}">{dot}{label}</div>
</div>"""


def gauge_html(score: float, need: float) -> str:
    """Half-circle gauge, short on the left and long on the right, with the trade threshold marked."""
    clamp = max(-1.0, min(1.0, score))
    deg = need * 90
    arc = lambda f: f"stroke-dasharray:{125.6 * f:.1f} 400;opacity:{0.95 if f > 0.02 else 0}"
    sc = f"{score:+.2f}"
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 120" width="240" height="144">'
           f'<path d="M 20 100 A 80 80 0 0 1 100 20" fill="none" stroke="#3A1E27" stroke-width="12" stroke-linecap="round"/>'
           f'<path d="M 100 20 A 80 80 0 0 1 180 100" fill="none" stroke="#143A31" stroke-width="12" stroke-linecap="round"/>'
           f'<path d="M 100 20 A 80 80 0 0 0 20 100" fill="none" stroke="{RED}" stroke-width="12" stroke-linecap="round" style="{arc(max(0.0, -clamp))}"/>'
           f'<path d="M 100 20 A 80 80 0 0 1 180 100" fill="none" stroke="{GREEN}" stroke-width="12" stroke-linecap="round" style="{arc(max(0.0, clamp))}"/>'
           f'<g stroke="{TEXT}" stroke-width="2" opacity=".8"><line x1="100" y1="8" x2="100" y2="14" transform="rotate({-deg:.1f} 100 100)"/>'
           f'<line x1="100" y1="8" x2="100" y2="14" transform="rotate({deg:.1f} 100 100)"/></g>'
           f'<line x1="100" y1="100" x2="100" y2="36" stroke="{TEXT}" stroke-width="3" stroke-linecap="round" '
           f'transform="rotate({clamp * 90:.1f} 100 100)"/><circle cx="100" cy="100" r="7" fill="{TEXT}"/></svg>')
    return f"""<div style="position:relative;width:240px;margin:0 auto">
{svg_img(svg, 240, 144, "Composite score " + sc)}
<div style="text-align:center;margin-top:2px;font:600 30px 'JetBrains Mono',monospace;color:{TEXT}">{sc}</div></div>
<div style="display:flex;justify-content:space-between;font-size:12px;color:{MUTED};padding:6px 10px 0"><span>Short</span><span>needs &plusmn;{need:g}</span><span>Long</span></div>"""


def decision_html(plan, score: float, need: float) -> str:
    """The desk decision card: gauge plus what the desk wants to do."""
    if plan.side == "NONE":
        title, col, text = "NO TRADE", TEXT, (plan.reasons[0] if plan.reasons else "Nothing to do.")
        text = text.replace("No trade: ", "", 1)
        bg, border = PANEL2, "#243246"
    else:
        col = GREEN if plan.side == "LONG" else RED
        if plan.approved:
            title = f"{plan.side} approved"
            text = (f"{plan.strategy}: entry {plan.entry:.2f}, stop {plan.stop:.2f}, TP1 {plan.tp1:.2f}, TP2 {plan.tp2:.2f}, "
                    f"RR {plan.rr}. Size {plan.size} lots, risk ${plan.risk_usd:,.0f}. Setup score {plan.confidence:.0%} (not a win probability).")
        else:
            title = f"{plan.side} blocked by risk"
            text = " ".join(plan.vetoes) if plan.vetoes else "The risk agent blocked this trade."
            col = AMBER
        bg, border = col + "12", col + "55"
    return f"""<div class="ui-card" style="background:linear-gradient(180deg,#131B27,#0F1520);display:flex;flex-direction:column;gap:12px">
<div style="display:flex;align-items:center;justify-content:space-between"><div style="font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:{MUTED}">Desk decision</div></div>
{gauge_html(score, need)}
<div style="padding:16px;border-radius:14px;background:{bg};border:1px solid {border}">
<div style="font-size:22px;font-weight:700;color:{col}">{escape(title)}</div>
<div style="margin-top:6px;font-size:14px;line-height:1.5;color:{SOFT}">{escape(text)}</div></div></div>"""


def _bar(label: str, value: str, note: str, frac: float, color: str) -> str:
    frac = max(0.0, min(1.0, frac))
    return f"""<div style="display:flex;flex-direction:column;gap:8px">
<div style="display:flex;justify-content:space-between;align-items:baseline"><span style="font-size:13px;color:{SOFT}">{escape(label)}</span><span class="mono" style="font-weight:600;font-size:14px;color:{TEXT}">{escape(value)}</span></div>
<div style="height:8px;border-radius:8px;background:#172131;overflow:hidden"><div class="bar" style="height:100%;width:{frac * 100:.0f}%;background:{color};border-radius:8px;box-shadow:0 0 10px {color}88"></div></div>
<div style="font-size:12px;color:{MUTED}">{escape(note)}</div></div>"""


def rules_html(daily_left: float, max_daily: float, dd_left: float, max_dd: float, trades: int, max_trades: int,
               open_trades: int, max_open: int, streak: int, max_streak: int, locked: list[str],
               pnl_today: float, pnl_total: float, target: float | None = None, label: str = "paper") -> str:
    m = lambda x: f"${x:,.0f}"
    used = lambda left, lim: (1 - left / lim) if lim else 0.0
    ok = not locked
    status_col = GREEN if ok else RED
    status = "Within limits" if ok else "Blocked: " + ", ".join(locked)
    icon = svg_img(f'<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="{status_col}" stroke-width="2.4" '
                   f'stroke-linecap="round" stroke-linejoin="round">{"<path d=" + chr(34) + "M20 6 9 17l-5-5" + chr(34) + "/>" if ok else "<path d=" + chr(34) + "M6 6l12 12M18 6 6 18" + chr(34) + "/>"}</svg>', 14, 14)
    bars = (_bar("Daily loss left", f"{m(daily_left)} / {m(max_daily)}", f"Today's P&L {m(pnl_today)}", used(daily_left, max_daily),
                 GREEN if used(daily_left, max_daily) < .6 else AMBER if used(daily_left, max_daily) < .85 else RED)
            + _bar("Drawdown left", f"{m(dd_left)} / {m(max_dd)}", f"Total P&L {m(pnl_total)}", used(dd_left, max_dd),
                   GREEN if used(dd_left, max_dd) < .6 else AMBER if used(dd_left, max_dd) < .85 else RED))
    if target:
        bars += _bar("Profit target", f"{m(max(0, pnl_total))} / {m(target)}", f"{max(0.0, pnl_total) / target:.0%} of the way", max(0.0, pnl_total) / target, BLUE)
    tile = lambda lab, a, b: (f'<div style="flex:1;padding:10px 12px;border-radius:12px;background:{PANEL2};border:1px solid #1B2738">'
                              f'<div style="font-size:12px;color:{MUTED}">{lab}</div><div class="mono" style="font-weight:600;font-size:18px;color:{TEXT}">{a}'
                              f'<span style="color:{MUTED};font-size:13px"> / {b}</span></div></div>')
    return f"""<div class="ui-card" style="display:flex;flex-direction:column;gap:16px;height:100%;box-sizing:border-box">
<div style="display:flex;align-items:center;justify-content:space-between;gap:8px"><div style="font-size:15px;font-weight:600;color:{TEXT}">Account rules <span style="font-size:11px;color:{MUTED};font-weight:500">({escape(label)})</span></div>
<div style="display:flex;align-items:center;gap:6px;font-size:12px;font-weight:600;color:{status_col};padding:5px 10px;border-radius:999px;background:{status_col}12;border:1px solid {status_col}55">
{icon}{escape(status)}</div></div>
{bars}
<div style="display:flex;gap:10px">{tile("Trades today", trades, max_trades)}{tile("Active", open_trades, max_open)}{tile("Loss streak", streak, max_streak)}</div></div>"""


def agent_card_html(name: str, title: str, bias: float, conf: float, weight_share: float | None, summary: str,
                    n_setups: int, veto: bool = False) -> str:
    label, col = direction(bias)
    left = 50 if bias >= 0 else 50 + bias * 50
    width = abs(bias) * 50
    setup = (f'<span style="font-size:12px;font-weight:600;color:{AMBER}">{n_setups} setup{"s" if n_setups != 1 else ""} found</span>'
             if n_setups else f'<span style="font-size:12px;color:{MUTED}">No setup right now</span>')
    w = f"{weight_share:.0%}" if weight_share is not None else "n/a"
    veto_chip = chip("VETO", RED, solid=True) if veto else ""
    return f"""<span class="agent-card-marker" style="display:none"></span>
<div style="display:flex;flex-direction:column;gap:12px;padding:2px 2px 0">
<div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
<div style="display:flex;align-items:center;gap:10px">{icon_tile(name, bias)}<div style="font-size:15px;font-weight:600;color:{TEXT}">{escape(title)}</div></div>
<div style="display:flex;gap:6px">{veto_chip}{chip(label, col)}</div></div>
<div style="position:relative;height:10px;border-radius:10px;background:#172131">
<div style="position:absolute;left:50%;top:-3px;bottom:-3px;width:2px;background:#3A4B61"></div>
<div class="bar" style="position:absolute;top:0;bottom:0;border-radius:10px;left:{left:.1f}%;width:{width:.1f}%;background:{col};box-shadow:0 0 14px {col}66"></div></div>
<div style="display:flex;justify-content:space-between;font-size:12px;color:{MUTED}">
<span>Bias <b class="mono" style="color:{TEXT}">{bias:+.2f}</b></span><span>Confidence <b class="mono" style="color:{TEXT}">{conf:.0%}</b></span><span>Weight <b class="mono" style="color:{TEXT}">{w}</b></span></div>
<div style="font-size:13px;line-height:1.5;color:{SOFT};min-height:58px">{escape(summary)}</div>
<div>{setup}</div></div>"""


def ladder_html(side: str, entry: float, stop: float, tp1: float, tp2: float) -> str:
    """Price strip: stop, entry and targets in their real positions, with the risk and reward zones tinted."""
    ps = [entry, stop, tp1, tp2]
    lo, hi = min(ps) - 3, max(ps) + 3
    pc = lambda p: (p - lo) / (hi - lo) * 100
    zone = lambda a, b, col: (f'<div style="position:absolute;top:18px;height:8px;border-radius:8px;left:{min(pc(a), pc(b)):.1f}%;'
                              f'width:{abs(pc(a) - pc(b)):.1f}%;background:{col}"></div>')
    mark = lambda p, lab, col: (f'<div style="position:absolute;top:0;left:{pc(p):.1f}%;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center">'
                                f'<div style="position:absolute;top:10px;width:3px;height:24px;border-radius:3px;background:{col}"></div>'
                                f'<div style="margin-top:22px;font-size:11px;letter-spacing:.06em;color:{MUTED};white-space:nowrap">{lab}</div>'
                                f'<div class="mono" style="font-weight:600;font-size:12px;white-space:nowrap;color:{TEXT}">{p:.1f}</div></div>')
    return (f'<div style="position:relative;height:72px;margin:6px 14px 0"><div style="position:absolute;left:0;right:0;top:18px;height:8px;border-radius:8px;background:#172131"></div>'
            + zone(entry, stop, "rgba(255,107,122,.55)") + zone(entry, tp2, "rgba(45,212,167,.45)")
            + mark(stop, "STOP", RED) + mark(entry, "ENTRY", TEXT) + mark(tp1, "TP1", GREEN) + mark(tp2, "TP2", GREEN) + "</div>")


STATUS = {"selected": ("Chosen as the trade", GREEN), "passed": ("Passed all checks, another setup ranked higher", BLUE),
          "rejected": ("Not taken", AMBER)}


def setup_html(s: dict) -> str:
    label, col = STATUS.get(s["status"], (s["status"], MUTED))
    side_col = GREEN if s["side"] == "LONG" else RED
    pill = (f'<span style="font-size:12px;font-weight:600;color:{col};padding:5px 10px;border-radius:999px;border:1px solid {col}55;background:{col}12">{escape(label)}</span>')
    agents = ", ".join(a.capitalize() for a in s.get("agents", []))
    stat = lambda k, v: (f'<span style="padding:6px 10px;border-radius:8px;background:{PANEL2};font-size:12px;color:{SOFT}">{k} '
                         f'<b class="mono" style="color:{TEXT}">{escape(str(v))}</b></span>')
    return f"""<div class="ui-card" style="display:flex;flex-direction:column;gap:14px;margin-bottom:12px">
<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
<div style="display:flex;align-items:center;gap:10px">{chip(s['side'], side_col, solid=True)}<span style="font-size:15px;font-weight:600;color:{TEXT}">{escape(s['strategy'])}</span>
<span style="font-size:12px;color:{MUTED}">{escape(s['entry_type'].lower())}</span></div>{pill}</div>
{ladder_html(s['side'], s['entry'], s['stop'], s['tp1'], s['tp2'])}
<div style="display:flex;gap:10px;flex-wrap:wrap">{stat("Reward / risk", s['rr'])}{stat("Quality", f"{s['quality']:.0%}")}{stat("Built on", agents)}</div>
<div style="font-size:13px;line-height:1.5;color:{SOFT}">{escape(s['note'])}. {escape(s['reason'])}. Levels are indicative until the risk agent signs off.</div></div>"""


def tiles_html(items: list[tuple[str, str, str, str]]) -> str:
    """items = (label, value, note, colour) -> a row of stat tiles."""
    cells = "".join(
        f'<div style="flex:1 1 160px;padding:16px 18px;border-radius:14px;background:{PANEL2};border:1px solid #1B2738">'
        f'<div style="font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:{MUTED}">{escape(a)}</div>'
        f'<div class="mono" style="margin-top:6px;font-weight:600;font-size:26px;color:{c}">{escape(b)}</div>'
        f'<div style="margin-top:2px;font-size:12px;color:{MUTED}">{escape(n)}</div></div>' for a, b, n, c in items)
    return f'<div style="display:flex;flex-wrap:wrap;gap:14px">{cells}</div>'
