"""TradingSystem: wires the agents together. One call = one full desk cycle."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

import pandas as pd

from agents.data_agent import DataAgent
from agents.derivatives_agent import DerivativesAgent
from agents.indicators_agent import IndicatorsAgent
from agents.journal_agent import JournalAgent
from agents.liquidation_agent import LiquidationAgent
from agents.liquidity_agent import LiquidityAgent
from agents.manager_agent import ManagerAgent
from agents.mtf_agent import MultiTimeframeAgent
from agents.news_agent import NewsAgent
from agents.orderbook_agent import OrderBookAgent
from agents.btc_agent import BtcAgent
from agents.divergence_agent import DivergenceAgent
from agents.options_agent import OptionsAgent
from agents.whale_agent import WhaleAgent
from agents.pattern_agent import PatternAgent
from agents.regime_agent import RegimeAgent
from agents.volume_profile_agent import VolumeProfileAgent
from agents.orderflow_agent import OrderFlowAgent
from agents.risk_agent import RiskAgent
from agents.session_agent import SessionAgent
from agents.structure_agent import StructureAgent
from core.llm import explain, review
from core.models import AgentReport, MarketSnapshot, TradePlan, tf_minutes
from core.notifier import Notifier
from core.report import format_plan


@dataclass
class CycleResult:
    snapshot: MarketSnapshot
    reports: dict
    plan: TradePlan
    narrative: str | None
    text: str
    settled: list | None = None


class TradingSystem:
    def __init__(self, cfg: dict, demo: bool = False, seed: int = 7, demo_end=None,
                 journal_path: str | None = None):
        self.cfg, self.demo = cfg, demo
        self.tf = cfg["market"]["entry_tf"]
        self.data = DataAgent(cfg, demo=demo, seed=seed, demo_end=demo_end)
        self.analysts = [LiquidityAgent(cfg), StructureAgent(cfg), PatternAgent(cfg), RegimeAgent(cfg), DivergenceAgent(cfg), VolumeProfileAgent(cfg), BtcAgent(cfg), OrderFlowAgent(cfg),
                         DerivativesAgent(cfg), IndicatorsAgent(cfg), MultiTimeframeAgent(cfg),
                         SessionAgent(cfg), OrderBookAgent(cfg), WhaleAgent(cfg), OptionsAgent(cfg), LiquidationAgent(cfg), NewsAgent(cfg, offline=demo)]
        if not demo:
            from core.liqstream import ensure_running
            ensure_running(cfg)         # background thread that records Binance liquidations (no-op if disabled)
        self.risk = RiskAgent(cfg)
        self.manager = ManagerAgent(cfg, self.risk)
        if journal_path is None and demo:
            journal_path = cfg["journal"]["path"].replace("journal.db", "journal_demo.db")
        self.journal = JournalAgent(cfg, journal_path)
        self.notifier = Notifier(cfg)

    # ---- one analysis pass on any snapshot (live, demo, or a replayed moment in the past) ----
    def analyze(self, snap: MarketSnapshot, use_journal: bool = True, use_llm: bool = True) -> tuple[dict, TradePlan]:
        with ThreadPoolExecutor(max_workers=len(self.analysts)) as ex:
            futs = {a.name: ex.submit(a.safe_analyze, snap) for a in self.analysts}
            reports = {n: f.result() for n, f in futs.items()}
        state = self.journal.risk_state(snap.ts) if use_journal else None
        if state is None:
            from core.models import RiskState
            state = RiskState()
        plan = self.manager.decide(snap, reports, state, snap.ts)
        if use_llm and plan.approved:
            review(plan, reports, self.cfg)  # may reject or halve the plan; can never enlarge it
        return reports, plan

    def replay(self, full: MarketSnapshot, t) -> tuple[MarketSnapshot, dict, TradePlan]:
        """Re-run the desk exactly as it would have looked at time t (only candles closed by t are visible)."""
        snap = full.until(pd.Timestamp(t))
        reports, plan = self.analyze(snap, use_journal=False, use_llm=False)
        return snap, reports, plan

    def run_once(self, record: bool = True, notify: bool = False) -> CycleResult:
        snap = self.data.snapshot()
        settled = None
        if record:  # first update the paper trades from the candles that closed since the last cycle
            settled = self.journal.settle(snap.candles[self.tf], tf_minutes(self.tf), snap.ts)
        reports, plan = self.analyze(snap)
        narrative = explain(plan, reports, self.cfg)
        text = format_plan(self.cfg["market"]["display_symbol"], self.tf, plan, reports, narrative)

        if settled:
            for t in settled:
                text += f"\nPaper trade #{t['id']} {t['status']}: {t['notes']} ({t['r_mult'] if t['r_mult'] is not None else 0:+.2f}R)"
        if plan.approved and record and not self.journal.recent_signal(plan.side, 60, snap.ts):
            plan.id = self.journal.record_signal(plan, reports)
            if self.journal.paper:
                text += f"\n\nLogged as paper trade #{plan.id} (tracked automatically)."
            else:
                text += (f"\n\nLogged as signal #{plan.id}. Tell the journal what you did: "
                         f"python main.py journal take {plan.id}   or   journal skip {plan.id}")
            if notify:
                self.notifier.send(text)
        return CycleResult(snap, reports, plan, narrative, text, settled)
