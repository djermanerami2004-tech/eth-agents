"""Coinglass API client for LARGE LIMIT ORDERS ("whale walls"): GET /api/futures/orderbook/large-limit-order.

Documented fields (docs.coinglass.com): id, exchange_name, symbol, limit_price, start_time, start_quantity, start_usd_value,
current_quantity, current_usd_value, current_time, executed_volume, executed_usd_value, trade_count, order_side
(1 = sell / ask, 2 = buy / bid), order_state (1 = open, 2 = finished, 3 = canceled), order_end_time.
The endpoint needs the Standard plan or higher (not Hobbyist / Startup). The key is read from COINGLASS_API_KEY (.env) and is
never logged. Answers are cached so a dashboard that refreshes often does not burn the rate limit. This module is only ever
asked for LIVE data: Coinglass has no history for the past.
"""
from __future__ import annotations

import os
import threading
import time

BASE = "https://open-api-v4.coinglass.com"
PATH = "/api/futures/orderbook/large-limit-order"
_lock = threading.Lock()
_cache: dict = {}          # (exchange, symbol) -> {"t": float, "result": dict}


class CoinglassError(Exception):
    def __init__(self, kind: str, msg: str):
        super().__init__(msg)
        self.kind = kind           # 'nokey' | 'plan' | 'key' | 'rate' | 'network' | 'format'


def _fetch(exchange: str, symbol: str, key: str, timeout: float = 15.0) -> list[dict]:
    import requests
    try:
        r = requests.get(BASE + PATH, params={"exchange": exchange, "symbol": symbol}, timeout=timeout,
                         headers={"CG-API-KEY": key, "accept": "application/json"})
    except requests.RequestException as e:
        raise CoinglassError("network", f"could not reach Coinglass ({type(e).__name__})")
    try:
        body = r.json()
    except ValueError:
        raise CoinglassError("format", f"Coinglass answered HTTP {r.status_code} with something that is not JSON")
    code, msg = str(body.get("code", "")), str(body.get("msg", ""))
    if code == "0" and isinstance(body.get("data"), list):
        return body["data"]
    low = msg.lower()
    if code == "40004" or "upgrade" in low or "plan" in low or "not available" in low or "permission" in low:
        raise CoinglassError("plan", "your Coinglass plan does not include large orders (it needs Standard or higher)")
    if code == "40001" or "api key" in low or "apikey" in low or "invalid key" in low:
        raise CoinglassError("key", "Coinglass rejected the API key (copy it again into .env, or reset it)")
    if code == "40003" or r.status_code == 429 or "rate" in low or "limit" in low:
        raise CoinglassError("rate", "Coinglass rate limit hit, waiting a bit")
    raise CoinglassError("format", f"Coinglass answered code {code or '-'} {msg[:80]} (HTTP {r.status_code})")


def clean(records: list[dict]) -> list[dict]:
    """Keep the documented fields we need as plain numbers; drop records that do not parse."""
    out = []
    for x in records:
        try:
            out.append({"price": float(x["limit_price"]), "side": "ask" if int(x["order_side"]) == 1 else "bid",
                        "state": int(x["order_state"]), "usd": float(x["current_usd_value"]),
                        "start_usd": float(x.get("start_usd_value") or x["current_usd_value"]),
                        "executed_usd": float(x.get("executed_usd_value") or 0.0),
                        "start_ms": int(x["start_time"]), "end_ms": int(x["order_end_time"]) if x.get("order_end_time") else None,
                        "exchange": str(x.get("exchange_name", ""))})
        except (KeyError, TypeError, ValueError):
            continue
    return out


def large_orders(cfg: dict, now: float | None = None) -> dict:
    """{'orders': [...], 'error': None|{'kind','msg'}} for every exchange/symbol in config (cached, never raises).
    A plan or key error is remembered for 30 minutes (no point asking again); rate limits for 2 minutes."""
    c = cfg.get("coinglass", {}) or {}
    key = os.getenv("COINGLASS_API_KEY", "").strip()
    if not key:
        return {"orders": [], "error": {"kind": "nokey", "msg": "no COINGLASS_API_KEY in .env"}}
    now = now if now is not None else time.time()
    ttl = float(c.get("cache_seconds", 60))
    pairs = c.get("large_orders") or [{"exchange": "Binance", "symbol": cfg["market"]["symbol"]}]
    orders, error = [], None
    for p in pairs:
        ck = (p["exchange"], p["symbol"])
        with _lock:
            hit = _cache.get(ck)
        if hit and now - hit["t"] < hit["ttl"]:
            res = hit["result"]
        else:
            try:
                res, life = {"orders": clean(_fetch(p["exchange"], p["symbol"], key)), "error": None}, ttl
            except CoinglassError as e:
                life = {"plan": 1800, "key": 1800, "rate": 120}.get(e.kind, 60)
                res = {"orders": [], "error": {"kind": e.kind, "msg": str(e)}}
            with _lock:
                _cache[ck] = {"t": now, "ttl": life, "result": res}
        orders += res["orders"]
        error = error or res["error"]
    return {"orders": orders, "error": error if not orders else None}


def clear_cache() -> None:
    with _lock:
        _cache.clear()
