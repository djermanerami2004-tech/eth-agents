"""Optional Claude layer. Everything here is OFF unless llm.enabled / llm.review and ANTHROPIC_API_KEY are set.

- explain(): writes a short plain-language explanation of the plan.
- review():  a sceptical second opinion on a plan the other agents already APPROVED. It can reject the trade
             or halve its size. It can never create, enlarge or approve a trade - the risk agent keeps the veto.
"""
from __future__ import annotations

import json
import os
import re

from core.models import AgentReport, TradePlan

REVIEW_SYSTEM = (
    "You are the sceptical reviewer on a trading desk for an ETH CFD prop-firm account. Other agents have "
    "already approved a trade plan. Look for reasons NOT to take it: contradictions between the agents, a "
    "weak or stale setup, a target too close, a stop that sits in an obvious liquidity pool, events that make "
    "the setup unreliable. Reply with ONLY a JSON object: "
    '{"verdict": "approve" | "reduce" | "reject", "reasons": ["short reason", ...]}. '
    "Use reject only for a clear flaw, reduce for real doubt, approve otherwise. Never promise profit."
)


def _facts(reports: dict[str, AgentReport]) -> str:
    return "\n".join(f"- {r.agent}: bias {r.bias:+.2f}, conf {r.confidence:.2f}: {r.summary}" for r in reports.values())


def _client(cfg: dict, flag: str):
    key = os.getenv("ANTHROPIC_API_KEY")
    llm = cfg.get("llm", {}) or {}
    if not (llm.get(flag) and key):
        return None
    try:
        import anthropic
        return anthropic.Anthropic(api_key=key)
    except Exception:
        return None


def explain(plan: TradePlan, reports: dict[str, AgentReport], cfg: dict, client=None) -> str | None:
    client = client or _client(cfg, "enabled")
    if client is None or plan.side == "NONE":
        return None
    try:
        prompt = (f"You are the desk analyst. In 4 short lines, explain this ETH trade plan to the trader, "
                  f"mention the main risk to the idea, and do not promise profit.\n"
                  f"Plan: {plan.side} {plan.entry_type} entry {plan.entry:.2f}, stop {plan.stop:.2f}, "
                  f"TP1 {plan.tp1:.2f}, RR {plan.rr}, approved={plan.approved}, vetoes={plan.vetoes}\n{_facts(reports)}")
        msg = client.messages.create(model=cfg["llm"]["model"], max_tokens=300,
                                     messages=[{"role": "user", "content": prompt}])
        return msg.content[0].text
    except Exception:
        return None


def parse_verdict(text: str) -> dict | None:
    """Pull the JSON verdict out of a model reply; anything unparseable means 'no opinion'."""
    m = re.search(r"\{.*\}", text or "", re.S)
    if not m:
        return None
    try:
        d = json.loads(m.group(0))
    except Exception:
        return None
    verdict = str(d.get("verdict", "")).lower()
    if verdict not in ("approve", "reduce", "reject"):
        return None
    reasons = d.get("reasons") or []
    return {"verdict": verdict, "reasons": [str(x)[:200] for x in reasons][:4]}


def apply_verdict(plan: TradePlan, verdict: dict, cfg: dict) -> TradePlan:
    """Veto-only: the verdict can lower risk, never raise it."""
    why = "; ".join(verdict["reasons"]) or "no reason given"
    if verdict["verdict"] == "reject":
        plan.vetoes.append(f"AI reviewer rejected: {why}")
        plan.approved = False
    elif verdict["verdict"] == "reduce":
        step = cfg["account"]["lot_step"]
        new_size = int((plan.size * 0.5) / step + 1e-9) * step
        if new_size < step:
            plan.vetoes.append(f"AI reviewer wanted a smaller size but it would be below one lot: {why}")
            plan.approved = False
        else:
            factor = new_size / plan.size
            plan.size = round(new_size, 4)
            plan.risk_usd = round(plan.risk_usd * factor, 2)
            plan.reasons.append(f"AI reviewer halved the size: {why}")
    return plan


def review(plan: TradePlan, reports: dict[str, AgentReport], cfg: dict, client=None) -> dict | None:
    client = client or _client(cfg, "review")
    if client is None or plan.side == "NONE" or not plan.approved:
        return None
    try:
        prompt = (f"Plan: {plan.side} {plan.entry_type} entry {plan.entry:.2f}, stop {plan.stop:.2f}, "
                  f"TP1 {plan.tp1:.2f}, TP2 {plan.tp2:.2f}, RR {plan.rr}, size {plan.size} lots, "
                  f"risk ${plan.risk_usd:.0f}\nReasons: {plan.reasons[:1]}\nAgents:\n{_facts(reports)}")
        msg = client.messages.create(model=cfg["llm"]["model"], max_tokens=300, system=REVIEW_SYSTEM,
                                     messages=[{"role": "user", "content": prompt}])
        verdict = parse_verdict(msg.content[0].text)
    except Exception:
        return None
    if verdict:
        apply_verdict(plan, verdict, cfg)
    return verdict
