"""Chart pattern detection from confirmed swing pivots (pure functions, no look-ahead).

A pivot needs `k` candles on each side to exist, so the newest k candles never hold one: a pattern can only be found
from information that was already available. Patterns found:

  double top / double bottom, head & shoulders / inverse H&S, bull / bear flag,
  ascending / descending / symmetrical triangle, rising / falling wedge.

Every pattern is a dict:
  name, tf, dir (+1 bullish / -1 bearish), status ('broken' = a candle closed through the pattern's trigger line,
  'forming' = not yet), break_level, since (candles since the break), target (measured move), stop_ref
  (invalidation), quality 0..1, lines [[(ts_ms, price), (ts_ms, price)]], points [(ts_ms, price)].
Bearish "top" shapes are written once and mirrored for the bullish version by flipping prices.
These are textbook rules with tolerances in ATR units, not a promise that a pattern works: the backtest tab
tells you what the pattern strategy did on your data.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from core.indicators import swings


def _pivots(df: pd.DataFrame, k: int):
    sh, sl = swings(df, k, k)
    hi = [(i, float(v)) for i, v in enumerate(sh.values) if v == v]
    lo = [(i, float(v)) for i, v in enumerate(sl.values) if v == v]
    return hi, lo


def _flip(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["open"], out["close"] = -df["open"], -df["close"]
    out["high"], out["low"] = -df["low"], -df["high"]
    return out


def _vol_ok(df: pd.DataFrame, i: int) -> bool:
    base = df["volume"].iloc[max(0, i - 20):i]
    return len(base) >= 5 and float(df["volume"].iloc[i]) > 1.2 * float(base.mean())


def _line(p0, p1):
    (x0, y0), (x1, y1) = p0, p1
    s = (y1 - y0) / (x1 - x0) if x1 != x0 else 0.0
    return lambda x: y0 + s * (x - x0)


def _first_close_beyond(df, start, fn, sign, a, margin=0.1):
    """First index >= start whose close is beyond line fn(x) (sign=-1 below, +1 above), else None."""
    c = df["close"].values
    for i in range(start, len(df)):
        if sign * (c[i] - fn(i)) > margin * a:
            return i
    return None


# ----------------------------------------------------------------------------- bearish tops (mirrored for bottoms)
def _double_top(df, a, piv, max_age):
    hi, lo = piv
    n = len(df)
    if len(hi) < 2:
        return None
    (i1, p1), (i2, p2) = hi[-2], hi[-1]
    if abs(p1 - p2) > 0.7 * a or not 8 <= i2 - i1 <= 90:
        return None
    seg = df.iloc[i1:i2 + 1]
    j = i1 + int(np.argmin(seg["low"].values))
    neck = float(df["low"].iloc[j])
    peak = max(p1, p2)
    if min(p1, p2) - neck < 1.5 * a:
        return None
    if (df["close"].iloc[i1:] > peak + 0.3 * a).any():
        return None
    return _top_result("double top", df, a, n, i2, neck, lambda x: neck, peak, p1 - neck + (p2 - p1) / 2,
                       [(i1, p1), (i2, p2), (j, neck)],
                       [[(i1, p1), (i2, p2)], [(j, neck), (n - 1, neck)]],
                       0.55 + 0.25 * (1 - abs(p1 - p2) / (0.7 * a)), max_age)


def _head_shoulders(df, a, piv, max_age):
    hi, lo = piv
    n = len(df)
    if len(hi) < 3:
        return None
    (iL, pL), (iH, pH), (iR, pR) = hi[-3:]
    if pH - max(pL, pR) < 0.8 * a or abs(pL - pR) > 1.5 * a:
        return None
    if not (5 <= iH - iL <= 70 and 5 <= iR - iH <= 70):
        return None
    j1 = iL + int(np.argmin(df["low"].values[iL:iH + 1]))
    j2 = iH + int(np.argmin(df["low"].values[iH:iR + 1]))
    t1, t2 = float(df["low"].iloc[j1]), float(df["low"].iloc[j2])
    neck = _line((j1, t1), (j2, t2))
    height = pH - neck(iH)
    if height < 1.5 * a or (df["close"].iloc[iL:] > pH + 0.3 * a).any():
        return None
    return _top_result("head and shoulders", df, a, n, iR, neck(n - 1), neck, pR, height,
                       [(iL, pL), (iH, pH), (iR, pR), (j1, t1), (j2, t2)],
                       [[(j1, t1), (n - 1, neck(n - 1))], [(iL, pL), (iH, pH)], [(iH, pH), (iR, pR)]],
                       0.5 + 0.25 * (1 - abs(pL - pR) / (1.5 * a)) + (0.1 if height >= 2.5 * a else 0.0), max_age)


def _top_result(name, df, a, n, i_last, neck_now, neck_fn, stop_ref, height, points, lines, quality, max_age):
    """Shared break logic for bearish tops: a close below the neckline breaks the pattern."""
    b = _first_close_beyond(df, i_last + 1, neck_fn, -1, a)
    if b is not None:
        since = n - 1 - b
        if since > max_age or df["close"].iloc[-1] > neck_fn(n - 1) + 0.5 * a:      # too old, or it climbed back inside
            return None
        q = min(1.0, quality + (0.15 if _vol_ok(df, b) else 0.0))
        lines = [ln[:] for ln in lines]
        return {"name": name, "dir": -1, "status": "broken", "since": since, "break_level": float(neck_fn(b)),
                "target": float(neck_fn(b) - height), "stop_ref": float(stop_ref), "quality": q, "points": points,
                "lines": lines}
    if n - 1 - i_last > 25 or df["close"].iloc[-1] < neck_fn(n - 1) - 0.1 * a:
        return None
    return {"name": name, "dir": -1, "status": "forming", "since": None, "break_level": float(neck_fn(n - 1)),
            "target": float(neck_fn(n - 1) - height), "stop_ref": float(stop_ref), "quality": quality * 0.8,
            "points": points, "lines": lines}


def _bull_flag(df, a, piv, max_age):
    n = len(df)
    if n < 50:
        return None
    lo_i = n - 40
    e = lo_i + int(np.argmax(df["high"].values[lo_i:n - 4]))          # top of the pole
    pole_low = float(df["low"].iloc[max(0, e - 14):e + 1].min())
    pole_i = max(0, e - 14) + int(np.argmin(df["low"].values[max(0, e - 14):e + 1]))
    height = float(df["high"].iloc[e]) - pole_low
    if height < 3.0 * a or e - pole_i < 2:
        return None
    hi_e = float(df["high"].iloc[e])
    broke = None
    for i in range(e + 4, n):
        ch = float(df["high"].iloc[e + 1:i].max())
        if df["close"].iloc[i] > ch + 0.1 * a:
            broke = i
            break
    end = broke if broke is not None else n
    cons = df.iloc[e + 1:end]
    if len(cons) < 4 or len(cons) > 30:
        return None
    ch, cl = float(cons["high"].max()), float(cons["low"].min())
    if (hi_e - cl) / height > 0.5 or (ch - cl) > 0.6 * height or ch > hi_e + 0.3 * a:
        return None
    pts = [(pole_i, pole_low), (e, hi_e)]
    lines = [[(pole_i, pole_low), (e, hi_e)], [(e + 1, ch), (end - 1, ch)], [(e + 1, cl), (end - 1, cl)]]
    if broke is not None:
        since = n - 1 - broke
        if since > max_age or df["close"].iloc[-1] < ch - 0.5 * a:
            return None
        return {"name": "bull flag", "dir": 1, "status": "broken", "since": since, "break_level": ch, "target": ch + height,
                "stop_ref": cl, "quality": min(1.0, 0.55 + (0.15 if _vol_ok(df, broke) else 0.0) + 0.1 * (height >= 5 * a)),
                "points": pts, "lines": lines}
    return {"name": "bull flag", "dir": 1, "status": "forming", "since": None, "break_level": ch, "target": ch + height,
            "stop_ref": cl, "quality": 0.45, "points": pts, "lines": lines}


# ----------------------------------------------------------------------------- triangles and wedges (both directions)
def _triangle_wedge(df, a, piv, max_age):
    hi, lo = piv
    n = len(df)
    hi = [p for p in hi if p[0] >= n - 150][-4:]
    lo = [p for p in lo if p[0] >= n - 150][-4:]
    if len(hi) < 2 or len(lo) < 2 or len(hi) + len(lo) < 5:
        return None
    start = min(hi[0][0], lo[0][0])
    last_piv = max(hi[-1][0], lo[-1][0])
    span = n - 1 - start
    if not 20 <= span <= 150:
        return None
    fu = np.polyfit([p[0] for p in hi], [p[1] for p in hi], 1)
    fl = np.polyfit([p[0] for p in lo], [p[1] for p in lo], 1)
    up_line = lambda x: fu[0] * x + fu[1]
    lo_line = lambda x: fl[0] * x + fl[1]
    if max(abs(up_line(i) - p) for i, p in hi) > 0.6 * a or max(abs(lo_line(i) - p) for i, p in lo) > 0.6 * a:
        return None
    w0, w1 = up_line(start) - lo_line(start), up_line(n - 1) - lo_line(n - 1)
    if w0 <= 1.5 * a or w1 <= 0 or w1 > 0.65 * w0:
        return None
    u, l = fu[0] * span, fl[0] * span
    tol = 0.15 * w0
    flat = lambda x: abs(x) <= tol
    up = lambda x: x > tol
    dn = lambda x: x < -tol
    if flat(u) and up(l):
        name, hint = "ascending triangle", 1
    elif dn(u) and flat(l):
        name, hint = "descending triangle", -1
    elif dn(u) and up(l):
        name, hint = "symmetrical triangle", 0
    elif up(u) and up(l) and l > u:
        name, hint = "rising wedge", -1
    elif dn(u) and dn(l) and u < l:
        name, hint = "falling wedge", 1
    else:
        return None
    c = df["close"].values
    for i in range(start, min(last_piv + 1, n)):                      # price must have lived inside the lines
        if c[i] > up_line(i) + 0.4 * a or c[i] < lo_line(i) - 0.4 * a:
            return None
    touches = len(hi) + len(lo)
    q0 = 0.45 + 0.05 * min(3, touches - 4)
    pts = [(i, p) for i, p in hi + lo]
    lines = [[(start, up_line(start)), (n - 1, up_line(n - 1))], [(start, lo_line(start)), (n - 1, lo_line(n - 1))]]
    bu = _first_close_beyond(df, last_piv + 1, up_line, 1, a)
    bd = _first_close_beyond(df, last_piv + 1, lo_line, -1, a)
    cand = [(b, d) for b, d in ((bu, 1), (bd, -1)) if b is not None]
    if cand:
        b, d = min(cand)
        since = n - 1 - b
        edge = up_line if d == 1 else lo_line
        if since > max_age or d * (c[-1] - edge(n - 1)) < -0.5 * a:
            return None
        opp = lo_line if d == 1 else up_line
        lvl = float(edge(b))
        return {"name": name, "dir": d, "status": "broken", "since": since, "break_level": lvl,
                "target": lvl + d * float(w0), "stop_ref": float(opp(b)),
                "quality": min(1.0, q0 + (0.15 if _vol_ok(df, b) else 0.0) + (0.05 if d == hint else 0.0)),
                "points": pts, "lines": lines}
    if n - 1 - last_piv > 25:
        return None
    edge = up_line if hint >= 0 else lo_line
    d = hint
    return {"name": name, "dir": d, "status": "forming", "since": None, "break_level": float(edge(n - 1)),
            "target": float(edge(n - 1) + d * w0) if d else None,
            "stop_ref": float((lo_line if d >= 0 else up_line)(n - 1)), "quality": q0 * 0.8, "points": pts, "lines": lines}


# ----------------------------------------------------------------------------- public API
def _unflip(p: dict) -> dict:
    p = dict(p)
    p["dir"] = -p["dir"]
    p["name"] = {"double top": "double bottom", "head and shoulders": "inverse head and shoulders",
                 "bull flag": "bear flag"}[p["name"]]
    for k in ("break_level", "target", "stop_ref"):
        if p.get(k) is not None:
            p[k] = -p[k]
    p["points"] = [(i, -v) for i, v in p["points"]]
    p["lines"] = [[(i, -v) for i, v in ln] for ln in p["lines"]]
    return p


def find_patterns(df: pd.DataFrame, a: float, k: int = 3, max_age: int = 6, tf: str = "") -> list[dict]:
    """All patterns that are forming or were broken at most `max_age` candles ago, on the candles in `df`."""
    if len(df) < 40 or a <= 0:
        return []
    found = []
    flipped = _flip(df)
    piv, piv_f = _pivots(df, k), _pivots(flipped, k)         # computed once, shared by all detectors
    for fn in (_double_top, _head_shoulders, _bull_flag):
        p = fn(df, a, piv, max_age)                  # bearish tops / bull flag as they are
        if p:
            found.append(p)
        p = fn(flipped, a, piv_f, max_age)           # mirrored: double bottom, inverse H&S, bear flag
        if p:
            found.append(_unflip(p))
    p = _triangle_wedge(df, a, piv, max_age)
    if p:
        found.append(p)
    idx = df.index
    out = []
    for p in found:
        p["tf"] = tf
        conv = lambda i: int(idx[min(int(i), len(idx) - 1)].timestamp() * 1000)
        p["points"] = [(conv(i), float(v)) for i, v in p["points"]]
        p["lines"] = [[(conv(i), float(v)) for i, v in ln] for ln in p["lines"]]
        p["quality"] = float(min(1.0, p["quality"]))
        out.append(p)
    return out
