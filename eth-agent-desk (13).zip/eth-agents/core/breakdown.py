"""How much each agent contributes to the composite score (same arithmetic as the manager)."""
from __future__ import annotations


def contributions(weights: dict, reports: dict) -> dict:
    """{agent: {weight, share, contribution}}. share = weight / total weight of agents that have data;
    contribution = share * bias * (0.5 + 0.5 * confidence). The contributions add up to the composite score."""
    live = {n: r for n, r in reports.items() if not r.details.get("no_data")}
    den = sum(weights.get(n, 0.0) for n in live)
    out = {}
    for n, r in reports.items():
        if n not in live:
            out[n] = {"weight": weights.get(n, 0.0), "share": 0.0, "contribution": 0.0, "used": False}
            continue
        share = weights.get(n, 0.0) / den if den else 0.0
        out[n] = {"weight": weights.get(n, 0.0), "share": share, "contribution": share * r.bias * (0.5 + 0.5 * r.confidence), "used": True}
    return out
