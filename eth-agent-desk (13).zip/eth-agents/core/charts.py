"""Plotly charts used by the dashboard (kept separate so they can be tested without Streamlit)."""
from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go

from core.indicators import session_vwap
from core.models import AgentReport, MarketSnapshot, TradePlan, tf_minutes

UP, DOWN = "#2DD4A7", "#FF6B7A"
BLUE, AMBER = "#5B9DFF", "#F5B544"
DARK = dict(template="plotly_dark", paper_bgcolor="#0F1520", plot_bgcolor="#0B111A", font=dict(family="Inter, sans-serif", color="#B6C2D0"))


def _local(idx, tz: str):
    """tz-aware UTC index/timestamp -> naive wall-clock time in the display timezone (plotly-safe)."""
    idx = pd.DatetimeIndex(idx) if not isinstance(idx, pd.Timestamp) else idx
    return idx.tz_convert(tz).tz_localize(None)


def build_chart(snap: MarketSnapshot, reports: dict[str, AgentReport], plan: TradePlan, tf: str,
                tz: str = "UTC", n: int = 160) -> go.Figure:
    pt = reports.get("patterns")
    pat_ts = [t for p in (pt.details.get("patterns", []) if pt else []) for ln in p["lines"] for t, _ in ln]
    if pat_ts:   # show the whole pattern: widen the window back to its first point (at most 450 candles)
        first = pd.Timestamp(min(pat_ts), unit="ms", tz="UTC")
        n = min(max(n, int((snap.candles[tf].index >= first).sum()) + 8), 450)
    df = snap.candles[tf].tail(n)
    x = _local(df.index, tz)
    step = pd.Timedelta(minutes=tf_minutes(tf))
    x_end = x[-1] + step * 14            # room on the right for the plan boxes
    fig = go.Figure()
    lo, hi = float(df["low"].min()), float(df["high"].max())
    pad = (hi - lo) * 0.08
    fig.add_trace(go.Candlestick(x=x, open=df["open"], high=df["high"], low=df["low"], close=df["close"],
                                 increasing_line_color=UP, decreasing_line_color=DOWN, name="price",
                                 showlegend=False))
    vw = session_vwap(snap.candles[tf]).tail(n)
    fig.add_trace(go.Scatter(x=x, y=vw, mode="lines", line=dict(color=AMBER, width=1.2, dash="dot"),
                             name="VWAP (UTC day)"))

    # liquidity clusters (model estimate or your manual Coinglass levels)
    liq = reports.get("liquidity")
    if liq:
        for c in liq.details.get("clusters", []):
            if not (lo - 2 * pad <= c["price"] <= hi + 2 * pad):
                continue  # off-screen levels would only pile their labels on the chart edge
            col = DOWN if c["price"] > snap.price else UP
            fig.add_shape(type="line", x0=x[0], x1=x_end, y0=c["price"], y1=c["price"], layer="below",
                          line=dict(color=col, width=1 + 3 * c["strength"], dash="dash"), opacity=0.35 + 0.4 * c["strength"])
            fig.add_annotation(x=x_end, y=c["price"], xanchor="right", yanchor="bottom", showarrow=False,
                               text=f"liq {c['price']:.0f} ({c['strength']:.2f})", font=dict(size=10, color=col))
    ses = reports.get("session")
    if ses:  # previous-day / session highs and lows as thin dotted lines
        for lv in ses.details.get("levels", []):
            if not (lo - pad <= lv["price"] <= hi + pad):
                continue
            fig.add_shape(type="line", x0=x[0], x1=x_end, y0=lv["price"], y1=lv["price"], layer="below",
                          line=dict(color=AMBER, width=1, dash="dot"), opacity=0.55)
            fig.add_annotation(x=x[0], y=lv["price"], xanchor="left", yanchor="bottom", showarrow=False,
                               text=f"{lv['name']} {lv['price']:.0f}", font=dict(size=9, color=AMBER))
    ob = reports.get("orderbook")
    if ob:  # big resting orders: solid thick lines (red = sell wall above, green = buy wall below)
        for w in ob.details.get("walls", [])[:8]:
            if not (lo - pad <= w["price"] <= hi + pad):
                continue
            col = DOWN if w["side"] == "ask" else UP
            fig.add_shape(type="line", x0=x[-1], x1=x_end, y0=w["price"], y1=w["price"],
                          line=dict(color=col, width=4), opacity=0.8)
            fig.add_annotation(x=x_end, y=w["price"], xanchor="right", yanchor="top", showarrow=False,
                               text=f"{w['side']} wall ${w['usd'] / 1e6:.1f}M", font=dict(size=9, color=col))
    wh = reports.get("whales")
    if wh:  # Coinglass whale walls: gold-edged thick lines so they differ from the Binance depth walls
        for w in wh.details.get("walls", [])[:8]:
            if not (lo - pad <= w["price"] <= hi + pad):
                continue
            col = DOWN if w["side"] == "ask" else UP
            fig.add_shape(type="line", x0=x[0], x1=x_end, y0=w["price"], y1=w["price"], line=dict(color=col, width=3, dash="dash"), opacity=0.75)
            fig.add_annotation(x=x[0], y=w["price"], xanchor="left", yanchor="bottom", showarrow=False,
                               text=f"whale {w['side']} ${w['usd'] / 1e6:.1f}M", font=dict(size=10, color=col))
    op = reports.get("options")
    if op and not op.details.get("no_data"):    # options: max pain (gold), gamma walls (red above / green below), gamma flip (grey)
        for key, label, col in (("max_pain", "max pain", "#E8C547"), ("call_wall", "call wall", DOWN), ("put_wall", "put wall", UP),
                                ("gamma_flip", "gamma flip", "#9AA4B2")):
            y = op.details.get(key)
            if y and lo - pad <= y <= hi + pad:
                fig.add_shape(type="line", x0=x[0], x1=x_end, y0=y, y1=y, line=dict(color=col, width=1.4, dash="dot"), opacity=0.8)
                fig.add_annotation(x=x_end, y=y, xanchor="right", yanchor="bottom", showarrow=False,
                                   text=f"{label} {y:.0f}", font=dict(size=10, color=col))
    dv = reports.get("divergence")
    for d in (dv.details.get("divergences", []) if dv else []):   # price line between the two pivots, pink
        xs = [_local(pd.Timestamp(t, unit="ms", tz="UTC"), tz) for t, _ in d["points"]]
        fig.add_trace(go.Scatter(x=xs, y=[v for _, v in d["points"]], mode="lines+markers", showlegend=False, hoverinfo="skip",
                                 line=dict(color="#FF8AD8", width=1.6, dash="dash"), marker=dict(size=7, color="#FF8AD8")))
        fig.add_annotation(x=xs[-1], y=d["points"][-1][1], text=f"{d['tf']} {d['name'].replace(' RSI divergence', ' div')}", showarrow=False,
                           xanchor="left", yshift=10 if d["dir"] < 0 else -10, font=dict(size=10, color="#FF8AD8"))
    pt = reports.get("patterns")
    vp = reports.get("volume_profile")
    if vp and "poc" in vp.details:      # volume profile: POC (solid) and value area edges (dotted), light blue
        for key, label, dash, w in (("poc", "POC", "solid", 1.4), ("vah", "VAH", "dot", 1.0), ("val", "VAL", "dot", 1.0)):
            y = vp.details[key]
            if lo - pad <= y <= hi + pad:
                fig.add_shape(type="line", x0=x[0], x1=x_end, y0=y, y1=y, line=dict(color="#6FA8FF", width=w, dash=dash), opacity=0.7)
                fig.add_annotation(x=x[0], y=y, text=f"{label} {y:.1f}", showarrow=False, xanchor="left", yanchor="bottom",
                                   font=dict(size=10, color="#6FA8FF"))
    for p in (pt.details.get("patterns", []) if pt else []):    # pattern lines: purple, dotted while forming
        for ln in p["lines"]:
            fig.add_trace(go.Scatter(x=[_local(pd.Timestamp(t, unit="ms", tz="UTC"), tz) for t, _ in ln], y=[v for _, v in ln],
                                     mode="lines", showlegend=False, hoverinfo="skip",
                                     line=dict(color="#B58CFF", width=1.6, dash="solid" if p["status"] == "broken" else "dot")))
        if p["points"]:
            fig.add_trace(go.Scatter(x=[_local(pd.Timestamp(t, unit="ms", tz="UTC"), tz) for t, _ in p["points"]],
                                     y=[v for _, v in p["points"]], mode="markers", showlegend=False, hoverinfo="skip",
                                     marker=dict(color="#B58CFF", size=8, line=dict(color="#0A0E14", width=1))))
        lx, ly = p["lines"][0][-1]
        fig.add_annotation(x=_local(pd.Timestamp(lx, unit="ms", tz="UTC"), tz), y=ly, text=f"{p['tf']} {p['name']}", showarrow=False,
                           xanchor="right", yshift=10, font=dict(size=10, color="#B58CFF"))
    lq = reports.get("liquidations")
    if lq:  # recent forced liquidations: red = longs liquidated, green = shorts liquidated, size = USD
        pts = [e for e in lq.details.get("chart_events", []) if lo - pad <= e["price"] <= hi + pad]
        for side, col, label in (("long_liq", DOWN, "longs liquidated"), ("short_liq", UP, "shorts liquidated")):
            sel = [e for e in pts if e["side"] == side]
            if sel:
                fig.add_trace(go.Scatter(x=[_local(pd.Timestamp(e["ts_ms"], unit="ms", tz="UTC"), tz) for e in sel],
                                         y=[e["price"] for e in sel], mode="markers", name=label,
                                         marker=dict(color=col, opacity=0.65, symbol="x",
                                                     size=[min(18, 6 + e["usd"] / 150_000) for e in sel]),
                                         hovertext=[f"${e['usd'] / 1e3:,.0f}k" for e in sel], hoverinfo="text+y"))
    if liq:
        sw = liq.details.get("sweep")
        if sw:
            fig.add_annotation(x=x[-1], y=sw["extreme"], text="sweep", showarrow=True, arrowhead=2,
                               ax=-30, ay=30 if sw["direction"] < 0 else -30, font=dict(size=11, color=AMBER))

    # structure zones (FVG / order blocks)
    st_ = reports.get("structure")
    if st_:
        zones = [z for z in st_.details.get("zones", [])]
        zones = sorted(zones, key=lambda z: abs((z["low"] + z["high"]) / 2 - snap.price))[:6]
        for z in zones:
            x0 = _local(z["ts"], tz) if z["ts"] >= df.index[0] else x[0]
            col = "rgba(38,166,154,0.18)" if z["kind"] == "bull" else "rgba(239,83,80,0.18)"
            fig.add_shape(type="rect", x0=x0, x1=x_end, y0=z["low"], y1=z["high"], fillcolor=col, line_width=0,
                          layer="below")
            fig.add_annotation(x=x0, y=z["high"], xanchor="left", yanchor="bottom", showarrow=False,
                               text=f"{z['kind']} {z['type']}", font=dict(size=9, color="gray"))

    # the trade plan
    if plan.side != "NONE" and plan.entry:
        xs = x[-1] + step
        fig.add_shape(type="rect", x0=xs, x1=x_end, y0=min(plan.entry, plan.stop), y1=max(plan.entry, plan.stop),
                      fillcolor="rgba(239,83,80,0.22)", line_width=0)
        fig.add_shape(type="rect", x0=xs, x1=x_end, y0=min(plan.entry, plan.tp2), y1=max(plan.entry, plan.tp2),
                      fillcolor="rgba(38,166,154,0.15)", line_width=0)
        for name, y, col in (("entry", plan.entry, BLUE), ("stop", plan.stop, DOWN),
                             ("TP1", plan.tp1, UP), ("TP2", plan.tp2, UP)):
            fig.add_shape(type="line", x0=xs, x1=x_end, y0=y, y1=y, line=dict(color=col, width=2))
            fig.add_annotation(x=xs, y=y, xanchor="left", yanchor="bottom", showarrow=False,
                               text=f"{name} {y:.1f}", font=dict(size=11, color=col))

    ys = [lo - pad, hi + pad]
    if plan.side != "NONE" and plan.entry:
        ys = [min(ys[0], plan.stop - pad / 2), max(ys[1], plan.tp2 + pad / 2)]
    fig.update_layout(**DARK, height=560, margin=dict(l=10, r=10, t=30, b=10), xaxis_rangeslider_visible=False,
                      yaxis=dict(range=ys, side="right"), legend=dict(orientation="h", y=1.04, x=0),
                      title=dict(text=f"{snap.symbol} {tf} - times shown in {tz}", font=dict(size=13)))
    return fig


def equity_chart(eq: pd.Series, title: str = "Equity (USD, cumulative P&L)") -> go.Figure:
    fig = go.Figure(go.Scatter(x=list(range(1, len(eq) + 1)) if not isinstance(eq.index, pd.DatetimeIndex) else eq.index,
                               y=eq.values, mode="lines+markers", line=dict(color=BLUE, width=2)))
    fig.add_hline(y=0, line_color="gray", line_dash="dot")
    fig.update_layout(**DARK, height=300, margin=dict(l=10, r=10, t=30, b=10), title=dict(text=title, font=dict(size=13)))
    return fig
