"""Shared trade-management simulator: used by the backtester AND the live paper journal,
so both always apply exactly the same rules.

Rules (deliberately conservative, because candles hide the order of events inside a bar):
- LIMIT entries wait `wait_bars` candles; they are cancelled if price reaches TP1 before filling.
- On the candle where a limit order fills, only the stop can trigger (targets are ignored that candle).
- If a stop and a target are both reachable in the same candle, the STOP is assumed to hit first.
- TP1 closes `tp1_fraction` of the position and moves the stop to break-even; the rest runs to TP2.
  After TP1 the break-even stop and TP2 can only trigger from the NEXT candle.
- Time stop: whatever is still open after `max_bars` candles is closed at that candle's close.
- Costs: `spread_usd` per unit per round trip, plus `slippage_usd` per unit on stop / time-stop exits.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass
class SimParams:
    wait_bars: int = 8
    max_bars: int = 48
    tp1_fraction: float = 0.5
    spread_usd: float = 1.0
    slippage_usd: float = 0.3

    @classmethod
    def from_cfg(cls, cfg: dict) -> "SimParams":
        b = (cfg or {}).get("backtest", {}) or {}
        return cls(**{k: b[k] for k in cls.__dataclass_fields__ if k in b})


@dataclass
class SimTrade:
    side: str                 # LONG / SHORT
    entry: float
    stop: float
    tp1: float
    tp2: float
    units: float              # position size in ETH
    risk_usd: float
    state: str = "pending"    # pending | open | closed | expired
    age: int = 0              # candles processed since the decision
    cur_stop: float | None = None
    tp1_hit: bool = False
    remaining: float = 1.0    # fraction of the position still open
    gross: float = 0.0        # realised P&L before costs (USD)
    slip_units: float = 0.0   # units that exited with slippage
    exit_price: float | None = None
    exit_reason: str = ""
    pnl_usd: float = 0.0      # final, net of costs
    r: float = 0.0            # final, net of costs, in units of planned risk
    last_ts: str | None = None  # last candle open-time already processed
    log: list = field(default_factory=list)

    def __post_init__(self):
        if self.cur_stop is None:
            self.cur_stop = self.stop

    @property
    def d(self) -> int:
        return 1 if self.side == "LONG" else -1

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "SimTrade":
        return cls(**d)


def new_trade(plan, contract_size: float, market_filled: bool) -> SimTrade:
    """Build a SimTrade from an approved TradePlan."""
    units = plan.size * contract_size
    return SimTrade(side=plan.side, entry=plan.entry, stop=plan.stop, tp1=plan.tp1, tp2=plan.tp2,
                    units=units, risk_usd=plan.risk_usd, state="open" if market_filled else "pending")


def _finish(t: SimTrade, p: SimParams, price: float, reason: str, slipped: bool) -> None:
    pnl = (price - t.entry) * t.d * t.units * t.remaining
    t.gross += pnl
    if slipped:
        t.slip_units += t.units * t.remaining
    t.remaining = 0.0
    t.state, t.exit_price, t.exit_reason = "closed", price, reason
    t.pnl_usd = t.gross - p.spread_usd * t.units - p.slippage_usd * t.slip_units
    t.r = t.pnl_usd / t.risk_usd if t.risk_usd else 0.0


def advance(t: SimTrade, high: float, low: float, close: float, p: SimParams, ts: str | None = None) -> SimTrade:
    """Feed ONE closed candle into the trade. Mutates and returns the trade."""
    if t.state in ("closed", "expired"):
        return t
    if ts is not None:
        t.last_ts = ts
    t.age += 1
    d = t.d
    fill_candle = False

    if t.state == "pending":
        touched = low <= t.entry if d == 1 else high >= t.entry
        missed = high >= t.tp1 if d == 1 else low <= t.tp1
        if not touched:
            if missed:
                t.state, t.exit_reason = "expired", "target reached before fill"
            elif t.age >= p.wait_bars:
                t.state, t.exit_reason = "expired", "limit order not filled"
            return t
        t.state, fill_candle = "open", True

    # --- open position ---
    hit_stop = low <= t.cur_stop if d == 1 else high >= t.cur_stop
    if hit_stop:
        reason = "break-even stop" if t.tp1_hit else "stop"
        _finish(t, p, t.cur_stop, reason, slipped=not t.tp1_hit)
        return t
    if fill_candle:
        return t

    if not t.tp1_hit:
        if (high >= t.tp1) if d == 1 else (low <= t.tp1):
            frac = min(max(p.tp1_fraction, 0.0), 1.0)
            t.gross += (t.tp1 - t.entry) * d * t.units * frac
            t.remaining -= frac
            t.tp1_hit, t.cur_stop = True, t.entry
            if t.remaining <= 1e-9:
                _finish(t, p, t.tp1, "TP1", slipped=False)
                return t
    else:
        if (high >= t.tp2) if d == 1 else (low <= t.tp2):
            _finish(t, p, t.tp2, "TP2", slipped=False)
            return t

    if t.age >= p.max_bars:
        _finish(t, p, close, "time stop", slipped=True)
    return t
