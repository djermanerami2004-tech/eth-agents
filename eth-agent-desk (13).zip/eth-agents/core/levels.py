"""Manual liquidity levels from a plain text file (levels.txt), re-read automatically when the file changes.

One level per line:   price [strength]      strength = a number 0..1, or the word strong / medium / weak
Examples:             3850            (strength 1.0)
                      3720 0.6
                      3600 weak       # comments start with #
"""
from __future__ import annotations

from pathlib import Path

from core.config import ROOT

WORDS = {"strong": 1.0, "medium": 0.7, "weak": 0.4}
_cache: dict[str, tuple[float, list[dict]]] = {}


def parse_levels(text: str) -> list[dict]:
    out = []
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].replace(",", " ").replace(";", " ").replace(":", " ").strip()
        if not line:
            continue
        parts = line.split()
        try:
            price = float(parts[0])
        except ValueError:
            continue
        strength = 1.0
        if len(parts) > 1:
            w = parts[1].lower()
            try:
                strength = WORDS[w] if w in WORDS else float(w)
            except ValueError:
                strength = 1.0
        if price > 0:
            out.append({"price": price, "strength": min(1.0, max(0.05, strength))})
    return out


def resolve(path: str | None) -> Path:
    p = Path(path or "levels.txt")
    return p if p.is_absolute() else ROOT / p


def load_levels(path: str | None) -> list[dict]:
    p = resolve(path)
    try:
        mtime = p.stat().st_mtime
    except OSError:
        return []
    key = str(p)
    hit = _cache.get(key)
    if hit and hit[0] == mtime:
        return [dict(x) for x in hit[1]]
    levels = parse_levels(p.read_text(encoding="utf-8", errors="ignore"))
    _cache[key] = (mtime, levels)
    return [dict(x) for x in levels]


def save_levels_text(path: str | None, text: str) -> int:
    """Validate and store the text; returns how many levels were understood."""
    n = len(parse_levels(text))
    resolve(path).write_text(text.rstrip() + "\n", encoding="utf-8")
    return n


# ---------------------------------------------------------------- order-book walls (walls.txt)
_wcache: dict[str, tuple[float, list[dict]]] = {}


def parse_walls(text: str) -> list[dict]:
    """One wall per line:  price [bid|ask] [size in USD millions]   e.g. '3955 ask 48.5'  or  '2300 bid 12'.
    Side is worked out from the current price when left out; size defaults to 10 (million USD)."""
    out = []
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].replace(",", " ").replace(";", " ").strip()
        if not line:
            continue
        side, size = None, 10.0
        parts = line.split()
        try:
            price = float(parts[0])
        except ValueError:
            continue
        for tok in parts[1:]:
            t = tok.lower().rstrip("m")
            if t in ("bid", "b", "buy", "support"):
                side = "bid"
            elif t in ("ask", "a", "sell", "resistance"):
                side = "ask"
            else:
                try:
                    size = float(t)
                except ValueError:
                    pass
        if price > 0 and size > 0:
            out.append({"price": price, "side": side, "usd": size * 1e6})
    return out


def load_walls(path: str | None) -> list[dict]:
    p = resolve(path or "walls.txt")
    try:
        mtime = p.stat().st_mtime
    except OSError:
        return []
    hit = _wcache.get(str(p))
    if not hit or hit[0] != mtime:
        hit = (mtime, parse_walls(p.read_text(encoding="utf-8", errors="ignore")))
        _wcache[str(p)] = hit
    return [dict(x) for x in hit[1]]


def save_walls_text(path: str | None, text: str) -> int:
    n = len(parse_walls(text))
    resolve(path or "walls.txt").write_text(text.rstrip() + "\n", encoding="utf-8")
    return n
