"""Smart-money-concept helpers: fair value gaps and order blocks."""
from __future__ import annotations

import pandas as pd


def find_fvgs(df: pd.DataFrame, lookback: int = 80, keep: int = 6) -> list[dict]:
    """Unfilled 3-candle imbalances. bull zone = (high[i-2], low[i]); bear zone = (high[i], low[i-2])."""
    h, l = df["high"].values, df["low"].values
    n = len(df)
    out = []
    for i in range(max(2, n - lookback), n):
        if l[i] > h[i - 2]:
            lo, hi = h[i - 2], l[i]
            later = l[i + 1:]
            if len(later) == 0 or later.min() > lo:
                out.append({"kind": "bull", "type": "FVG", "low": float(lo), "high": float(hi), "ts": df.index[i]})
        elif h[i] < l[i - 2]:
            lo, hi = h[i], l[i - 2]
            later = h[i + 1:]
            if len(later) == 0 or later.max() < hi:
                out.append({"kind": "bear", "type": "FVG", "low": float(lo), "high": float(hi), "ts": df.index[i]})
    return out[-keep:]


def find_order_blocks(df: pd.DataFrame, atr_s: pd.Series, lookback: int = 80,
                      disp: float = 1.0, keep: int = 6) -> list[dict]:
    """Last opposite candle before a displacement move; dropped once price trades through it."""
    o, c, h, l = (df[k].values for k in ("open", "close", "high", "low"))
    n = len(df)
    out = []
    for i in range(max(0, n - lookback), n - 4):
        a = atr_s.iloc[i]
        if c[i] < o[i] and c[i + 1:i + 4].max() > h[i] + disp * a:
            if l[i + 4:].size == 0 or l[i + 4:].min() > l[i]:
                out.append({"kind": "bull", "type": "OB", "low": float(l[i]), "high": float(h[i]), "ts": df.index[i]})
        elif c[i] > o[i] and c[i + 1:i + 4].min() < l[i] - disp * a:
            if h[i + 4:].size == 0 or h[i + 4:].max() < h[i]:
                out.append({"kind": "bear", "type": "OB", "low": float(l[i]), "high": float(h[i]), "ts": df.index[i]})
    return out[-keep:]
