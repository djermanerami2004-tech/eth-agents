from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

import pandas as pd


def tf_minutes(tf: str) -> int:
    unit = tf[-1].lower()
    n = int(tf[:-1])
    return n * {"m": 1, "h": 60, "d": 1440}[unit]


@dataclass
class MarketSnapshot:
    symbol: str
    price: float
    candles: dict  # tf -> DataFrame(open, high, low, close, volume, taker_buy_base)
    oi: pd.DataFrame | None
    funding: float | None
    long_short_ratio: float | None
    source: str
    ts: pd.Timestamp
    book: dict | None = None      # live order book {'bids': [[price, qty]], 'asks': [...]}; not available for the past
    ref: dict | None = None       # candles of the reference market (BTC): tf -> DataFrame, same cut rules as `candles`

    def until(self, t: pd.Timestamp, price: float | None = None) -> "MarketSnapshot":
        """Return a copy that only contains candles fully CLOSED at time t."""
        out = {}
        for tf, df in self.candles.items():
            m = pd.Timedelta(minutes=tf_minutes(tf))
            out[tf] = df[df.index + m <= t]
        ref = None
        if self.ref:
            ref = {tf: df[df.index + pd.Timedelta(minutes=tf_minutes(tf)) <= t] for tf, df in self.ref.items()}
        oi = self.oi[self.oi.index <= t] if self.oi is not None else None
        if price is None:
            base = out[min(out, key=tf_minutes)]
            price = float(base["close"].iloc[-1])
        live = t >= self.ts   # funding / positioning are only known 'now'; hide them from replays of the past
        return MarketSnapshot(self.symbol, float(price), out, oi, self.funding if live else None,
                              self.long_short_ratio if live else None, self.source, t,
                              self.book if live else None, ref)


@dataclass
class AgentReport:
    agent: str
    bias: float          # -1 (short) .. +1 (long)
    confidence: float    # 0 .. 1
    summary: str
    details: dict = field(default_factory=dict)
    veto: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class RiskState:
    daily_pnl: float = 0.0
    total_pnl: float = 0.0
    trades_today: int = 0
    loss_streak: int = 0
    open_trades: int = 0       # trades / pending orders still active


@dataclass
class TradePlan:
    side: str = "NONE"               # LONG / SHORT / NONE
    ts: str = ""
    price: float = 0.0
    atr: float = 0.0
    strategy: str = ""               # which strategy produced the setup
    entry_type: str = "MARKET"       # MARKET / LIMIT
    entry: float = 0.0
    stop: float = 0.0
    tp1: float = 0.0
    tp2: float = 0.0
    rr: float = 0.0
    size: float = 0.0                # lots
    risk_usd: float = 0.0
    score: float = 0.0
    confidence: float = 0.0          # heuristic setup score, NOT a statistical probability
    approved: bool = False
    reasons: list = field(default_factory=list)
    vetoes: list = field(default_factory=list)
    setups: list = field(default_factory=list)   # EVERY setup any strategy found this cycle, with its status (taken / why not)
    id: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
