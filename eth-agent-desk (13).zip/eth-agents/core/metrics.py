"""Performance statistics shared by the backtester, the journal and the dashboard."""
from __future__ import annotations

import pandas as pd


def summarize(tdf: pd.DataFrame, account: float) -> dict:
    empty = {"trades": 0, "win_rate": 0.0, "avg_r": 0.0, "profit_factor": 0.0, "total_r": 0.0,
             "max_dd_r": 0.0, "total_pnl": 0.0, "max_dd_usd": 0.0, "max_dd_pct": 0.0, "longest_loss_streak": 0}
    if tdf.empty:
        return empty
    r = tdf["r"]
    wins, losses = r[r > 0], r[r <= 0]
    gl = abs(losses.sum())
    eq_r = r.cumsum()
    eq_usd = tdf["pnl_usd"].cumsum()
    dd_usd = float((eq_usd.cummax().clip(lower=0) - eq_usd).max())
    streak = best = 0
    for x in r:
        streak = streak + 1 if x <= 0 else 0
        best = max(best, streak)
    return {"trades": int(len(tdf)), "win_rate": float(len(wins) / len(tdf)), "avg_r": float(r.mean()),
            "profit_factor": float(wins.sum() / gl) if gl > 0 else float("inf"),
            "total_r": float(r.sum()), "max_dd_r": float((eq_r.cummax().clip(lower=0) - eq_r).max()),
            "total_pnl": float(tdf["pnl_usd"].sum()), "max_dd_usd": dd_usd,
            "max_dd_pct": dd_usd / account * 100 if account else 0.0, "longest_loss_streak": best}


def by_strategy(tdf: pd.DataFrame) -> pd.DataFrame:
    """One row per strategy: trades, win rate, average R, total R, profit factor."""
    if tdf.empty or "strategy" not in tdf:
        return pd.DataFrame(columns=["strategy", "trades", "win_rate", "avg_r", "total_r", "profit_factor"])
    rows = []
    for name, g in tdf.assign(strategy=tdf["strategy"].fillna("").replace("", "unknown")).groupby("strategy"):
        r = g["r"]
        gl = abs(r[r <= 0].sum())
        rows.append({"strategy": name, "trades": len(g), "win_rate": float((r > 0).mean()), "avg_r": float(r.mean()),
                     "total_r": float(r.sum()), "profit_factor": float(r[r > 0].sum() / gl) if gl > 0 else float("inf")})
    return pd.DataFrame(rows).sort_values("trades", ascending=False).reset_index(drop=True)


MIN_TRADES = 30


def verdict(trades: int, avg_r: float, pf: float) -> str:
    """Plain-words reading of one strategy's record. Deliberately cautious: few trades prove nothing."""
    if trades < MIN_TRADES:
        return f"too early ({trades}/{MIN_TRADES} trades)"
    if avg_r > 0.1 and pf >= 1.2:
        return "promising - keep paper trading"
    if avg_r < 0:
        return "losing - consider switching off"
    return "no clear edge"


def leaderboard(tdf: pd.DataFrame) -> pd.DataFrame:
    """by_strategy() plus a verdict column, best average R first."""
    b = by_strategy(tdf)
    if b.empty:
        return b.assign(verdict=pd.Series(dtype=str))
    b["verdict"] = [verdict(int(r.trades), float(r.avg_r), float(r.profit_factor)) for r in b.itertuples()]
    return b.sort_values("avg_r", ascending=False).reset_index(drop=True)
