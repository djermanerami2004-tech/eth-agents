"""Synthetic ETH-like market data for demo mode, tests and offline development."""
from __future__ import annotations

import numpy as np
import pandas as pd


def make_5m(n: int = 6000, seed: int = 7, end=None, start_price: float = 3000.0,
            drift_amp: float = 0.0, vol_amp: float = 0.0):
    """Random-walk ETH-like candles.

    The default is a NULL market: no predictable drift, constant volatility. A strategy that shows a
    statistically significant profit here has a bug (look-ahead) - see tests/test_null_market.py.
    drift_amp > 0 adds slowly rotating trends, vol_amp > 0 adds volatility cycles (both are exploitable
    by trend followers, so results on such data say nothing about real markets).
    """
    rng = np.random.default_rng(seed)
    end = pd.Timestamp(end) if end is not None else pd.Timestamp.now(tz="UTC")
    end = end.tz_localize("UTC") if end.tzinfo is None else end.tz_convert("UTC")
    end = end.floor("5min")
    idx = pd.date_range(end=end - pd.Timedelta(minutes=5), periods=n, freq="5min")
    t = np.arange(n)

    sigma = 0.0014 * (1 + vol_amp * np.sin(t / 180 + seed))
    jumps = (rng.random(n) > 0.99) * rng.normal(0, 0.006, n)
    drift = drift_amp * np.sin(t / 500 + seed * 1.3)
    ret = drift + sigma * rng.standard_normal(n) + jumps
    close = start_price * np.exp(np.cumsum(ret))
    open_ = np.r_[start_price, close[:-1]]
    wu = np.abs(rng.normal(0, sigma * 0.6)) * close
    wl = np.abs(rng.normal(0, sigma * 0.6)) * close
    high = np.maximum(open_, close) + wu
    low = np.minimum(open_, close) - wl

    hour = idx.hour.values
    vol = 800 * np.exp(rng.normal(0, 0.4, n)) * (1 + 6 * np.abs(ret) / sigma.mean())
    vol *= 1 + 0.5 * ((hour >= 13) & (hour <= 17))
    buy_ratio = np.clip(0.5 + 0.35 * np.tanh(ret / sigma) + rng.normal(0, 0.04, n), 0.05, 0.95)

    df = pd.DataFrame({"open": open_, "high": high, "low": low, "close": close,
                       "volume": vol, "taker_buy_base": vol * buy_ratio}, index=idx)
    oi = 2.5e6 + np.cumsum(rng.normal(0, 3e3, n) + (vol - vol.mean()) * 2.0)
    oi_df = pd.DataFrame({"oi": oi}, index=idx)
    funding = float(rng.normal(0.0001, 0.0003))
    ls_ratio = float(abs(1 + rng.normal(0, 0.3)))
    return df, oi_df, funding, ls_ratio, end


def make_ref_5m(df5: pd.DataFrame, seed: int = 7, start_price: float = 65000.0, beta: float = 0.75, noise: float = 0.55):
    """A BTC-like market for demo mode. Its returns share a common part with the ETH candles (same candle, never earlier),
    so the two are correlated but BTC tells nothing about ETH's FUTURE: the null-market check stays valid."""
    rng = np.random.default_rng(seed + 101)
    r_eth = np.log(df5["close"].values / df5["open"].values)
    sd = r_eth.std() or 1e-3
    ret = beta * r_eth * 0.8 + noise * sd * 0.8 * rng.standard_normal(len(df5))
    close = start_price * np.exp(np.cumsum(ret))
    open_ = np.r_[start_price, close[:-1]]
    wick = np.abs(rng.normal(0, sd * 0.4, len(df5))) * close
    vol = 120 * np.exp(rng.normal(0, 0.4, len(df5))) * (1 + 6 * np.abs(ret) / (np.abs(ret).mean() + 1e-12) * 0.1)
    buy = np.clip(0.5 + 0.3 * np.tanh(ret / (np.abs(ret).mean() + 1e-12) / 3) + rng.normal(0, 0.04, len(df5)), 0.05, 0.95)
    return pd.DataFrame({"open": open_, "high": np.maximum(open_, close) + wick, "low": np.minimum(open_, close) - wick,
                         "close": close, "volume": vol, "taker_buy_base": vol * buy}, index=df5.index)
