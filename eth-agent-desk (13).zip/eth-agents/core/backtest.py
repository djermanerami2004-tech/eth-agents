"""Walk-forward backtest of the full agent stack on historical candles (news agent excluded).

For every closed candle the desk sees ONLY data that existed at that moment (`MarketSnapshot.until`),
exactly like the live loop. Trade management comes from core/tradesim.py (read its docstring for the
fill / stop / cost rules). Candle data cannot model real spreads, slippage, funding or partial fills -
treat the numbers as an optimistic upper bound and confirm with weeks of paper trading.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from agents.derivatives_agent import DerivativesAgent
from agents.indicators_agent import IndicatorsAgent
from agents.mtf_agent import MultiTimeframeAgent
from agents.liquidity_agent import LiquidityAgent
from agents.manager_agent import ManagerAgent
from agents.btc_agent import BtcAgent
from agents.divergence_agent import DivergenceAgent
from agents.pattern_agent import PatternAgent
from agents.regime_agent import RegimeAgent
from agents.volume_profile_agent import VolumeProfileAgent
from agents.session_agent import SessionAgent
from agents.orderflow_agent import OrderFlowAgent
from agents.risk_agent import RiskAgent
from agents.structure_agent import StructureAgent
from core.metrics import by_strategy, summarize  # noqa: F401  (re-exported)
from core.models import AgentReport, MarketSnapshot, RiskState, tf_minutes
from core.tradesim import SimParams, advance, new_trade


def run_backtest(cfg: dict, full: MarketSnapshot, bars: int = 300, warmup: int = 150,
                 progress=None) -> dict:
    tf = cfg["market"]["entry_tf"]
    step = pd.Timedelta(minutes=tf_minutes(tf))
    df = full.candles[tf]
    times = df.index[-bars:]
    params = SimParams.from_cfg(cfg)
    contract = cfg["account"]["contract_size"]

    analysts = [LiquidityAgent(cfg), StructureAgent(cfg), OrderFlowAgent(cfg),
                DerivativesAgent(cfg), IndicatorsAgent(cfg),
                MultiTimeframeAgent(cfg), PatternAgent(cfg), SessionAgent(cfg), RegimeAgent(cfg), DivergenceAgent(cfg), VolumeProfileAgent(cfg), BtcAgent(cfg)]   # candle-only agents; order book, liquidations and news are live-only
    risk = RiskAgent(cfg)
    manager = ManagerAgent(cfg, risk)
    neutral_news = AgentReport("news", 0.0, 0.0, "n/a")

    trades, active, meta = [], None, None
    day, daily_pnl, trades_today, streak, total = None, 0.0, 0, 0, 0.0
    n_eval = 0

    for k, t in enumerate(times):
        now = t + step
        if day != now.date():
            day, daily_pnl, trades_today, streak = now.date(), 0.0, 0, 0
        c = df.loc[t]

        # 1) manage the active trade with the candle that just closed
        if active is not None:
            was_pending = active.state == "pending"
            advance(active, float(c["high"]), float(c["low"]), float(c["close"]), params, ts=str(t))
            if was_pending and active.state == "open":
                trades_today += 1
            if active.state == "closed":
                daily_pnl += active.pnl_usd
                total += active.pnl_usd
                streak = streak + 1 if active.pnl_usd < 0 else 0
                trades.append({"time": meta["time"], "strategy": meta["strategy"], "side": active.side, "entry": active.entry,
                               "stop": active.stop, "tp1": active.tp1, "tp2": active.tp2,
                               "r": round(active.r, 3), "pnl_usd": round(active.pnl_usd, 2),
                               "exit": active.exit_reason, "bars": active.age})
                active = None
            elif active.state == "expired":
                active = None

        # 2) look for a new trade
        if active is None and len(df.loc[:t]) >= warmup:
            snap = full.until(now)
            reports = {a.name: a.safe_analyze(snap) for a in analysts}
            reports["news"] = neutral_news
            plan = manager.decide(snap, reports, RiskState(daily_pnl, total, trades_today, streak), now)
            n_eval += 1
            if plan.approved:
                active = new_trade(plan, contract, market_filled=plan.entry_type == "MARKET")
                meta = {"time": now, "strategy": plan.strategy}
                if active.state == "open":
                    trades_today += 1
        if progress and k % 100 == 0:
            progress(k / len(times))

    tdf = pd.DataFrame(trades)
    eq = None
    if not tdf.empty:
        eq = pd.Series(tdf["pnl_usd"].cumsum().values, index=pd.to_datetime(tdf["time"]))
    return {"trades": tdf, "summary": summarize(tdf, cfg["account"]["size"]), "equity": eq,
            "by_strategy": by_strategy(tdf), "evaluations": n_eval, "params": params}
