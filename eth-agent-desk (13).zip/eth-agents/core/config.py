from __future__ import annotations

import copy
import os
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent


def _load_env(path: Path) -> None:
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def _deep_update(base: dict, new: dict) -> dict:
    for k, v in new.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_update(base[k], v)
        else:
            base[k] = v
    return base


def load_config(path: str | None = None, overrides: dict | None = None) -> dict:
    _load_env(ROOT / ".env")
    p = Path(path) if path else ROOT / "config.yaml"
    cfg = yaml.safe_load(p.read_text())
    jp = Path(cfg["journal"]["path"])
    cfg["journal"]["path"] = str(jp if jp.is_absolute() else ROOT / jp)
    cfg["telegram"]["token"] = os.getenv("TELEGRAM_BOT_TOKEN", "")
    cfg["telegram"]["chat_id"] = os.getenv("TELEGRAM_CHAT_ID", "")
    cfg.setdefault("weights", {}).setdefault("session", 0.08)   # configs from older versions lack this
    cfg["weights"].setdefault("orderbook", 0.08)
    cfg["weights"].setdefault("liquidations", 0.08)
    cfg["weights"].setdefault("patterns", 0.08)
    cfg["weights"].setdefault("regime", 0.0)
    cfg["weights"].setdefault("divergence", 0.06)
    cfg["weights"].setdefault("whales", 0.06)
    cfg["weights"].setdefault("options", 0.05)
    cfg["weights"].setdefault("volume_profile", 0.06)
    cfg["weights"].setdefault("btc", 0.07)
    cfg.setdefault("news", {}).setdefault("blackouts", [])
    if cfg["news"]["blackouts"] is None:
        cfg["news"]["blackouts"] = []
    if overrides:
        _deep_update(cfg, copy.deepcopy(overrides))
    return cfg
