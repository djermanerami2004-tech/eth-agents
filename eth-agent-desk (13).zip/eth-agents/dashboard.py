"""ETH Agent Desk - dashboard.   Run:  python main.py dashboard   (or: streamlit run dashboard.py)"""
from __future__ import annotations

import hmac
import os
import time

import pandas as pd
import streamlit as st

from core.backtest import run_backtest
from core.charts import build_chart, equity_chart
from core.breakdown import contributions
from core.config import load_config
from core.levels import load_levels, load_walls, resolve, save_levels_text, save_walls_text
from core.metrics import leaderboard
from core.models import tf_minutes
from core.pipeline import TradingSystem
from core import ui

st.set_page_config(page_title="ETH Agent Desk", page_icon="📈", layout="wide")
st.html(ui.CSS)


def _password_gate() -> None:
    """If DASHBOARD_PASSWORD is set in .env, nothing is shown (or started) until it is typed. Use it whenever the
    dashboard can be reached from the internet - and then only over HTTPS (see deploy/DEPLOY.md)."""
    load_config()                                       # reads .env into the environment
    pw = os.getenv("DASHBOARD_PASSWORD", "")
    if not pw or st.session_state.get("authed"):
        return
    st.markdown("### ETH Agent Desk")
    with st.form("login"):
        typed = st.text_input("Password", type="password")
        if st.form_submit_button("Open"):
            if hmac.compare_digest(typed.encode(), pw.encode()):
                st.session_state["authed"] = True
                st.rerun()
            time.sleep(1.5)                              # slows down guessing
            st.error("Wrong password.")
    st.stop()


_password_gate()

HISTORY = 1500
AGENT_ORDER = ["liquidity", "structure", "orderflow", "derivatives", "indicators", "mtf", "patterns", "divergence", "regime", "volume_profile", "btc", "session", "orderbook", "whales", "options", "liquidations", "news"]
AGENT_TITLE = {"liquidity": "Liquidity", "structure": "Structure", "orderflow": "Order flow", "derivatives": "Derivatives", "indicators": "Indicators", "mtf": "Multi-timeframe", "session": "Sessions", "orderbook": "Order book", "liquidations": "Liquidations", "patterns": "Chart patterns", "divergence": "RSI divergence", "whales": "Whale orders", "options": "Options", "regime": "Market regime", "volume_profile": "Volume profile", "btc": "BTC", "news": "News"}


@st.cache_resource(show_spinner="Loading market data...")
def get_system(demo: bool, seed: int):
    cfg = load_config()
    return TradingSystem(cfg, demo=demo, seed=seed)


@st.cache_resource(show_spinner="Building history...")
def get_history(demo: bool, seed: int, candles: int):
    system = get_system(demo, seed)
    return system.data.snapshot(limit=candles)


@st.cache_data(show_spinner="Scanning past candles for setups...", ttl=600)
def scan_setups(demo: bool, seed: int, bars: int) -> list[dict]:
    system, full = get_system(demo, seed), get_history(demo, seed, HISTORY)
    tf = system.tf
    step = pd.Timedelta(minutes=tf_minutes(tf))
    out = []
    for t in full.candles[tf].index[-bars:]:
        _, _, plan = system.replay(full, t + step)
        if plan.side != "NONE":
            out.append({"time": (t + step).isoformat(), "side": plan.side, "approved": plan.approved,
                        "entry": round(plan.entry, 1), "rr": plan.rr,
                        "why": "approved" if plan.approved else "; ".join(plan.vetoes)[:90]})
    return out


AGENT_INFO = {
    "liquidity": ("Finds the liquidation clusters (stop pools) above and below price and spots sweeps.",
                  "a wick through a cluster that closes back inside it (a sweep), or price sitting right next to a big cluster"),
    "structure": ("Reads swing highs/lows, breaks of structure and supply/demand zones.",
                  "a break of a swing high or low, then a retest that holds"),
    "orderflow": ("Reads delta, cumulative delta (CVD), VWAP and divergences from taker volume.",
                  "buying or selling pressure that confirms (or diverges from) price at a level"),
    "derivatives": ("Reads funding rate, open interest and the long/short ratio to see how crowded the market is.",
                    "extreme funding, a crowded long/short ratio or an open-interest spike; it adjusts the score and never enters trades by itself"),
    "indicators": ("RSI, MACD, Bollinger bands, EMAs and volume as a cross-check.",
                   "indicators lined up in one direction; it adjusts the score and never enters trades by itself"),
    "mtf": ("Compares trend across 15m, 1h, 4h and 1d and blocks trades against the higher-timeframe trend.",
            "higher timeframes agreeing on a trend, then price pulling back into it"),
    "session": ("Tracks the previous-day high/low and the Asia / London / New York ranges.",
                "a fresh sweep of the previous-day high/low or of an Asia / London high/low"),
    "orderbook": ("Resting limit orders (walls) and bid/ask imbalance near price, plus the walls you paste in walls.txt.",
                  "a big wall close to price that holds; it adjusts the score and never enters trades by itself"),
    "divergence": ("RSI divergence on the 15m and 1h: price and RSI disagree at two swing points. Regular = a reversal warning, hidden = the trend continues.",
                   "a regular or hidden RSI divergence whose second swing was confirmed recently and has not failed"),
    "whales": ("Big resting limit orders from Coinglass (large orders). A big ask above price is resistance, a big bid below is support; young, eaten or pulled walls count less. Needs the Coinglass Standard plan or higher.",
               "a large order of $1M+ within 2.5% of price (Coinglass key and plan required)"),
    "options": ("ETH options on Deribit (free): max pain of the next expiries, where dealer gamma is concentrated (call / put walls), 25-delta skew and put/call ratio. Gamma assumes dealers are long calls / short puts, so it is a rough map.",
                "a big expiry within a few days whose max pain is away from price, or a gamma wall right above / below price"),
    "regime": ("Classifies the market as trend, range, squeeze or mixed (1h ADX and efficiency, 15m Bollinger squeeze). A context agent: it ranks which strategies fit the market and by default adds nothing to the score.",
               "always has a reading; it never creates or blocks a trade, it only reorders setups that already passed"),
    "volume_profile": ("Where the last 2 days of volume traded: point of control (POC), value area (70% of volume) and high/low volume nodes, drawn on the chart.",
                       "price inside the value area leaning back to the POC, a failed move back into it, or acceptance outside it"),
    "btc": ("Compares ETH with BTC: does BTC confirm the move, and is ETH lagging a BTC move it should follow? Says nothing when ETH is decoupled from BTC.",
            "ETH correlated with BTC (above min_corr) and BTC trending or ahead of ETH"),
    "patterns": ("Classic chart patterns on the 15m and 1h: double top/bottom, head & shoulders, flags, triangles and wedges. A close through the pattern's trigger line counts as a break.",
                 "a pattern broken by a candle close in the last few candles, or still forming (a forming pattern only leans slightly)"),
    "liquidations": ("Live stream of forced liquidations on Binance: a burst of liquidated longs or shorts, and whether the flow is still running or spent.",
                     "a liquidation burst: a cascade still running (leans with it) or a spent flush (leans the other way); it adjusts the score and never enters trades by itself"),
    "news": ("Blocks trading around high-impact economic events and scores headline tone.",
             "nothing: it is a safety filter that adjusts the score and can veto trades"),
}
STATUS_STYLE = {"selected": ("✅", "chosen as the trade"), "passed": ("✔️", "passed all checks, but another setup ranked higher"),
                "rejected": ("⚠️", "NOT taken")}


def _open_agent(name: str) -> None:
    st.session_state["open_agent"] = name


def _close_agent() -> None:
    st.session_state.pop("open_agent", None)


def _fmt(v):
    if isinstance(v, float):
        return f"{v:,.4f}".rstrip("0").rstrip(".") if abs(v) < 1000 else f"{v:,.2f}"
    return str(v)


def show_details(details: dict) -> None:
    """Show an agent's raw data: single values as a small table, lists/tables as tables."""
    scalars, others = {}, {}
    for k, v in details.items():
        if v is None or isinstance(v, (bool, int, float, str)):
            scalars[k] = v
        else:
            others[k] = v
    if scalars:
        st.dataframe(pd.DataFrame({"value": {k: _fmt(v) for k, v in scalars.items()}}), width="stretch")
    for k, v in others.items():
        st.markdown(f"**{k.replace('_', ' ')}**")
        try:
            if isinstance(v, list) and v and isinstance(v[0], dict):
                st.dataframe(pd.DataFrame(v), width="stretch", hide_index=True)
            elif isinstance(v, dict) and v and all(isinstance(x, dict) for x in v.values()):
                st.dataframe(pd.DataFrame(v).T, width="stretch")
            elif isinstance(v, dict):
                st.dataframe(pd.DataFrame({"value": {kk: _fmt(vv) if not isinstance(vv, (dict, list)) else str(vv) for kk, vv in v.items()}}), width="stretch")
            elif isinstance(v, list):
                st.write(v if v else "none")
            else:
                st.write(str(v))
        except Exception:
            st.write(str(v))


def setup_card(s: dict) -> None:
    st.html(ui.setup_html(s))


@st.dialog("Agent details", width="large", on_dismiss=_close_agent)
def agent_dialog(name: str, reports: dict, plan, cfg: dict) -> None:
    rep = reports[name]
    what, waiting = AGENT_INFO.get(name, ("", ""))
    label, col = ui.direction(rep.bias)
    st.html(f'<div style="display:flex;align-items:center;gap:14px">{ui.icon_tile(name, rep.bias, 52, 28)}'
            f'<div><div style="display:flex;align-items:center;gap:12px"><span style="font-size:24px;font-weight:700;color:#E6EDF3">{AGENT_TITLE[name]}</span>'
            f'{ui.chip(label, col)}</div><div style="font-size:14px;color:#8B98A8;margin-top:3px">{what}</div></div></div>')
    if rep.veto:
        st.error("This agent is VETOING trades right now.")
    br = contributions(cfg["weights"], reports)[name]
    need = float(cfg["manager"]["min_score"])
    pts_col = ui.GREEN if br["contribution"] > 0.005 else ui.RED if br["contribution"] < -0.005 else "#E6EDF3"
    st.html(ui.tiles_html([
        ("Bias", f"{rep.bias:+.2f}", "-1 short, +1 long", col if label != "NEUTRAL" else "#E6EDF3"),
        ("Confidence", f"{rep.confidence:.0%}", "How clear the picture is", "#E6EDF3"),
        ("Weight in score", f"{br['share']:.0%}" if br["used"] else "not used", "Set in config.yaml", "#E6EDF3"),
        ("Points added", f"{br['contribution']:+.3f}", f"Composite {plan.score:+.2f}, trade needs about {need:g}", pts_col)]))
    st.info(rep.summary)

    st.markdown("#### Setups")
    mine = [s for s in plan.setups if name in s.get("agents", [])]
    if mine:
        st.caption("Found by strategies built on this agent's data - shown even when the composite score is too low to trade them.")
        for s in mine:
            setup_card(s)
    else:
        lean = f" It leans {'long' if rep.bias > 0.1 else 'short'} ({rep.bias:+.2f}) but that alone is not an entry." if abs(rep.bias) > 0.1 else ""
        st.write(f"No setup from this agent right now.{lean}")
        st.caption(f"What it waits for: {waiting}.")
    others = [s for s in plan.setups if name not in s.get("agents", [])]
    if others:
        st.caption("Other setups on the desk right now (from other agents): " +
                   ", ".join(f"{s['side']} {s['strategy']} ({s['status']})" for s in others))

    st.markdown("#### Data")
    if name == "divergence" and rep.details.get("divergences"):
        st.dataframe(pd.DataFrame([{"timeframe": d["tf"], "type": d["name"], "direction": "long" if d["dir"] > 0 else "short",
                                    "candles ago": d["since"], "RSI first -> second": f"{d['rsi_1']:.0f} -> {d['rsi_2']:.0f}",
                                    "price first -> second": f"{d['price_1']:.1f} -> {d['price_2']:.1f}",
                                    "volume delta agrees": d["delta_confirms"], "quality": round(d["quality"], 2)}
                                   for d in rep.details["divergences"]]), hide_index=True, width="stretch")
    if name == "whales" and rep.details.get("walls"):
        st.dataframe(pd.DataFrame([{"side": w["side"], "price": round(w["price"], 2), "size": f"${w['usd'] / 1e6:.1f}M",
                                    "distance %": round(w["dist_pct"], 2), "age (min)": w["age_min"],
                                    "already eaten": f"{w['eaten']:.0%}", "trust": w["trust"], "exchange": w["exchange"]}
                                   for w in rep.details["walls"]]), hide_index=True, width="stretch")
    if name == "options" and rep.details.get("expiries"):
        st.dataframe(pd.DataFrame([{"expiry": r["expiry"], "hours left": round(r["hours"]), "max pain": r["max_pain"],
                                    "from price %": round(r["dist_pct"], 2), "open interest": f"${r['oi_usd'] / 1e6:.0f}M",
                                    "put/call": None if r["pcr"] is None else round(r["pcr"], 2)} for r in rep.details["expiries"]]),
                     hide_index=True, width="stretch")
        d = rep.details
        st.caption(f"Gamma flip {d['gamma_flip']:.0f}" if d.get("gamma_flip") else "No gamma flip within 15% of price")
    if name == "regime" and rep.details.get("fit"):
        st.caption(f"Right now the market is **{rep.details['regime']}**. Setups that passed are ranked with these multipliers (config.yaml, regime.fit):")
        st.dataframe(pd.DataFrame([{"strategy": k, "rank multiplier": v} for k, v in rep.details["fit"].items()]),
                     hide_index=True, width="stretch")
    if name == "patterns" and rep.details.get("patterns"):
        st.dataframe(pd.DataFrame([{"timeframe": p["tf"], "pattern": p["name"], "status": p["status"],
                                    "direction": "long" if p["dir"] > 0 else "short" if p["dir"] < 0 else "-",
                                    "candles since break": p["since"], "trigger line": round(p["break_level"], 2),
                                    "measured move": None if p["target"] is None else round(p["target"], 2),
                                    "invalidation": round(p["stop_ref"], 2), "quality": round(p["quality"], 2)}
                                   for p in rep.details["patterns"]]), hide_index=True, width="stretch")
    show_details({k: v for k, v in rep.details.items() if k not in ("no_data", "chart_events", "patterns", "breakout", "fit", "divergences", "walls", "expiries", "gex_top")})
    if rep.details.get("no_data"):
        st.warning("This agent has nothing to add right now, so it is left out of the composite score.")


def agent_cards(reports: dict, plan, cfg: dict) -> None:
    br = contributions(cfg["weights"], reports)
    for start in range(0, len(AGENT_ORDER), 3):
        cols = st.columns(3, gap="medium")
        for col, name in zip(cols, AGENT_ORDER[start:start + 3]):
            rep = reports[name]
            n_set = sum(1 for s in plan.setups if name in s.get("agents", []))
            with col:
                with st.container(border=True):
                    st.html(ui.agent_card_html(name, AGENT_TITLE[name], rep.bias, rep.confidence,
                                               br[name]["share"] if br[name]["used"] else None, rep.summary, n_set, rep.veto))
                    st.button("Details & setups", key=f"open_{name}", on_click=_open_agent, args=(name,), width="stretch")
    if st.session_state.get("open_agent") in reports:
        agent_dialog(st.session_state["open_agent"], reports, plan, cfg)


def money(x: float) -> str:
    return f"{'-' if x < 0 else ''}${abs(x):,.0f}"


def rules_card(system, ts, demo: bool) -> str:
    """Your account limits at a glance, from the paper journal. Keep the config limits tighter than your firm's."""
    r, a = system.cfg["risk"], system.cfg["account"]
    stt = system.journal.risk_state(ts)
    size = a["size"]
    max_daily, max_dd = size * r["max_daily_loss_pct"] / 100, size * r["max_total_drawdown_pct"] / 100
    daily_left, dd_left = max(0.0, max_daily + stt.daily_pnl), max(0.0, max_dd + stt.total_pnl)
    locked = []
    if daily_left <= 0:
        locked.append("daily loss limit")
    if dd_left <= 0:
        locked.append("drawdown limit")
    if stt.trades_today >= r["max_trades_per_day"]:
        locked.append("max trades today")
    if stt.loss_streak >= r["max_consecutive_losses"]:
        locked.append("loss streak")
    if stt.open_trades >= r["max_open_trades"]:
        locked.append("trade already active")
    target = a.get("profit_target_pct")
    return ui.rules_html(daily_left, max_daily, dd_left, max_dd, stt.trades_today, r["max_trades_per_day"], stt.open_trades,
                         r["max_open_trades"], stt.loss_streak, r["max_consecutive_losses"], locked, stt.daily_pnl, stt.total_pnl,
                         size * float(target) / 100 if target else None, "demo" if demo else "paper")


# ---------------------------------------------------------------- sidebar
cfg = load_config()
st.sidebar.title("📈 ETH Agent Desk")
mode = st.sidebar.radio("Data source", ["Demo (synthetic, offline)", "Live (Binance)"],
                        help="Demo data is a random walk: it shows how the desk works, not whether the strategy works.")
demo = mode.startswith("Demo")
seed = st.sidebar.number_input("Demo seed", 1, 9999, 7, disabled=not demo)
auto_refresh = st.sidebar.checkbox("Auto-refresh live data every 60 s", value=True, disabled=demo,
                                   help="Only the Desk tab reloads, so you can use the other tabs undisturbed.")
if st.sidebar.button("Refresh data"):
    st.cache_resource.clear()
    st.cache_data.clear()
with st.sidebar.expander("Coinglass levels (paste here)"):
    lv_path = cfg["liquidity"].get("levels_file", "levels.txt")
    try:
        current = resolve(lv_path).read_text(encoding="utf-8")
    except OSError:
        current = ""
    txt = st.text_area("One level per line: price [strength]", current, height=180,
                       help="strength = 0..1 or strong / medium / weak. These replace the modelled liquidity map "
                            "while they are close to price. Lines starting with # are comments.")
    if st.button("Save levels"):
        n = save_levels_text(lv_path, txt)
        st.success(f"Saved {n} level(s). The desk uses them on its next refresh.")
    st.caption(f"{len(load_levels(lv_path))} level(s) active")
with st.sidebar.expander("Order-book walls (paste here)"):
    w_path = (cfg.get("orderbook", {}) or {}).get("walls_file", "walls.txt")
    try:
        w_current = resolve(w_path).read_text(encoding="utf-8")
    except OSError:
        w_current = ""
    w_txt = st.text_area("price [bid|ask] [USD millions]", w_current, height=150, key="walls_txt",
                         help="Big resting orders from Coinglass 'Large orders', e.g. '3955 ask 48.5'. Lines starting with # are comments.")
    if st.button("Save walls"):
        st.success(f"Saved {save_walls_text(w_path, w_txt)} wall(s).")
    st.caption(f"{len(load_walls(w_path))} wall(s) active")
st.sidebar.divider()
r, a = cfg["risk"], cfg["account"]
st.sidebar.caption("Risk settings (edit config.yaml)")
st.sidebar.markdown(
    f"- Account **{money(a['size'])}**\n- Risk per trade **{r['risk_per_trade_pct']}%** ({money(a['size'] * r['risk_per_trade_pct'] / 100)})\n"
    f"- Daily stop **{r['max_daily_loss_pct']}%**, total stop **{r['max_total_drawdown_pct']}%**\n"
    f"- Max **{r['max_trades_per_day']}** trades/day, hours (UTC) **{r['allowed_sessions_utc']}**")
st.sidebar.warning("Signals only - not financial advice. Check your prop firm's rules on automation and copy-trading "
                   "before you place trades from any bot's signals.")

system = get_system(demo, int(seed))
tf, tz = system.tf, cfg["market"].get("display_tz", "UTC")
tab_desk, tab_lb, tab_bt, tab_j, tab_how = st.tabs(["🎯 Desk", "🏆 Strategies", "🧪 Backtest", "📒 Journal", "ℹ️ How it works"])

# ---------------------------------------------------------------- desk
with tab_desk:
    @st.fragment(run_every="60s" if (not demo and auto_refresh) else None)
    def desk():
        try:
            if demo:
                full = get_history(True, int(seed), HISTORY)
                c1, c2 = st.columns([3, 2])
                setups = scan_setups(True, int(seed), 400)
                approved = [s for s in setups if s["approved"]]
                with c2:
                    pick = st.selectbox("Jump to an approved setup (demo replay)",
                                        ["Latest candle"] + [f"{s['time'][:16]} {s['side']} @ {s['entry']}" for s in approved])
                if pick == "Latest candle":
                    t_dec = full.candles[tf].index[-1] + pd.Timedelta(minutes=tf_minutes(tf))
                else:
                    t_dec = pd.Timestamp(approved[[f"{s['time'][:16]} {s['side']} @ {s['entry']}" for s in approved].index(pick)]["time"])
                with c1:
                    st.caption(f"Replaying {full.source} - the desk only sees candles closed before {t_dec:%Y-%m-%d %H:%M} UTC. "
                               f"{len(approved)} approved / {len(setups)} total setups in the last 400 candles.")
                snap, reports, plan = system.replay(full, t_dec)
            else:
                snap = system.data.snapshot()
                reports, plan = system.analyze(snap, use_journal=True, use_llm=True)
                if snap.source != "binance-live":
                    st.warning("Using the spot-market fallback feed: prices differ slightly from the perpetual and "
                               "there is no open-interest / funding data.")
        except Exception as e:
            st.error(f"Could not load market data: {e}")
            st.info("Run `python main.py check` in a terminal, or switch to Demo in the sidebar.")
            return

        st.html(ui.header_html(not demo, snap.source, f"{snap.ts:%H:%M} UTC", demo))
        if not demo and snap.source != "binance-live":
            st.warning("Using the spot-market fallback feed: prices differ slightly from the perpetual and "
                       "there is no open-interest / funding data.")
        c_dec, c_rules = st.columns([1.15, 1], gap="medium")
        with c_dec:
            st.html(ui.decision_html(plan, plan.score, float(cfg["manager"]["min_score"])))
        with c_rules:
            st.html(rules_card(system, snap.ts, demo))
        st.plotly_chart(build_chart(snap, reports, plan, tf, tz), width="stretch")
        st.html('<div style="font-size:18px;font-weight:700;margin:10px 0 2px;color:#E6EDF3">The agents</div>'
                '<div style="font-size:13px;color:#8B98A8;margin-bottom:6px">Each bar shows how far an agent leans: left = short, right = long. '
                'Open a card for its data and setups.</div>')
        agent_cards(reports, plan, cfg)
        with st.expander(f"All setups found this cycle ({len(plan.setups)})"):
            if plan.setups:
                for sp in plan.setups:
                    setup_card(sp)
            else:
                st.write("No strategy sees a setup right now.")
        with st.expander("Multi-timeframe table"):
            per = reports["mtf"].details.get("per_tf", {})
            if per:
                st.dataframe(pd.DataFrame(per).T[["label", "score", "ema", "structure", "weight"]], width="stretch")
        with st.expander("Manager's reasoning"):
            for line in plan.reasons:
                st.write("- " + line)
        if not demo:
            liq = reports["liquidity"]
            with st.expander("Liquidity clusters"):
                st.dataframe(pd.DataFrame(liq.details.get("clusters", [])), width="stretch")

    desk()

# ---------------------------------------------------------------- strategy leaderboard
with tab_lb:
    st.subheader("Strategy leaderboard")
    st.caption("Which setups actually make money? Ranked by average R from your closed paper trades. "
               "A strategy needs 30+ trades before the verdict means anything.")
    closed_lb = system.journal.closed_trades()
    if closed_lb.empty:
        st.info("No closed paper trades yet. Run `python main.py loop` and let it collect trades - or run a backtest "
                "in the Backtest tab to see the same table on past data.")
    else:
        lb = leaderboard(closed_lb)
        st.dataframe(lb, width="stretch", hide_index=True)
        import plotly.graph_objects as go
        fig = go.Figure(go.Bar(x=lb["strategy"], y=lb["avg_r"], marker_color=["#2e9e6b" if v > 0 else "#d1495b" for v in lb["avg_r"]],
                               text=[f"n={n}" for n in lb["trades"]], textposition="outside"))
        fig.update_layout(height=320, margin=dict(l=10, r=10, t=30, b=10), title="Average R per trade",
                          yaxis_title="R", template="plotly_dark")
        fig.add_hline(y=0, line_color="gray", line_dash="dot")
        st.plotly_chart(fig, width="stretch")
    if st.session_state.get("last_bt_by_strategy") is not None:
        st.markdown("**Last backtest (past data)**")
        st.dataframe(st.session_state["last_bt_by_strategy"], width="stretch", hide_index=True)
    st.caption("Switch a strategy off in config.yaml -> strategies.<name>.enabled once it has a clearly losing record.")

# ---------------------------------------------------------------- backtest
with tab_bt:
    st.subheader("Walk-forward backtest")
    st.caption("Runs the whole agent stack candle by candle; the desk only sees data that existed at each moment. "
               "Costs (spread, slippage) are included - see `backtest:` in config.yaml.")
    bars = st.slider("Candles to test", 200, 2000 if demo else 900, 600, step=100)
    if demo:
        st.warning("Demo data is a random walk with no edge. Expect roughly zero or slightly negative results here - "
                   "that is the correct outcome and proves the backtest is not fooling itself.")
    if st.button("Run backtest", type="primary"):
        bt_system = TradingSystem(cfg, demo=demo, seed=int(seed), journal_path=":memory:")
        full_bt = bt_system.data.snapshot(limit=bars + 400)
        bar = st.progress(0.0, text="Testing...")
        out = run_backtest(cfg, full_bt, bars=bars, progress=lambda f: bar.progress(min(f, 1.0), text="Testing..."))
        bar.empty()
        s = out["summary"]
        m = st.columns(5)
        m[0].metric("Trades", s["trades"])
        m[1].metric("Win rate", f"{s['win_rate']:.0%}")
        m[2].metric("Avg R", f"{s['avg_r']:+.2f}")
        m[3].metric("Profit factor", f"{s['profit_factor']:.2f}")
        m[4].metric("Max drawdown", f"{money(s['max_dd_usd'])} ({s['max_dd_pct']:.1f}%)")
        if s["trades"] < 100:
            st.info(f"Only {s['trades']} trades - far too few to conclude anything. 100+ trades is a minimum.")
        if out["equity"] is not None:
            st.plotly_chart(equity_chart(out["equity"]), width="stretch")
            st.markdown("**Results by strategy**")
            st.session_state["last_bt_by_strategy"] = leaderboard(out["trades"]) if len(out["trades"]) else None
            st.dataframe(out["by_strategy"], width="stretch")
            st.dataframe(out["trades"], width="stretch")
            st.download_button("Download trades (CSV)", out["trades"].to_csv(index=False), "backtest_trades.csv")

# ---------------------------------------------------------------- journal
with tab_j:
    st.subheader("Trade journal / paper trading")
    j = system.journal
    s = j.stats()
    m = st.columns(5)
    m[0].metric("Closed trades", s["trades"])
    m[1].metric("Win rate", f"{s['win_rate']:.0%}")
    m[2].metric("Avg R", f"{s['avg_r']:+.2f}")
    m[3].metric("Total P&L", money(s["total_pnl"]))
    m[4].metric("Active now", s["open"])
    closed = j.closed_trades()
    if not closed.empty:
        from core.metrics import by_strategy
        st.markdown("**Results by strategy**")
        st.dataframe(by_strategy(closed), width="stretch")
        st.plotly_chart(equity_chart(closed["pnl_usd"].cumsum()), width="stretch")
    lst = j.list(100)
    if lst.empty:
        st.info("No trades yet. Run `python main.py loop` - every approved signal is tracked here automatically (paper mode).")
    else:
        st.dataframe(lst, width="stretch")
    if demo:
        st.caption("Demo mode uses a separate demo journal file.")

# ---------------------------------------------------------------- how it works
with tab_how:
    st.markdown("""
### The desk
| Agent | Job |
|---|---|
| **Data** | Downloads candles, open interest, funding and long/short ratio from Binance |
| **Liquidity** | Estimates where leveraged positions get liquidated (a model of a liquidation heatmap - or the exact levels you type in from Coinglass) and spots fresh liquidity sweeps |
| **Structure** | Trend on two timeframes, break of structure / change of character, premium-discount, fair value gaps, order blocks |
| **Order flow** | Delta / CVD, VWAP, CVD divergence, funding and positioning |
| **Sessions** | Previous-day high/low and Asia / London ranges; flags a sweep of any of them |
| **RSI divergence** | RSI vs price at two swing points on the 15m and 1h. Regular = reversal warning, hidden = continuation; a volume-delta agreement adds quality. Works on candles, so it is also used in backtests |
| **Whale orders** | Big resting limit orders from Coinglass (needs its Standard plan or higher). Big asks above price are resistance, big bids below are support; young, half-eaten or pulled walls count less. Live only |
| **Market regime** | Trend, range, squeeze or mixed (1h ADX and efficiency, 15m Bollinger squeeze). Context only: ranks which strategies fit and adds nothing to the score unless you give it a weight |
| **Volume profile** | Point of control, value area and volume nodes of the last 2 days, drawn on the chart. Leans back to the POC inside the value area and with the move after acceptance outside |
| **BTC** | BTC trend and whether ETH lags a BTC move, scaled by their correlation. Silent when ETH is decoupled |
| **Chart patterns** | Double top/bottom, head & shoulders, flags, triangles, wedges found from swing pivots on the 15m and 1h. A candle close through the trigger line is a break; the measured move is the target. Works on candles only, so it is also used in backtests |
| **Liquidations** | Live stream of forced liquidations on Binance (free). A burst of liquidated longs or shorts, and whether the flow is still running (cascade) or spent (flush). Live only - not used in backtests |
| **Order book** | Big resting orders (walls) and bid/ask imbalance near price from Binance depth, plus far walls you paste from Coinglass. Live only - not used in backtests |
| **News** | Blocks trading around high-impact USD events and reads crypto headlines |
| **Risk** | Position size, daily / total loss limits, trading hours, max trades, stop and RR sanity. **Has veto power.** |
| **Manager** | Combines the reports into one plan (entry, stop, two targets) or "no trade" |
| **Journal** | Tracks every signal as a paper trade with the same rules as the backtest, and reports statistics |
| **Claude (optional)** | Explains the plan and can act as a sceptical reviewer that may only *reject* or *halve* a trade |

### Honest limits
- The liquidity map is an **estimate**, not Coinglass data. Type real levels into `config.yaml -> liquidity.manual_levels` to override it.
- "Setup score" is a heuristic, **not a win probability**.
- Backtests on candles cannot model real spreads, slippage and fills. Paper trade for several weeks before risking a funded account.
- Nothing here guarantees profit. Past results, backtests and demo data do not predict the future.
""")
