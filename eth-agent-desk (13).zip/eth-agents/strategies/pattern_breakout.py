"""Pattern breakout: a chart pattern (double top/bottom, head & shoulders, flag, triangle, wedge) was broken by a candle
close a moment ago and price has not run far from the break yet. Trade the break; the stop sits at the pattern's
invalidation and the first target is the pattern's measured move."""
from strategies.base import Setup, Strategy


class PatternBreakout(Strategy):
    name = "pattern_breakout"
    agents = ('patterns',)           # agents whose data this strategy is built on (shown in their popup)

    def detect(self, snap, reports, ctx):
        rep = reports.get("patterns")
        b = rep.details.get("breakout") if rep else None
        if not b or not b.get("dir"):
            return None
        d = int(b["dir"])
        if (ctx.price - b["break_level"]) * d < -0.2 * ctx.atr:                 # fell back through the broken line
            return None
        if (ctx.price - b["break_level"]) * d > float(self.p.get("max_chase_atr", 1.0)) * ctx.atr:
            return None                                                         # already ran away, do not chase
        if (b["stop_ref"] - ctx.price) * d >= 0:
            return None
        return Setup(self.name, d, "MARKET", ctx.price, float(b["stop_ref"]), 0.3 + 0.5 * float(b["strength"]),
                     f"{b['tf']} {b['name']} broke {b['break_level']:.1f} {b['since']} candles ago (measured move {b['target']:.1f})",
                     target=b.get("target"))
