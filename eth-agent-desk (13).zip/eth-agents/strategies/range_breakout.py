"""Asian-range breakout: a tight overnight range (UTC 00:00-07:00 by default) is broken during the London/New York
hours with above-average volume and aggressive buying/selling behind it. Trade the first close outside the range."""
import pandas as pd

from core.models import tf_minutes
from strategies.base import Setup, Strategy, htf_bias


class RangeBreakout(Strategy):
    name = "range_breakout"
    agents = ('liquidity', 'orderflow')          # agents whose data this strategy is built on (shown in their popup)

    def detect(self, snap, reports, ctx):
        p, df, a = self.p, ctx.df, ctx.atr
        start, end, until = p.get("start_hour", 0), p.get("end_hour", 7), p.get("trade_until", 17)
        last = df.iloc[-1]
        h = df.index[-1].hour
        if not (end <= h < until):
            return None
        day = df.index[-1].normalize()
        asia = df[(df.index >= day + pd.Timedelta(hours=start)) & (df.index < day + pd.Timedelta(hours=end))]
        expected = (end - start) * 60 / tf_minutes(self.cfg["market"]["entry_tf"])
        if len(asia) < 0.7 * expected:
            return None
        hi, lo = float(asia["high"].max()), float(asia["low"].min())
        if (hi - lo) / ctx.price * 100 > p.get("max_range_pct", 1.5):
            return None                                               # not a consolidation
        today = df[df.index >= day + pd.Timedelta(hours=end)]
        prev = today.iloc[:-1]
        vol_ok = last["volume"] >= p.get("min_volume_x", 1.2) * float(df["volume"].tail(48).mean())
        share = float(last["taker_buy_base"] / last["volume"]) if last["volume"] else 0.5
        hb = htf_bias(reports)
        for d in (1, -1):
            if d == 1:
                broke = last["close"] > hi + 0.1 * a and (prev["close"] <= hi).all()
                flow = share >= p.get("min_buy_share", 0.55)
                ref = (hi + lo) / 2
            else:
                broke = last["close"] < lo - 0.1 * a and (prev["close"] >= lo).all()
                flow = share <= 1 - p.get("min_buy_share", 0.55)
                ref = (hi + lo) / 2
            if broke and vol_ok and flow and hb * d > -0.2:
                return Setup(self.name, d, "MARKET", ctx.price, ref, 0.5 + (0.1 if hb * d > 0.3 else 0.0),
                             f"first close outside the {start:02d}-{end:02d} UTC range {lo:.1f}-{hi:.1f} "
                             f"with volume and {share:.0%} buy share")
        return None
