from strategies.bos_retest import BosRetest
from strategies.consensus import Consensus
from strategies.pattern_breakout import PatternBreakout
from strategies.range_breakout import RangeBreakout
from strategies.session_sweep import SessionSweep
from strategies.sweep_reversal import SweepReversal
from strategies.trend_pullback import TrendPullback

ALL = [SweepReversal, SessionSweep, TrendPullback, BosRetest, RangeBreakout, PatternBreakout, Consensus]


def build_strategies(cfg: dict) -> list:
    """Strategies switched on in config.yaml -> strategies.<name>.enabled (default: on)."""
    conf = cfg.get("strategies", {}) or {}
    return [s(cfg) for s in ALL if (conf.get(s.name, {}) or {}).get("enabled", True)]
