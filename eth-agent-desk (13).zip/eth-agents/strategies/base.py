"""A strategy looks at one market snapshot (plus the agents' reports) and proposes at most ONE setup.
It never sizes or approves anything: the manager checks it against the agents' consensus and the risk agent."""
from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace


@dataclass
class Setup:
    name: str            # strategy name, stored with every trade
    side: int            # +1 long / -1 short
    entry_type: str      # MARKET / LIMIT
    entry: float
    stop_ref: float      # the stop goes just beyond this price
    quality: float       # 0..1 how clean the setup is
    note: str = ""
    target: float | None = None   # optional measured-move target (patterns); the manager uses it when it gives enough RR


def htf_bias(reports: dict) -> float:
    m = reports.get("mtf")
    return float(m.details.get("htf_bias", 0.0)) if m else 0.0


def mtf_bias(reports: dict) -> float:
    m = reports.get("mtf")
    return float(m.bias) if m else 0.0


class Strategy:
    name = "base"
    agents: tuple = ()   # which agents this setup is built on

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.p = (cfg.get("strategies", {}) or {}).get(self.name, {}) or {}

    def detect(self, snap, reports: dict, ctx: SimpleNamespace):  # -> Setup | None
        raise NotImplementedError
