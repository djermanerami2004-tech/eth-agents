"""Break of structure + retest: price closes beyond a confirmed swing high/low, comes back to retest that level,
holds it, and the last candle rejects the retest. Trade the continuation of the break."""
from core.indicators import swings
from strategies.base import Setup, Strategy, htf_bias


class BosRetest(Strategy):
    name = "bos_retest"
    agents = ('structure',)          # agents whose data this strategy is built on (shown in their popup)

    def detect(self, snap, reports, ctx):
        df, a = ctx.df.tail(200), ctx.atr
        if len(df) < 40:
            return None
        lookback = int(self.p.get("lookback", 16))
        hb = htf_bias(reports)
        sh, sl = swings(df, 3, 3)
        n, last = len(df), df.iloc[-1]
        vol_avg = float(df["volume"].tail(48).mean())
        found = []
        for d, levels in ((1, sh.dropna()), (-1, sl.dropna())):
            if hb * d <= -0.2:
                continue                                              # do not trade a break against the big trend
            if (last["close"] > last["open"]) != (d == 1):
                continue
            for ts, lvl in list(levels.items())[::-1][:4]:
                i0 = df.index.get_loc(ts)
                after = df.iloc[i0 + 1:]
                beyond = (after["close"] > lvl) if d == 1 else (after["close"] < lvl)
                if not beyond.any():
                    continue
                k = i0 + 1 + int(beyond.values.argmax())             # first close beyond the level
                since = n - 1 - k
                if since < 2 or since > lookback:
                    continue
                post = df.iloc[k + 1:]
                if d == 1:
                    held = bool((post["close"] > lvl - 0.3 * a).all())
                    retest = last["low"] <= lvl + 0.35 * a and last["close"] > lvl
                    ref = min(float(post["low"].tail(3).min()), lvl - 0.5 * a)
                else:
                    held = bool((post["close"] < lvl + 0.3 * a).all())
                    retest = last["high"] >= lvl - 0.35 * a and last["close"] < lvl
                    ref = max(float(post["high"].tail(3).max()), lvl + 0.5 * a)
                if held and retest:
                    strong = df["volume"].iloc[k] > 1.3 * vol_avg
                    q = 0.5 + (0.15 if strong else 0.0) + 0.1 * min(1.0, max(0.0, hb * d))
                    found.append(Setup(self.name, d, "MARKET", ctx.price, ref, q,
                                       f"broke {lvl:.1f} {since} candles ago, retested and held"
                                       + (" (high-volume break)" if strong else "")))
                    break
        return max(found, key=lambda s: s.quality) if found else None
