"""Liquidity sweep reversal: price wicks through a liquidity cluster and closes back -> trade the reversal."""
from strategies.base import Setup, Strategy


class SweepReversal(Strategy):
    name = "sweep_reversal"
    agents = ('liquidity', 'liquidations')          # agents whose data this strategy is built on (shown in their popup)

    def detect(self, snap, reports, ctx):
        liq = reports.get("liquidity")
        sweep = liq.details.get("sweep") if liq else None
        if not sweep:
            return None
        return Setup(self.name, int(sweep["direction"]), "MARKET", ctx.price, float(sweep["extreme"]),
                     0.4 + 0.6 * float(sweep["strength"]),
                     f"swept {sweep['level']:.1f} (strength {sweep['strength']:.2f}) and closed back")
