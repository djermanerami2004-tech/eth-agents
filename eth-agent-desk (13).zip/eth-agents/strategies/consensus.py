"""Agent consensus: no special pattern, just a strong enough weighted agreement. Enters at a nearby order block /
fair value gap if there is one, else at market with the stop behind the recent swing. (The original fallback.)"""
from strategies.base import Setup, Strategy


class Consensus(Strategy):
    name = "consensus"
    agents = ('liquidity', 'structure', 'orderflow')          # agents whose data this strategy is built on (shown in their popup)

    def detect(self, snap, reports, ctx):
        if ctx.score == 0:
            return None
        d = 1 if ctx.score > 0 else -1
        zone = self._zone(reports.get("structure"), d, ctx)
        if zone:
            inside = zone["low"] <= ctx.price <= zone["high"]
            entry, kind = ctx.price, "MARKET"
            if not inside:
                span = zone["high"] - zone["low"]
                entry = zone["high"] - 0.25 * span if d == 1 else zone["low"] + 0.25 * span
                kind = "LIMIT"
            return Setup(self.name, d, kind, entry, zone["low"] if d == 1 else zone["high"], 0.3,
                         f"{zone['kind']} {zone['type']} zone")
        recent = ctx.df.tail(8)
        ref = float(recent["low"].min()) if d == 1 else float(recent["high"].max())
        return Setup(self.name, d, "MARKET", ctx.price, ref, 0.2, "recent swing")

    def _zone(self, structure, d, ctx):
        if not structure:
            return None
        maxd = self.cfg["manager"]["max_entry_distance_atr"] * ctx.atr
        best, best_d = None, None
        for z in structure.details.get("zones", []):
            if (z["kind"] == "bull") != (d == 1):
                continue
            wrong_side = (z["low"] >= ctx.price) if d == 1 else (z["high"] <= ctx.price)
            dist = max(ctx.price - z["high"], 0.0) if d == 1 else max(z["low"] - ctx.price, 0.0)
            if wrong_side or dist > maxd:
                continue
            if best is None or dist < best_d:
                best, best_d = z, dist
        return best
