"""Session sweep: price wicks through the previous-day or an Asia/London high or low and closes back -> trade the reversal."""
from strategies.base import Setup, Strategy


class SessionSweep(Strategy):
    name = "session_sweep"
    agents = ('session', 'liquidations')          # agents whose data this strategy is built on (shown in their popup)

    def detect(self, snap, reports, ctx):
        rep = reports.get("session")
        sw = rep.details.get("sweep") if rep else None
        if not sw:
            return None
        return Setup(self.name, int(sw["direction"]), "MARKET", ctx.price, float(sw["extreme"]),
                     0.35 + 0.4 * float(sw["weight"]), f"swept {sw['name']} {sw['level']:.1f} and closed back")
