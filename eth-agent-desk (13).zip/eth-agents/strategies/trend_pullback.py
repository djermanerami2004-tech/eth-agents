"""Trend pullback: the higher timeframes trend one way; price pulls back into an order block / fair value gap
(or the EMA50) and the last candle rejects it in the trend direction. Trade the continuation."""
from core.indicators import ema, rsi
from strategies.base import Setup, Strategy, htf_bias, mtf_bias


class TrendPullback(Strategy):
    name = "trend_pullback"
    agents = ('mtf', 'structure')          # agents whose data this strategy is built on (shown in their popup)

    def detect(self, snap, reports, ctx):
        p = self.p
        hb = htf_bias(reports)
        if abs(hb) < p.get("min_htf_bias", 0.4):
            return None
        d = 1 if hb > 0 else -1
        if mtf_bias(reports) * d < 0.25 or len(ctx.df) < 60:
            return None
        df, a = ctx.df, ctx.atr
        last = df.iloc[-1]
        if (last["close"] > last["open"]) != (d == 1) or last["close"] == last["open"]:
            return None                                              # no rejection candle
        r = float(rsi(df["close"]).iloc[-1])
        max_rsi = p.get("max_rsi", 58)
        if (d == 1 and r > max_rsi) or (d == -1 and r < 100 - max_rsi):
            return None                                              # not a pullback, price is extended
        zone = self._touched_zone(reports.get("structure"), d, last, ctx.price, a)
        e50 = float(ema(df["close"], 50).iloc[-1])
        if d == 1:
            near_ema = last["low"] <= e50 + 0.25 * a and last["close"] > e50 - 0.1 * a
        else:
            near_ema = last["high"] >= e50 - 0.25 * a and last["close"] < e50 + 0.1 * a
        if not zone and not near_ema:
            return None
        if d == 1:
            ref = min(float(df["low"].tail(3).min()), zone["low"] if zone else e50 - 0.3 * a)
        else:
            ref = max(float(df["high"].tail(3).max()), zone["high"] if zone else e50 + 0.3 * a)
        what = f"{zone['kind']} {zone['type']}" if zone else "EMA50"
        return Setup(self.name, d, "MARKET", ctx.price, ref,
                     0.45 + 0.25 * min(1.0, abs(hb)) + (0.15 if zone else 0.0),
                     f"pullback to {what} in a higher-timeframe {'uptrend' if d == 1 else 'downtrend'}, RSI {r:.0f}")

    @staticmethod
    def _touched_zone(structure, d, last, price, a):
        if not structure:
            return None
        best, best_d = None, None
        for z in structure.details.get("zones", []):
            if (z["kind"] == "bull") != (d == 1):
                continue
            if d == 1:
                ok = last["low"] <= z["high"] + 0.25 * a and last["close"] >= z["low"]
            else:
                ok = last["high"] >= z["low"] - 0.25 * a and last["close"] <= z["high"]
            dist = abs(price - (z["low"] + z["high"]) / 2)
            if ok and (best is None or dist < best_d):
                best, best_d = z, dist
        return best
