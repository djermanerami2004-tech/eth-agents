#!/usr/bin/env bash
# One-shot setup on a fresh Ubuntu/Debian server (no Docker needed). Run as a normal user with sudo, from the project folder:
#   bash deploy/vps_setup.sh
# Installs Python packages, creates two services that start on boot and restart if they crash.
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$DIR"
sudo apt-get update -y
sudo apt-get install -y python3 python3-venv python3-pip
python3 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
for s in eth-desk eth-dashboard; do
  sed "s|__USER__|$USER|g; s|__DIR__|$DIR|g" "deploy/$s.service" | sudo tee "/etc/systemd/system/$s.service" >/dev/null
done
sudo systemctl daemon-reload
sudo systemctl enable --now eth-desk eth-dashboard
echo
.venv/bin/python main.py check || true
echo
echo "Running. Logs:  journalctl -u eth-desk -f      Status: systemctl status eth-desk eth-dashboard"
echo "Dashboard listens on 127.0.0.1:8501 only. See deploy/DEPLOY.md to open it from your phone."
echo "Edit .env (Telegram, password) then:  sudo systemctl restart eth-desk eth-dashboard"
