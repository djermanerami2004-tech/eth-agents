# Run the desk 24/7 on a server

The desk only sends signals (no orders, no exchange keys), so a small server is enough. It keeps analysing every
5 minutes, tracks paper trades, listens to the liquidation stream and sends Telegram alerts while your PC and phone are off.
You open the dashboard from your phone whenever you want.

## 1. Pick the server

- Ubuntu 24.04 (or 22.04), 1-2 GB RAM is enough. Around 4-6 EUR/month at the usual cheap providers (check the current price).
- **Choose a location in Europe (Germany, Finland...), not the USA.** Binance blocks US addresses (HTTP 451) and the desk would get no data.
- `python main.py check` on the server tells you straight away whether Binance is reachable from it.

## 2. Put the project on it

On your computer (replace `user` and `SERVER_IP`):

```
scp eth-agent-desk.zip user@SERVER_IP:~
ssh user@SERVER_IP
sudo apt-get install -y unzip
unzip eth-agent-desk.zip && cd eth-agents
```

## 3A. Easiest: one script (no Docker)

```
bash deploy/vps_setup.sh
```

It installs everything and creates two services that start on boot and restart after a crash:
`eth-desk` (the loop + liquidation listener) and `eth-dashboard` (the web page, reachable from the server itself only).

## 3B. Or with Docker

```
cp .env.example .env
docker compose up -d --build
```

Same two parts (`desk` and `dashboard`). `docker compose ps` shows whether the desk is healthy,
`docker compose logs -f desk` shows what it does.

## 4. Settings

```
nano .env        # TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, DASHBOARD_PASSWORD
nano config.yaml # set telegram.enabled: true
```

Then restart: `sudo systemctl restart eth-desk eth-dashboard` (3A) or `docker compose restart` (3B).
You get a Telegram message after 5 failed cycles in a row, and another when data flows again.

## 5. Open the dashboard from your phone

The dashboard is deliberately NOT open to the internet. Pick one:

**Tailscale (recommended, free for personal use, no domain needed, encrypted).**
1. On the server: `curl -fsSL https://tailscale.com/install.sh | sh` then `sudo tailscale up` and open the link it prints.
2. Install the Tailscale app on your phone and sign in with the same account.
3. On the server: `sudo tailscale serve --bg 8501`. It prints an `https://...ts.net` address. Open that on your phone.

**SSH tunnel (from a computer).** `ssh -L 8501:localhost:8501 user@SERVER_IP`, leave it open, browse to http://localhost:8501.

**Public HTTPS with your own domain.** Install Caddy and use `deploy/Caddyfile.example`. Set `DASHBOARD_PASSWORD` in `.env` first:
anyone who finds the address can otherwise read your journal and levels. Never put the dashboard on plain http://SERVER_IP:8501.

## 6. Everyday commands

| What | Command (3A) |
|---|---|
| Is it alive? | `systemctl status eth-desk eth-dashboard` and `.venv/bin/python scripts/healthcheck.py` |
| Live log | `journalctl -u eth-desk -f` |
| Is the liquidation stream connected? | `.venv/bin/python main.py check` (look for "Binance liquidation stream") |
| Update to a new version | upload the new zip, unzip over the folder (keep `.env`, `config.yaml`, `data/`), then restart |
| Back up your journal | copy `data/journal.db` to your computer: `scp user@SERVER_IP:~/eth-agents/data/journal.db .` |

Basic safety: `sudo ufw allow OpenSSH && sudo ufw enable` (the dashboard needs no open port with Tailscale or a tunnel),
and use SSH keys instead of a password for the server login.
