"""Liquidation agent: reads the LIVE stream of forced liquidations on Binance.

A burst of forced selling (longs liquidated) or forced buying (shorts liquidated) is the market clearing leveraged
positions. Two phases matter:
  * still running (liquidations keep coming at close to their peak rate): a cascade, momentum continues in the
    direction of the forced orders, so the bias follows it (small, low confidence: nobody catches a falling knife);
  * exhausted (the rate has dropped well below the peak): the forced flow is done, which often marks a local low
    (after long liquidations) or high (after short liquidations), so the bias is the opposite way.
Both are heuristics, not statistics: the stream has no history before you start collecting, so this agent
is live only and is left out of backtests (like the order book agent).
"""
from __future__ import annotations

import time

from agents.base import BaseAgent, clip
from core.liqstream import HEARTBEAT_STALE_S, LiqStore, db_path
from core.models import AgentReport, MarketSnapshot


def usd(x: float) -> str:
    return f"${x / 1e6:.1f}M" if x >= 1e6 else f"${x / 1e3:.0f}k"


class LiquidationAgent(BaseAgent):
    name = "liquidations"

    def __init__(self, cfg: dict, store: LiqStore | None = None):
        super().__init__(cfg)
        self.c = cfg.get("liquidations", {}) or {}
        self._store = store
        self.symbol = cfg["market"]["symbol"]

    @property
    def store(self) -> LiqStore:
        if self._store is None:
            self._store = LiqStore(db_path(self.cfg))
        return self._store

    @staticmethod
    def _is_live(snap: MarketSnapshot) -> bool:
        return abs(time.time() - snap.ts.timestamp()) < 1200

    def _none(self, msg: str, **details) -> AgentReport:
        return AgentReport(self.name, 0.0, 0.0, msg, {**details, "no_data": True})

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        if not self.c.get("enabled", True):
            return self._none("Liquidation stream is switched off in config.yaml")
        if str(snap.source).startswith("synthetic"):
            return self._none("Demo data: the liquidation stream only exists live")
        if not self._is_live(snap):
            return self._none("Liquidation stream is live only (no history), left out of replays and backtests")
        now = time.time()
        beat, first = self.store.get_meta("heartbeat"), self.store.get_meta("first_run")
        if beat is None or now - beat > HEARTBEAT_STALE_S:
            return self._none("Liquidation stream is not running. It starts with `python main.py loop` or the "
                              "dashboard, or run `python main.py liqstream` on its own", running=False)

        window = float(self.c.get("window_min", 15))
        base_h = float(self.c.get("baseline_hours", 6))
        covered_min = (now - first) / 60 if first else 0.0
        if covered_min < window:
            return self._none(f"Liquidation stream just started, collecting ({covered_min:.0f} of {window:.0f} min)",
                              running=True, covered_min=covered_min)

        now_ms = int(now * 1000)
        evs = self.store.since(self.symbol, now_ms - int(base_h * 3600_000))
        win_start = now_ms - int(window * 60_000)
        win = [e for e in evs if e["ts_ms"] >= win_start]
        before = [e for e in evs if e["ts_ms"] < win_start]
        long_w = sum(e["usd"] for e in win if e["side"] == "long_liq")
        short_w = sum(e["usd"] for e in win if e["side"] == "short_liq")
        tot = long_w + short_w

        base_min = min(base_h * 60, covered_min) - window
        per_window = sum(e["usd"] for e in before) / (base_min / window) if base_min >= window else 0.0
        thr = max(float(self.c.get("min_usd", 1_500_000)), float(self.c.get("burst_x", 3.0)) * per_window)

        details = {"window_min": window, "long_liq_usd": long_w, "short_liq_usd": short_w, "threshold_usd": thr,
                   "baseline_per_window_usd": per_window, "covered_min": covered_min, "running": True,
                   "events": [{"time": time.strftime("%H:%M:%S", time.gmtime(e["ts_ms"] / 1000)), "side": e["side"],
                               "price": e["price"], "usd": round(e["usd"])} for e in win[-10:]][::-1],
                   "chart_events": [{"ts_ms": e["ts_ms"], "side": e["side"], "price": e["price"], "usd": e["usd"]}
                                    for e in evs if e["usd"] >= float(self.c.get("chart_min_usd", 100_000))][-200:]}
        if win:
            details["largest_usd"] = max(e["usd"] for e in win)

        if tot < thr:
            return self._none(f"Quiet: {usd(tot)} liquidated in {window:.0f} min (long {usd(long_w)}, short {usd(short_w)}); "
                              f"a burst needs {usd(thr)}", **details, phase="quiet")
        dom, dom_usd = ("long_liq", long_w) if long_w >= short_w else ("short_liq", short_w)
        share = dom_usd / tot
        if share < float(self.c.get("min_dominance", 0.65)):
            return self._none(f"Mixed burst: {usd(tot)} liquidated both ways (long {usd(long_w)}, short {usd(short_w)}), no clear side",
                              **details, phase="mixed")

        # speed of the forced flow: per-minute dominant volume, last 2 minutes vs the peak minute
        buckets: dict[int, float] = {}
        for e in win:
            if e["side"] == dom:
                m = int((e["ts_ms"] - win_start) // 60_000)
                buckets[m] = buckets.get(m, 0.0) + e["usd"]
        n_min = int(window)
        series = [buckets.get(m, 0.0) for m in range(n_min)]
        peak = max(series) if series else 0.0
        recent = sum(series[-2:]) / 2 if series else 0.0
        ratio = recent / peak if peak > 0 else 0.0
        exhausted = ratio <= float(self.c.get("exhaust_ratio", 0.35))
        strength = min(1.0, tot / (3 * thr))
        flushed = "longs" if dom == "long_liq" else "shorts"
        if exhausted:
            bias = (1 if dom == "long_liq" else -1) * (0.35 + 0.45 * strength)
            conf = 0.35 + 0.4 * strength
            phase = "exhausted"
            note = (f"{usd(dom_usd)} of {flushed} liquidated in {window:.0f} min ({share:.0%} of {usd(tot)}) and the flow has slowed to "
                    f"{ratio:.0%} of its peak: the forced flow is spent, leans {'LONG' if bias > 0 else 'SHORT'} (heuristic)")
        else:
            bias = (-1 if dom == "long_liq" else 1) * (0.3 + 0.3 * strength)
            conf = 0.25 + 0.3 * strength
            phase = "cascade"
            note = (f"{usd(dom_usd)} of {flushed} liquidated in {window:.0f} min ({share:.0%} of {usd(tot)}) and it is still running "
                    f"({ratio:.0%} of peak rate): cascade, leans {'LONG' if bias > 0 else 'SHORT'} with the flow")
        details.update(phase=phase, dominant=dom, share=share, peak_per_min=peak, recent_per_min=recent, rate_vs_peak=ratio,
                       per_minute=[round(x) for x in series])
        return AgentReport(self.name, clip(bias), clip(conf, 0, 1), note, details)
