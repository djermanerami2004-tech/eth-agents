"""Pattern agent: classic chart patterns (double top/bottom, head & shoulders, flags, triangles, wedges) on the entry
and the higher timeframe. A pattern whose trigger line was broken by a candle CLOSE moves the bias with the break;
a pattern that is still forming only leans a little in its usual direction. Works on candles only, so it is included
in backtests. See core/patterns.py for the exact rules."""
from __future__ import annotations

from agents.base import BaseAgent, clip
from core.indicators import atr
from core.models import AgentReport, MarketSnapshot
from core.patterns import find_patterns


class PatternAgent(BaseAgent):
    name = "patterns"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.c = cfg.get("patterns", {}) or {}
        self.tfs = [cfg["market"]["htf"], cfg["market"]["entry_tf"]]

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        k_by_tf = self.c.get("pivot_bars", {"15m": 4, "1h": 3})
        weight = {self.tfs[0]: 1.0, self.tfs[1]: float(self.c.get("entry_tf_weight", 0.7))}
        max_age = int(self.c.get("max_age_bars", 6))
        pats = []
        for tf in self.tfs:
            df = snap.candles[tf].tail(int(self.c.get("lookback", 300)))
            if len(df) < 60:
                continue
            a = float(atr(df).iloc[-1])
            for p in find_patterns(df, a, int(k_by_tf.get(tf, 3)), max_age, tf):
                p["strength"] = p["quality"] * weight[tf]
                pats.append(p)
        if not pats:
            return AgentReport(self.name, 0.0, 0.0, f"No chart pattern on {self.tfs[1]} or {self.tfs[0]}",
                               {"no_data": True, "patterns": [], "breakout": None})
        contrib = sorted(((p["dir"] * ((0.35 + 0.5 * p["strength"]) if p["status"] == "broken" else 0.12 * p["strength"]))
                          for p in pats if p["dir"]), key=abs, reverse=True)
        bias = (contrib[0] + 0.3 * sum(contrib[1:])) if contrib else 0.0     # the strongest pattern leads, the rest only add a little
        broken = sorted((p for p in pats if p["status"] == "broken"), key=lambda p: -p["strength"])
        best = broken[0] if broken else max(pats, key=lambda p: p["strength"])
        conf = (0.3 + 0.5 * best["strength"]) if broken else (0.2 + 0.2 * best["strength"])
        words = []
        for p in sorted(pats, key=lambda p: -p["strength"])[:3]:
            side = "bullish" if p["dir"] > 0 else "bearish" if p["dir"] < 0 else "neutral"
            when = f"broke {p['since']} candles ago" if p["status"] == "broken" else "forming"
            words.append(f"{p['tf']} {p['name']} ({side}, {when})")
        return AgentReport(self.name, clip(bias), clip(conf, 0, 1), "; ".join(words),
                           {"patterns": pats, "breakout": broken[0] if broken else None})
