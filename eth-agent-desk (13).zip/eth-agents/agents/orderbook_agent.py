"""Order-book agent: resting limit orders ("walls") and bid/ask imbalance.

Two sources:
  * LIVE Binance depth (top 1000 levels per side = only the area close to price, a fraction of a percent for ETH).
  * walls.txt: far walls you read from Coinglass "large orders" (e.g. an ask wall $48M at 3955).

A big ask wall above price acts as resistance, a big bid wall below as support. Walls can be pulled at any moment
(spoofing), so the agent tracks how long each wall has stood and how often walls vanished before price reached them,
and lowers its confidence when they do. History does not exist for the past, so backtests leave this agent out.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from agents.base import BaseAgent, clip
from core.levels import load_walls
from core.models import AgentReport, MarketSnapshot


def usd(x: float) -> str:
    return f"${x / 1e6:.1f}M" if x >= 1e6 else f"${x / 1e3:.0f}k"


class OrderBookAgent(BaseAgent):
    name = "orderbook"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.c = cfg.get("orderbook", {}) or {}
        self._seen: dict = {}          # wall key -> first seen timestamp
        self._prev: dict | None = None  # {"ts", "price", "keys"}
        self._pulled = 0               # walls that disappeared while price was still far from them

    # ---------- live book ----------
    def _book_stats(self, book: dict, price: float) -> dict | None:
        bids = np.array(book.get("bids") or [], dtype=float).reshape(-1, 2)
        asks = np.array(book.get("asks") or [], dtype=float).reshape(-1, 2)
        if len(bids) == 0 or len(asks) == 0:
            return None
        cover = min(price - bids[:, 0].min(), asks[:, 0].max() - price)      # how far both sides are visible
        window = min(price * float(self.c.get("window_pct", 0.25)) / 100, cover)
        if window <= 0:
            return None
        b = bids[bids[:, 0] >= price - window]
        a = asks[asks[:, 0] <= price + window]
        bid_usd, ask_usd = float((b[:, 0] * b[:, 1]).sum()), float((a[:, 0] * a[:, 1]).sum())
        tot = bid_usd + ask_usd
        imb = (bid_usd - ask_usd) / tot if tot else 0.0

        step = float(self.c.get("bin_usd", 0.5))
        walls = []
        for side, arr in (("bid", b), ("ask", a)):
            if len(arr) == 0:
                continue
            bins = pd.Series(arr[:, 0] * arr[:, 1]).groupby(np.floor(arr[:, 0] / step).astype(int)).sum()
            typical = float(bins[bins > 0].median()) if (bins > 0).any() else 0.0
            thr = max(float(self.c.get("min_wall_usd", 400000)), float(self.c.get("wall_ratio", 3.0)) * typical)
            big = bins[bins >= thr].sort_values(ascending=False).head(int(self.c.get("max_walls_per_side", 3)))
            for k, v in big.items():
                walls.append({"price": float((k + 0.5) * step), "side": side, "usd": float(v), "source": "live"})
        return {"imbalance": imb, "bid_usd": bid_usd, "ask_usd": ask_usd, "window": window, "walls": walls}

    def _track(self, walls: list[dict], price: float, ts: pd.Timestamp) -> None:
        """Wall age, and count walls that vanished without price trading through them (possible spoofing)."""
        if self._prev is not None and ts < self._prev["ts"]:
            self._seen, self._prev, self._pulled = {}, None, 0      # time went backwards: a replay, start over
        step = float(self.c.get("bin_usd", 0.5))
        keys = {(w["side"], int(w["price"] // step)) for w in walls}
        if self._prev is not None:
            lo, hi = sorted((self._prev["price"], price))
            for key in self._prev["keys"] - keys:
                wp = (key[1] + 0.5) * step
                if not (lo - step <= wp <= hi + step) and abs(wp - price) / price < 0.003:
                    self._pulled += 1
        self._seen = {k: self._seen.get(k, ts) for k in keys}
        self._prev = {"ts": ts, "price": price, "keys": keys}
        for w in walls:
            first = self._seen.get((w["side"], int(w["price"] // step)), ts)
            w["age_min"] = round((ts - first).total_seconds() / 60, 1)

    # ---------- manual (Coinglass) walls ----------
    def _manual(self, price: float) -> list[dict]:
        out = []
        for w in load_walls(self.c.get("walls_file", "walls.txt")):
            side = w["side"] or ("ask" if w["price"] > price else "bid")
            out.append({"price": w["price"], "side": side, "usd": w["usd"], "source": "manual",
                        "dist_pct": abs(w["price"] - price) / price * 100})
        return out

    @staticmethod
    def _is_live(snap: MarketSnapshot) -> bool:
        return abs((pd.Timestamp.now(tz="UTC") - snap.ts).total_seconds()) < 1200

    # ---------- agent ----------
    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        price = snap.price
        parts, notes, details, walls = [], [], {}, []
        stats = self._book_stats(snap.book, price) if snap.book else None
        if stats:
            self._track(stats["walls"], price, snap.ts)
            walls += stats["walls"]
            imb = stats["imbalance"]
            parts.append((0.5, clip(1.6 * imb)))
            bw = max([w["usd"] for w in stats["walls"] if w["side"] == "bid"] or [0.0])
            aw = max([w["usd"] for w in stats["walls"] if w["side"] == "ask"] or [0.0])
            if bw + aw > 0:
                parts.append((0.3, (bw - aw) / (bw + aw)))
            details.update(imbalance=imb, bid_usd=stats["bid_usd"], ask_usd=stats["ask_usd"], window_pct=stats["window"] / price * 100)
            notes.append(f"Book within {stats['window'] / price * 100:.2f}%: bids {usd(stats['bid_usd'])} vs asks {usd(stats['ask_usd'])} "
                         f"({(1 + imb) * 50:.0f}:{(1 - imb) * 50:.0f})")

        manual = self._manual(price) if self._is_live(snap) else []
        near = [w for w in manual if w["dist_pct"] <= float(self.c.get("manual_range_pct", 1.5))]
        if near:
            s = 0.0
            for w in near:
                size = w["usd"] / (w["usd"] + 10e6)                 # $10M counts half, $50M about 0.83
                s += (1 if w["side"] == "bid" else -1) * size / (1 + w["dist_pct"] / 0.5)
            parts.append((0.4, clip(s)))
        walls += manual

        walls.sort(key=lambda w: abs(w["price"] - price))
        details.update(walls=walls, pulled=self._pulled)
        if manual:
            nxt = min(manual, key=lambda w: abs(w["price"] - price))
            notes.append(f"manual wall nearest: {nxt['side']} {nxt['price']:.1f} ({usd(nxt['usd'])}, {nxt['dist_pct']:.2f}% away)")
        live_w = [w for w in walls if w["source"] == "live"]
        if live_w:
            top = live_w[:2]
            notes.append("live walls: " + ", ".join(f"{w['side']} {w['price']:.1f} ({usd(w['usd'])}, {w.get('age_min', 0):.0f} min)" for w in top))

        if not parts:
            msg = "No order-book data (live Binance depth only; add far walls in walls.txt)" if not manual else \
                  "Manual walls too far from price to matter; no live depth"
            return AgentReport(self.name, 0.0, 0.0, msg, {**details, "no_data": True})
        wsum = sum(w for w, _ in parts)
        bias = clip(sum(w * s for w, s in parts) / wsum)
        conf = 0.2 + 0.4 * abs(bias)
        if self._pulled >= 2:
            conf *= 0.6
            notes.append(f"{self._pulled} walls vanished before price reached them: treat walls with suspicion")
        return AgentReport(self.name, bias, clip(conf, 0, 1), "; ".join(notes), details)
