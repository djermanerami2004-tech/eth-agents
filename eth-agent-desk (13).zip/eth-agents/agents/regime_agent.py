"""Regime agent: what kind of market is this? trend, range, squeeze or in between.

It is a CONTEXT agent. Its default weight in the composite score is 0: instead of voting on direction it tells the
manager which strategies fit the current market (trend followers in a trend, sweep reversals in a range, breakouts
after a squeeze) through `details["fit"]`, a multiplier on each setup's quality when the manager picks the best one.
It never creates or blocks a trade. Edit the table in `regime.fit` of config.yaml; set a weight > 0 to let the
trend direction also vote."""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent, clip
from core.indicators import adx, atr, bollinger, ema
from core.models import AgentReport, MarketSnapshot

DEFAULT_FIT = {
    "trend": {"trend_pullback": 1.15, "bos_retest": 1.1, "sweep_reversal": 0.85, "session_sweep": 0.9},
    "range": {"trend_pullback": 0.8, "bos_retest": 0.85, "sweep_reversal": 1.15, "session_sweep": 1.1,
              "range_breakout": 0.9, "pattern_breakout": 0.9},
    "squeeze": {"pattern_breakout": 1.15, "range_breakout": 1.15, "trend_pullback": 0.9},
}


class RegimeAgent(BaseAgent):
    name = "regime"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.c = cfg.get("regime", {}) or {}
        self.entry, self.htf = cfg["market"]["entry_tf"], cfg["market"]["htf"]

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        h, e = snap.candles[self.htf], snap.candles[self.entry]
        if len(h) < 80 or len(e) < 120:
            return AgentReport(self.name, 0.0, 0.0, "Not enough candles to classify the market", {"no_data": True})
        n_er = int(self.c.get("er_bars", 30))
        adx_v = float(adx(h).iloc[-1])
        path = float(h["close"].diff().abs().tail(n_er).sum())
        er = abs(float(h["close"].iloc[-1] - h["close"].iloc[-1 - n_er])) / path if path else 0.0
        slope = float(ema(h["close"], 50).iloc[-1] - ema(h["close"], 50).iloc[-6])
        direction = 1 if slope > 0 else -1
        lo, _, up = bollinger(e["close"], 20, 2.0)
        bw = ((up - lo) / e["close"]).dropna().tail(int(self.c.get("squeeze_lookback", 300)))
        bw_pct = float((bw < bw.iloc[-1]).mean())                # 0 = tightest the market has been lately
        a = atr(e)
        atr_pct = float((a.tail(200) < a.iloc[-1]).mean())

        trend_adx, range_adx = float(self.c.get("trend_adx", 25)), float(self.c.get("range_adx", 20))
        if bw_pct <= float(self.c.get("squeeze_pct", 0.15)):
            regime = "squeeze"
            note = f"Squeeze: 15m Bollinger bands are tighter than {1 - bw_pct:.0%} of the last {len(bw)} candles; a breakout is building"
        elif adx_v >= trend_adx and er >= float(self.c.get("trend_er", 0.3)):
            regime = "trend"
            note = f"{'Up' if direction > 0 else 'Down'}trend: {self.htf} ADX {adx_v:.0f}, efficiency {er:.2f}"
        elif adx_v < range_adx and er < float(self.c.get("range_er", 0.25)):
            regime = "range"
            note = f"Range: {self.htf} ADX {adx_v:.0f}, efficiency {er:.2f}; price is rotating, not trending"
        else:
            regime = "mixed"
            note = f"Mixed: {self.htf} ADX {adx_v:.0f}, efficiency {er:.2f}; no clear regime"
        table = {**DEFAULT_FIT, **(self.c.get("fit") or {})}
        fit = dict(table.get(regime, {}))
        bias = conf = 0.0
        if regime == "trend":
            bias = direction * clip(0.25 + (adx_v - trend_adx) / 40, 0, 0.7)
            conf = clip(0.3 + er, 0, 0.8)
        details = {"regime": regime, "adx": adx_v, "efficiency": er, "bandwidth_percentile": bw_pct, "atr_percentile": atr_pct,
                   "trend_direction": direction if regime == "trend" else 0, "fit": fit,
                   "volatility": "high" if atr_pct > 0.8 else "low" if atr_pct < 0.2 else "normal"}
        return AgentReport(self.name, float(bias), float(conf), note, details)
