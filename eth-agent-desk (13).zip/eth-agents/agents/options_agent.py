"""Options agent: what the ETH options market on Deribit (free public data) says about where price may be pulled or pinned.

Three small readings, each a heuristic and not a proven edge:
  * max pain: near an expiry with big open interest, price tends to drift toward the strike where option holders lose
    the most. The pull counts more the closer the expiry and the bigger its open interest.
  * gamma walls: strikes with the largest dealer gamma (assumes dealers are long calls / short puts). A big call wall just
    above price tends to cap it, a big put wall just below tends to hold it. Total gamma negative = moves can accelerate,
    so the max-pain pull is trusted less.
  * sentiment extremes: a very negative 25-delta risk reversal / very high put-call ratio = crowded hedging (mild long),
    the opposite = crowded calls (mild short). Only at extremes, small weight.
Live only: Deribit has no history, so backtests leave this agent out.
"""
from __future__ import annotations

import time

from agents.base import BaseAgent, clip
from core import options as ox
from core.deribit import options as fetch_options
from core.models import AgentReport, MarketSnapshot


def usd(x: float) -> str:
    x = abs(x)
    return f"${x / 1e9:.1f}B" if x >= 1e9 else f"${x / 1e6:.0f}M" if x >= 1e6 else f"${x / 1e3:.0f}k"


def fmt_exp(ms: int) -> str:
    return time.strftime("%d %b %H:%M UTC", time.gmtime(ms / 1000))


class OptionsAgent(BaseAgent):
    name = "options"

    def __init__(self, cfg: dict, fetch=None):
        super().__init__(cfg)
        self.c = cfg.get("options", {}) or {}
        self._fetch = fetch or (lambda: fetch_options(cfg))

    def _none(self, msg: str, **d) -> AgentReport:
        return AgentReport(self.name, 0.0, 0.0, msg, {**d, "no_data": True})

    def analyze(self, snap: MarketSnapshot, now_ms: int | None = None) -> AgentReport:
        c = self.c
        if not c.get("enabled", True):
            return self._none("Options agent is switched off in config.yaml")
        if str(snap.source).startswith("synthetic"):
            return self._none("Demo data: the options market only exists live")
        if abs(time.time() - snap.ts.timestamp()) > 1200:
            return self._none("Options data is live only (Deribit keeps no history), left out of replays and backtests")
        res = self._fetch()
        if res["error"]:
            return self._none(f"Deribit: {res['error']['msg']}", error=res["error"]["kind"])

        S, now_ms = snap.price, now_ms or int(time.time() * 1000)
        opts = res["options"]
        exps = ox.by_expiry(opts, now_ms)
        if not exps:
            return self._none("Deribit shows no open option expiries")

        # --- max pain per upcoming expiry (only those that carry real open interest) ---
        pull_days, min_oi = float(c.get("pull_days", 7)), float(c.get("min_oi_usd", 50e6))
        rows, oi_max = [], 0.0
        for exp, rs in exps.items():
            hours = (exp - now_ms) / 3.6e6
            oi_usd = sum(o["oi"] for o in rs) * S
            mp = ox.max_pain(rs)
            if mp is None:
                continue
            rows.append({"expiry": fmt_exp(exp), "expiry_ms": exp, "hours": hours, "max_pain": mp, "oi_usd": oi_usd,
                         "pcr": ox.put_call_ratio(rs), "dist_pct": (mp - S) / S * 100})
            if hours <= pull_days * 24:
                oi_max = max(oi_max, oi_usd)
        rows = rows[:6]
        num = den = 0.0
        dead = float(c.get("pull_dead_pct", 0.3))
        for r in rows:
            if r["hours"] > pull_days * 24 or r["oi_usd"] < min_oi or oi_max <= 0:
                continue
            w = (1 - r["hours"] / (pull_days * 24)) * (r["oi_usd"] / oi_max)
            mag = max(0.0, min(1.0, (abs(r["dist_pct"]) - dead) / 2.0))
            num += w * mag * (1 if r["dist_pct"] > 0 else -1)
            den += w
        pull = num / den if den > 0 else 0.0

        # --- gamma map ---
        gex = ox.gex_at(opts, S, now_ms)
        total = sum(gex.values())
        absum = sum(abs(v) for v in gex.values()) or 1.0
        flip = ox.gamma_flip(opts, S, now_ms)
        rng = float(c.get("wall_range_pct", 2.0))
        share = float(c.get("wall_min_share", 0.12))
        above = [(k, v) for k, v in gex.items() if S < k <= S * (1 + rng / 100) and v > 0 and v / absum >= share]
        below = [(k, v) for k, v in gex.items() if S > k >= S * (1 - rng / 100) and v < 0 and abs(v) / absum >= share]
        call_wall = max(above, key=lambda kv: kv[1]) if above else None
        put_wall = max(below, key=lambda kv: abs(kv[1])) if below else None
        wall = 0.0
        if call_wall:
            wall -= 1 - (call_wall[0] - S) / S * 100 / rng * 0.7
        if put_wall:
            wall += 1 - (S - put_wall[0]) / S * 100 / rng * 0.7
        top = sorted(gex.items(), key=lambda kv: -abs(kv[1]))[:12]
        positive = total >= 0

        # --- sentiment extremes ---
        rr = ox.risk_reversal(opts, S, now_ms, float(c.get("skew_min_days", 7)))
        pcr_all = ox.put_call_ratio(opts)
        votes = []
        if rr:
            votes.append(1.0 if rr["rr25"] <= -float(c.get("rr_extreme", 6.0)) else -1.0 if rr["rr25"] >= float(c.get("rr_extreme", 6.0)) else 0.0)
        if pcr_all is not None:
            votes.append(1.0 if pcr_all >= float(c.get("pcr_high", 1.0)) else -1.0 if pcr_all <= float(c.get("pcr_low", 0.4)) else 0.0)
        sent = sum(votes) / len(votes) if votes else 0.0

        mag_scale = 1.0 if positive else 0.7           # negative gamma: pins are weaker, moves can run
        bias = clip((0.5 * pull * mag_scale + 0.3 * clip(wall) + 0.2 * sent))
        conf = clip(0.15 + 0.35 * abs(bias), 0, 0.5)

        near = next((r for r in rows if r["oi_usd"] >= min_oi), rows[0] if rows else None)
        parts = []
        if near:
            parts.append(f"max pain {near['max_pain']:.0f} for {near['expiry']} ({near['dist_pct']:+.1f}% from price, OI {usd(near['oi_usd'])})")
        parts.append(f"dealer gamma {'positive (pins / dampens)' if positive else 'negative (moves can accelerate)'} {usd(total)} per 1%")
        if call_wall:
            parts.append(f"call wall {call_wall[0]:.0f}")
        if put_wall:
            parts.append(f"put wall {put_wall[0]:.0f}")
        if rr:
            parts.append(f"25d risk reversal {rr['rr25']:+.1f} vol")
        if pcr_all is not None:
            parts.append(f"put/call OI {pcr_all:.2f}")
        details = {"expiries": rows, "max_pain": near["max_pain"] if near else None, "net_gex_usd": total, "gamma_positive": positive,
                   "gamma_flip": flip, "call_wall": call_wall[0] if call_wall else None, "put_wall": put_wall[0] if put_wall else None,
                   "gex_top": [{"strike": k, "gex_usd": v} for k, v in sorted(top)], "risk_reversal": rr, "pcr": pcr_all,
                   "components": {"pull": round(pull, 3), "walls": round(clip(wall), 3), "sentiment": round(sent, 3)}}
        return AgentReport(self.name, bias, conf, "; ".join(parts), details)
