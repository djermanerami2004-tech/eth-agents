"""BTC agent: does Bitcoin confirm the ETH move, and is ETH lagging a BTC move?

ETH rarely trends for long against BTC. Two things are read:
  * BTC trend: BTC price against its 1h EMA20 in ATR units (a market-wide push);
  * catch-up: BTC moved over the last hour and ETH, given its usual beta to BTC, has not followed yet (leans toward ETH catching up).
Both are scaled by the recent correlation. If ETH has decoupled from BTC (correlation < min_corr) the agent says nothing.
It uses candles only (BTC candles ride along in the snapshot), so it is also used in backtests; without BTC data it stays out."""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent, clip
from core.indicators import atr, ema
from core.models import AgentReport, MarketSnapshot


class BtcAgent(BaseAgent):
    name = "btc"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.c = cfg.get("btc", {}) or {}
        self.entry, self.htf = cfg["market"]["entry_tf"], cfg["market"]["htf"]

    def _none(self, msg: str, **d) -> AgentReport:
        return AgentReport(self.name, 0.0, 0.0, msg, {**d, "no_data": True})

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        if not snap.ref or self.entry not in snap.ref or self.htf not in snap.ref:
            return self._none("No BTC candles (set market.ref_symbol in config.yaml, or the download failed)")
        eth, btc = snap.candles[self.entry], snap.ref[self.entry]
        idx = eth.index.intersection(btc.index)
        bars = int(self.c.get("corr_bars", 96))
        if len(idx) < bars + 10:
            return self._none("Not enough overlapping BTC and ETH candles")
        r_e = np.log(eth["close"].reindex(idx)).diff().dropna().tail(bars)
        r_b = np.log(btc["close"].reindex(idx)).diff().dropna().tail(bars)
        corr = float(np.corrcoef(r_e, r_b)[0, 1])
        min_corr = float(self.c.get("min_corr", 0.3))
        if not corr == corr or corr < min_corr:
            return self._none(f"ETH is decoupled from BTC (correlation {corr:.2f} < {min_corr}), BTC says nothing right now", corr=corr)
        beta = float(np.cov(r_e, r_b)[0, 1] / max(r_b.var(), 1e-12))

        bh = snap.ref[self.htf]
        a_h = float(atr(bh).iloc[-1])
        t1 = clip((float(bh["close"].iloc[-1]) - float(ema(bh["close"], 20).iloc[-1])) / (2 * a_h)) if a_h else 0.0

        k = int(self.c.get("catchup_bars", 4))
        R_b, R_e = float(r_b.tail(k).sum()), float(r_e.tail(k).sum())
        sd_b, sd_e = float(r_b.std()), float(r_e.std())
        btc_z = R_b / (sd_b * k ** 0.5) if sd_b else 0.0
        gap_z = (beta * R_b - R_e) / (sd_e * k ** 0.5) if sd_e else 0.0
        catch = float(np.tanh(0.8 * gap_z)) if abs(btc_z) >= float(self.c.get("min_btc_move_z", 1.0)) else 0.0

        scale = min(1.0, corr / 0.6)
        bias = clip((0.5 * t1 + 0.5 * catch) * scale)
        conf = clip(0.2 + 0.4 * min(1.0, corr) * min(1.0, (abs(t1) + abs(catch)) / 1.2), 0, 0.7)
        parts = [f"BTC {'above' if t1 > 0.05 else 'below' if t1 < -0.05 else 'at'} its {self.htf} EMA20 ({t1:+.2f})"]
        if catch:
            parts.append(f"BTC moved {R_b * 100:+.2f}% in {k} candles and ETH {R_e * 100:+.2f}% (expected {beta * R_b * 100:+.2f}%): "
                         f"ETH {'lags, leans up' if catch > 0 else 'is ahead, leans down'}")
        parts.append(f"correlation {corr:.2f}, beta {beta:.2f}")
        return AgentReport(self.name, float(bias), float(conf), "; ".join(parts),
                           {"correlation": corr, "beta": beta, "btc_trend": t1, "btc_move_z": btc_z, "eth_gap_z": gap_z,
                            "catch_up": catch, "btc_price": float(snap.ref[self.entry]["close"].iloc[-1])})
