"""Whale agent: big resting limit orders from Coinglass ("large orders", the walls you see on their order-book page).

A large ask above price is resistance, a large bid below is support; the closer and the bigger, the more it counts.
Three things lower the trust in a wall: it is young (appeared a few minutes ago, could be a spoof), it has already been
eaten (most of it executed), or many large orders were just cancelled (walls are being pulled). Live only: Coinglass has
no history for the past, so backtests leave this agent out. It needs the Standard Coinglass plan or higher; on a lower
plan or without a key it says so and stays out of the score."""
from __future__ import annotations

import time

from agents.base import BaseAgent, clip
from core.coinglass import large_orders
from core.models import AgentReport, MarketSnapshot


def usd(x: float) -> str:
    return f"${x / 1e6:.1f}M" if x >= 1e6 else f"${x / 1e3:.0f}k"


class WhaleAgent(BaseAgent):
    name = "whales"

    def __init__(self, cfg: dict, fetch=None):
        super().__init__(cfg)
        self.c = cfg.get("coinglass", {}) or {}
        self._fetch = fetch or (lambda: large_orders(cfg))

    def _none(self, msg: str, **d) -> AgentReport:
        return AgentReport(self.name, 0.0, 0.0, msg, {**d, "no_data": True})

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        if not self.c.get("enabled", True):
            return self._none("Whale orders are switched off in config.yaml")
        if str(snap.source).startswith("synthetic"):
            return self._none("Demo data: whale orders only exist live")
        if abs(time.time() - snap.ts.timestamp()) > 1200:
            return self._none("Whale orders are live only (Coinglass keeps no history), left out of replays and backtests")
        res = self._fetch()
        if res["error"]:
            e = res["error"]
            msg = {"nokey": "No Coinglass key: add COINGLASS_API_KEY to .env to see whale orders"}.get(e["kind"], f"Coinglass: {e['msg']}")
            return self._none(msg, error=e["kind"])

        price, now_ms = snap.price, int(time.time() * 1000)
        rng_pct = float(self.c.get("range_pct", 2.5))
        min_usd = float(self.c.get("min_usd", 1_000_000))
        young_min = float(self.c.get("young_minutes", 5))
        opens, cancels = [], 0
        for o in res["orders"]:
            if o["state"] == 3 and o["end_ms"] and now_ms - o["end_ms"] <= 30 * 60_000 and o["start_usd"] >= min_usd:
                cancels += 1
            if o["state"] != 1 or o["usd"] < min_usd:
                continue
            dist = abs(o["price"] - price) / price * 100
            if dist > rng_pct:
                continue
            side_ok = (o["side"] == "ask" and o["price"] > price) or (o["side"] == "bid" and o["price"] < price)
            if not side_ok:
                continue          # a "bid" above price / "ask" below price is being crossed right now: ignore it
            age_min = (now_ms - o["start_ms"]) / 60_000
            eaten = o["executed_usd"] / (o["executed_usd"] + o["usd"]) if (o["executed_usd"] + o["usd"]) else 0.0
            trust = (0.5 if age_min < young_min else 1.0) * (0.6 if eaten > 0.5 else 1.0)
            opens.append({"price": o["price"], "side": o["side"], "usd": o["usd"], "dist_pct": dist, "age_min": round(age_min, 1),
                          "eaten": round(eaten, 2), "trust": trust, "exchange": o["exchange"]})
        if not opens:
            return self._none(f"No whale order of {usd(min_usd)}+ within {rng_pct:g}% of price"
                              f"{' (' + str(cancels) + ' large orders cancelled in the last 30 min)' if cancels else ''}",
                              walls=[], cancels=cancels)
        s = 0.0
        for w in opens:
            size = w["usd"] / (w["usd"] + 10e6)                 # $10M counts half, $50M about 0.83
            s += (1 if w["side"] == "bid" else -1) * size * w["trust"] / (1 + w["dist_pct"] / 0.5)
        bias = clip(s)
        conf = 0.2 + 0.4 * abs(bias)
        notes = []
        if cancels >= int(self.c.get("cancel_warn", 3)):
            conf *= 0.6
            notes.append(f"{cancels} large orders were cancelled in the last 30 min: walls are being pulled, treat them with suspicion")
        opens.sort(key=lambda w: w["dist_pct"])
        bid_usd, ask_usd = sum(w["usd"] for w in opens if w["side"] == "bid"), sum(w["usd"] for w in opens if w["side"] == "ask")
        near_b = next((w for w in opens if w["side"] == "bid"), None)
        near_a = next((w for w in opens if w["side"] == "ask"), None)
        head = f"Whale orders within {rng_pct:g}%: bids {usd(bid_usd)} vs asks {usd(ask_usd)}"
        if near_b:
            head += f"; nearest bid {near_b['price']:.1f} ({usd(near_b['usd'])}, {near_b['dist_pct']:.2f}% away)"
        if near_a:
            head += f"; nearest ask {near_a['price']:.1f} ({usd(near_a['usd'])}, {near_a['dist_pct']:.2f}% away)"
        return AgentReport(self.name, bias, clip(conf, 0, 1), "; ".join([head] + notes),
                           {"walls": opens[:20], "bid_usd": bid_usd, "ask_usd": ask_usd, "cancels": cancels, "range_pct": rng_pct})
