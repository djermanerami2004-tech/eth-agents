"""Structure agent: market structure (HH/HL, BOS/CHoCH), premium/discount, FVGs and order blocks."""
from __future__ import annotations

import pandas as pd

from agents.base import BaseAgent, clip
from core.indicators import atr, swings
from core.models import AgentReport, MarketSnapshot
from core.smc import find_fvgs, find_order_blocks

EVENT_DIR = {"BOS_UP": 1, "CHOCH_UP": 1, "BOS_DOWN": -1, "CHOCH_DOWN": -1}


class StructureAgent(BaseAgent):
    name = "structure"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.tf = cfg["market"]["entry_tf"]
        self.htf = cfg["market"]["htf"]

    def _tf(self, df: pd.DataFrame, tf: str) -> dict:
        df = df.tail(300)
        a_s = atr(df)
        a = float(a_s.iloc[-1])
        sh, sl = swings(df)
        highs, lows = sh.dropna(), sl.dropna()
        trend = 0
        if len(highs) >= 2 and len(lows) >= 2:
            hh, hl = highs.iloc[-1] > highs.iloc[-2], lows.iloc[-1] > lows.iloc[-2]
            if hh and hl:
                trend = 1
            elif (not hh) and (not hl):
                trend = -1
        event = None
        if len(highs) and len(lows):
            c = float(df["close"].iloc[-1])
            if c > highs.iloc[-1]:
                event = "BOS_UP" if trend == 1 else "CHOCH_UP"
            elif c < lows.iloc[-1]:
                event = "BOS_DOWN" if trend == -1 else "CHOCH_DOWN"
        hi, lo = float(df["high"].tail(100).max()), float(df["low"].tail(100).min())
        zones = find_fvgs(df) + find_order_blocks(df, a_s)
        for z in zones:
            z["tf"] = tf
        return {"trend": trend, "event": event, "atr": a, "range": (lo, hi), "zones": zones,
                "last_swing_high": float(highs.iloc[-1]) if len(highs) else None,
                "last_swing_low": float(lows.iloc[-1]) if len(lows) else None}

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        price = snap.price
        l = self._tf(snap.candles[self.tf], self.tf)
        h = self._tf(snap.candles[self.htf], self.htf)
        score = 0.40 * h["trend"] + 0.25 * l["trend"] + 0.20 * EVENT_DIR.get(l["event"], 0)

        lo, hi = h["range"]
        pos = (price - lo) / (hi - lo) if hi > lo else 0.5
        if pos < 0.4:
            score += 0.10
        elif pos > 0.6:
            score -= 0.10

        a = l["atr"]
        zones = l["zones"] + [z for z in h["zones"] if z["type"] == "OB"]
        near = None
        for z in zones:
            d = max(z["low"] - price, price - z["high"], 0.0)
            if d <= 0.5 * a:
                score += 0.20 if z["kind"] == "bull" else -0.20
                near = z
                break

        bias = clip(score)
        conf = clip(0.35 + 0.65 * abs(bias), 0, 1)
        trend_word = {1: "up", -1: "down", 0: "range"}
        summary = (f"{self.htf} trend {trend_word[h['trend']]}, {self.tf} trend {trend_word[l['trend']]}, "
                   f"event {l['event'] or 'none'}, price at {pos:.0%} of {self.htf} range"
                   + (f", inside/near {near['kind']} {near['type']}" if near else ""))
        return AgentReport(self.name, bias, conf, summary,
                           {"ltf": {k: v for k, v in l.items() if k != "zones"},
                            "htf": {k: v for k, v in h.items() if k != "zones"},
                            "zones": zones, "range_pos": pos, "atr": a})
