"""Journal agent: SQLite trade journal, paper-trade tracking, performance stats and live risk state.

Two ways to use it (config: journal.paper_mode):
- paper_mode true  : every approved signal is tracked automatically with the SAME rules as the backtest
                     (core/tradesim.py). Run the loop for a few weeks and read `journal stats`.
- paper_mode false : signals are only logged; you mark them yourself with `journal take/skip/close`.
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pandas as pd

from core.metrics import summarize
from core.models import RiskState, TradePlan
from core.tradesim import SimParams, SimTrade, advance, new_trade

SCHEMA = """
CREATE TABLE IF NOT EXISTS trades(
 id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, side TEXT, entry_type TEXT,
 entry REAL, stop REAL, tp1 REAL, tp2 REAL, size REAL, risk_usd REAL, rr REAL,
 score REAL, confidence REAL, status TEXT, taken_ts TEXT, exit_ts TEXT,
 exit_price REAL, pnl_usd REAL, r_mult REAL, reports TEXT, notes TEXT, sim TEXT, strategy TEXT)
"""
LIST_COLS = ("id,ts,strategy,side,entry_type,entry,stop,tp1,tp2,size,risk_usd,rr,confidence,status,"
             "exit_price,pnl_usd,r_mult,notes")


def _iso(t) -> str:
    t = pd.Timestamp(t)
    return (t.tz_convert("UTC") if t.tzinfo else t.tz_localize("UTC")).isoformat()


class JournalAgent:
    name = "journal"

    def __init__(self, cfg: dict, path: str | None = None):
        self.cfg = cfg
        self.contract = cfg["account"]["contract_size"]
        self.paper = bool(cfg.get("journal", {}).get("paper_mode", False))
        self.params = SimParams.from_cfg(cfg)
        p = path or cfg["journal"]["path"]
        if p != ":memory:":
            Path(p).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(p, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute(SCHEMA)
        cols = {r[1] for r in self.db.execute("PRAGMA table_info(trades)")}
        for col in ("sim", "strategy"):  # databases created by an older version
            if col not in cols:
                self.db.execute(f"ALTER TABLE trades ADD COLUMN {col} TEXT")
        self.db.commit()

    # ---------- write ----------
    def record_signal(self, plan: TradePlan, reports: dict, paper: bool | None = None) -> int:
        paper = self.paper if paper is None else paper
        status, sim, taken = "signal", None, None
        if paper:
            st = new_trade(plan, self.contract, market_filled=plan.entry_type == "MARKET")
            status, sim = st.state, json.dumps(st.to_dict())
            taken = plan.ts if st.state == "open" else None
        cur = self.db.execute(
            "INSERT INTO trades(ts,side,entry_type,entry,stop,tp1,tp2,size,risk_usd,rr,score,confidence,"
            "status,taken_ts,reports,sim,strategy) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (plan.ts, plan.side, plan.entry_type, plan.entry, plan.stop, plan.tp1, plan.tp2, plan.size,
             plan.risk_usd, plan.rr, plan.score, plan.confidence, status, taken,
             json.dumps({k: v.summary for k, v in reports.items()}), sim, plan.strategy))
        self.db.commit()
        return int(cur.lastrowid)

    def take(self, trade_id: int, now=None) -> None:
        now = now or pd.Timestamp.now(tz="UTC")
        self.db.execute("UPDATE trades SET status='open', taken_ts=? WHERE id=? AND status='signal'",
                        (_iso(now), trade_id))
        self.db.commit()

    def skip(self, trade_id: int) -> None:
        self.db.execute("UPDATE trades SET status='skipped' WHERE id=? AND status='signal'", (trade_id,))
        self.db.commit()

    def close(self, trade_id: int, exit_price: float, now=None, notes: str = "") -> dict:
        now = now or pd.Timestamp.now(tz="UTC")
        t = self.get(trade_id)
        if t is None:
            raise ValueError(f"No trade with id {trade_id}")
        if t["status"] in ("closed", "expired", "skipped"):
            raise ValueError(f"Trade {trade_id} is already {t['status']}")
        d = 1 if t["side"] == "LONG" else -1
        pnl = (exit_price - t["entry"]) * d * t["size"] * self.contract
        risk = t["risk_usd"] or 1e-9
        taken = t["taken_ts"] or _iso(now)
        self.db.execute("UPDATE trades SET status='closed', taken_ts=?, exit_ts=?, exit_price=?, pnl_usd=?, "
                        "r_mult=?, notes=?, sim=NULL WHERE id=?",
                        (taken, _iso(now), exit_price, round(pnl, 2), round(pnl / risk, 2), notes, trade_id))
        self.db.commit()
        return self.get(trade_id)

    def settle(self, candles: pd.DataFrame, tf_minutes: int, now) -> list[dict]:
        """Advance every auto-tracked (paper) trade with the candles that closed since its last update."""
        step = pd.Timedelta(minutes=tf_minutes)
        now = pd.Timestamp(now)
        done = candles[candles.index + step <= now]
        changed = []
        rows = self.db.execute("SELECT * FROM trades WHERE status IN ('open','pending') AND sim IS NOT NULL "
                               "ORDER BY id").fetchall()
        for row in rows:
            sim = SimTrade.from_dict(json.loads(row["sim"]))
            if sim.last_ts:
                new = done[done.index > pd.Timestamp(sim.last_ts)]
            else:
                new = done[done.index >= pd.Timestamp(row["ts"])]
            status, taken = row["status"], row["taken_ts"]
            for ts, c in new.iterrows():
                before = sim.state
                advance(sim, float(c["high"]), float(c["low"]), float(c["close"]), self.params, ts=str(ts))
                if before == "pending" and sim.state == "open":
                    status, taken = "open", _iso(ts)
                if sim.state in ("closed", "expired"):
                    break
            if sim.state == "closed":
                self.db.execute("UPDATE trades SET status='closed', taken_ts=?, exit_ts=?, exit_price=?, pnl_usd=?, "
                                "r_mult=?, notes=?, sim=? WHERE id=?",
                                (taken, _iso(pd.Timestamp(sim.last_ts) + step), sim.exit_price, round(sim.pnl_usd, 2),
                                 round(sim.r, 2), f"paper: {sim.exit_reason}", json.dumps(sim.to_dict()), row["id"]))
                changed.append(self.get(row["id"]))
            elif sim.state == "expired":
                self.db.execute("UPDATE trades SET status='expired', notes=?, sim=? WHERE id=?",
                                (f"paper: {sim.exit_reason}", json.dumps(sim.to_dict()), row["id"]))
                changed.append(self.get(row["id"]))
            else:
                self.db.execute("UPDATE trades SET status=?, taken_ts=?, sim=? WHERE id=?",
                                (status, taken, json.dumps(sim.to_dict()), row["id"]))
        self.db.commit()
        return changed

    # ---------- read ----------
    def get(self, trade_id: int) -> dict | None:
        row = self.db.execute("SELECT * FROM trades WHERE id=?", (trade_id,)).fetchone()
        return dict(row) if row else None

    def list(self, limit: int = 20) -> pd.DataFrame:
        return pd.read_sql_query(f"SELECT {LIST_COLS} FROM trades ORDER BY id DESC LIMIT ?", self.db,
                                 params=(limit,))

    def recent_signal(self, side: str, minutes: int, now) -> bool:
        cutoff = _iso(pd.Timestamp(now) - pd.Timedelta(minutes=minutes))
        row = self.db.execute("SELECT 1 FROM trades WHERE side=? AND ts>=? LIMIT 1", (side, cutoff)).fetchone()
        return row is not None

    def risk_state(self, now) -> RiskState:
        day = _iso(now)[:10]
        q = self.db.execute
        total = q("SELECT COALESCE(SUM(pnl_usd),0) FROM trades WHERE status='closed'").fetchone()[0]
        daily = q("SELECT COALESCE(SUM(pnl_usd),0) FROM trades WHERE status='closed' AND substr(exit_ts,1,10)=?",
                  (day,)).fetchone()[0]
        taken = q("SELECT COUNT(*) FROM trades WHERE status IN ('open','closed') AND substr(taken_ts,1,10)=?",
                  (day,)).fetchone()[0]
        active = q("SELECT COUNT(*) FROM trades WHERE status IN ('open','pending')").fetchone()[0]
        recent = q("SELECT pnl_usd FROM trades WHERE status='closed' AND substr(exit_ts,1,10)=? "
                   "ORDER BY exit_ts DESC", (day,)).fetchall()
        streak = 0
        for r in recent:
            if r[0] < 0:
                streak += 1
            else:
                break
        return RiskState(float(daily), float(total), int(taken), streak, int(active))

    def closed_trades(self) -> pd.DataFrame:
        df = pd.read_sql_query("SELECT id, ts, strategy, side, taken_ts, exit_ts, pnl_usd, r_mult AS r, notes FROM trades "
                               "WHERE status='closed' ORDER BY exit_ts", self.db)
        return df

    def stats(self) -> dict:
        df = self.closed_trades()
        s = summarize(df, self.cfg["account"]["size"]) if not df.empty else summarize(df, 1)
        s["open"] = int(self.db.execute("SELECT COUNT(*) FROM trades WHERE status IN ('open','pending')").fetchone()[0])
        s["signals"] = int(self.db.execute("SELECT COUNT(*) FROM trades").fetchone()[0])
        return s
