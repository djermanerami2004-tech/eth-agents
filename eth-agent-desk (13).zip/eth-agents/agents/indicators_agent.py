"""Indicators agent: a vote from classic indicators on the entry and higher timeframe.
Trend followers (EMA, MACD) and mean-reversion tools (RSI, Bollinger) are shown separately in `details`."""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent, clip
from core.indicators import atr, bollinger, ema, macd, rsi
from core.models import AgentReport, MarketSnapshot


class IndicatorsAgent(BaseAgent):
    name = "indicators"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.tf, self.htf = cfg["market"]["entry_tf"], cfg["market"]["htf"]

    @staticmethod
    def _one(df) -> dict:
        c = df["close"]
        e20, e50 = ema(c, 20), ema(c, 50)
        _, _, hist = macd(c)
        r = float(rsi(c).iloc[-1])
        lo, mid, hi = bollinger(c)
        pb = float((c.iloc[-1] - lo.iloc[-1]) / (hi.iloc[-1] - lo.iloc[-1] + 1e-12))
        a = atr(df)
        a_pct = float((a.tail(200) < a.iloc[-1]).mean())
        ema_s = 0.5 * np.sign(c.iloc[-1] - e50.iloc[-1]) + 0.5 * np.sign(e20.iloc[-1] - e50.iloc[-1])
        macd_s = float(np.tanh(hist.iloc[-1] / (a.iloc[-1] * 0.25 + 1e-12))) * (1.0 if hist.iloc[-1] > hist.iloc[-3] else 0.6)
        rsi_s = float(np.clip((50 - r) / 25, -1, 1)) if (r > 70 or r < 30) else 0.0     # only at extremes
        bb_s = float(np.clip((0.5 - pb) * 2, -1, 1)) if (pb > 1 or pb < 0) else 0.0      # only outside the bands
        return {"ema": float(ema_s), "macd": macd_s, "rsi": r, "rsi_s": rsi_s, "pctb": pb, "bb_s": bb_s,
                "atr_pctile": a_pct, "trend": 0.5 * float(ema_s) + 0.5 * macd_s}

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        l, h = self._one(snap.candles[self.tf]), self._one(snap.candles[self.htf])
        bias = 0.45 * l["trend"] + 0.25 * h["trend"] + 0.15 * l["rsi_s"] + 0.15 * l["bb_s"]
        bias = clip(float(bias))
        vol = "high" if l["atr_pctile"] > 0.8 else "low" if l["atr_pctile"] < 0.2 else "normal"
        conf = clip(0.3 + 0.5 * abs(bias), 0, 1) * (0.8 if vol == "low" else 1.0)
        word = lambda x: "up" if x > 0.15 else "down" if x < -0.15 else "flat"
        summary = (f"{self.tf}: EMA {word(l['ema'])}, MACD {word(l['macd'])}, RSI {l['rsi']:.0f}, %B {l['pctb']:.2f}; "
                   f"{self.htf}: EMA {word(h['ema'])}, MACD {word(h['macd'])}, RSI {h['rsi']:.0f}; volatility {vol}")
        return AgentReport(self.name, bias, conf, summary, {"ltf": l, "htf": h, "volatility": vol})
