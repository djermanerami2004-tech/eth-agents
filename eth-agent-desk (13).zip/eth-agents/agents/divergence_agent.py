"""Divergence agent: RSI divergences (regular = reversal, hidden = continuation) on the entry and the higher timeframe.
Works on candles only, so it is included in backtests. See core/divergence.py for the exact rules."""
from __future__ import annotations

from agents.base import BaseAgent, clip
from core.divergence import find_divergences
from core.indicators import atr
from core.models import AgentReport, MarketSnapshot


class DivergenceAgent(BaseAgent):
    name = "divergence"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.c = cfg.get("divergence", {}) or {}
        self.tfs = [cfg["market"]["htf"], cfg["market"]["entry_tf"]]

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        k_by_tf = self.c.get("pivot_bars", {"15m": 3, "1h": 3})
        weight = {self.tfs[0]: 1.0, self.tfs[1]: float(self.c.get("entry_tf_weight", 0.7))}
        found = []
        for tf in self.tfs:
            df = snap.candles[tf].tail(int(self.c.get("lookback", 300)))
            if len(df) < 60:
                continue
            a = float(atr(df).iloc[-1])
            for d in find_divergences(df, a, int(k_by_tf.get(tf, 3)), int(self.c.get("max_age_bars", 12)), tf,
                                      int(self.c.get("rsi_len", 14)), float(self.c.get("min_rsi_gap", 2.0)),
                                      bool(self.c.get("hidden", True)), zone_high=float(self.c.get("zone_high", 58)),
                                      zone_low=float(self.c.get("zone_low", 42))):
                d["strength"] = d["quality"] * weight[tf]
                found.append(d)
        if not found:
            return AgentReport(self.name, 0.0, 0.0, "No RSI divergence on " + " or ".join(self.tfs),
                               {"no_data": True, "divergences": []})
        contrib = sorted((d["dir"] * (0.3 + 0.5 * d["strength"]) for d in found), key=abs, reverse=True)
        bias = contrib[0] + 0.3 * sum(contrib[1:])
        best = max(found, key=lambda d: d["strength"])
        conf = 0.25 + 0.5 * best["strength"]
        words = [f"{d['tf']} {d['name']} (RSI {d['rsi_1']:.0f} -> {d['rsi_2']:.0f}, price {d['price_1']:.1f} -> {d['price_2']:.1f}, "
                 f"{d['since']} candles ago{', volume delta agrees' if d['delta_confirms'] else ''})"
                 for d in sorted(found, key=lambda d: -d["strength"])[:3]]
        return AgentReport(self.name, clip(bias), clip(conf, 0, 1), "; ".join(words), {"divergences": found})
