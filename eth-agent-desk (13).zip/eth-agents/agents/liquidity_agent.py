"""Liquidity agent: estimates where leveraged positions get liquidated (like a liquidation heatmap),
detects fresh liquidity sweeps, and returns a magnet/sweep bias.

The model estimate is an approximation. If you read exact levels from Coinglass, put them in
config.yaml -> liquidity.manual_levels and they override the estimate.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from agents.base import BaseAgent, clip
from core.indicators import atr
from core.levels import load_levels
from core.models import AgentReport, MarketSnapshot

MMR = 0.005  # maintenance margin rate assumption


class LiquidityAgent(BaseAgent):
    name = "liquidity"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.c = cfg["liquidity"]
        self.tf = cfg["market"]["entry_tf"]

    # ---------- cluster model ----------
    def build_clusters(self, df: pd.DataFrame, oi: pd.DataFrame | None, price: float) -> list[dict]:
        c = self.c
        n = len(df)
        close, open_ = df["close"].values, df["open"].values
        low, high, vol = df["low"].values, df["high"].values, df["volume"].values

        w = vol / (vol.mean() + 1e-9)
        if oi is not None and len(oi) > 5:
            o = oi["oi"].reindex(df.index, method="nearest")
            new = o.diff().clip(lower=0).fillna(0).values
            if new.mean() > 0:
                w = w * (0.5 + 0.5 * np.minimum(new / new.mean(), 4))

        # liquidation levels already hit by LATER price action are consumed.
        # the most recent `sweep_lookback` candles are left out so fresh sweeps stay visible.
        sl = int(c["sweep_lookback"])
        hist_n = max(0, n - sl)
        fut_min = np.full(n, np.inf)
        fut_max = np.full(n, -np.inf)
        run_min, run_max = np.inf, -np.inf
        for i in range(hist_n - 1, -1, -1):
            fut_min[i], fut_max[i] = run_min, run_max
            run_min, run_max = min(run_min, low[i]), max(run_max, high[i])
        # candles inside the sweep window keep fut_min=inf / fut_max=-inf, i.e. nothing consumed them yet

        long_share = 0.5 + 0.15 * np.sign(close - open_)
        levels, weights = [], []
        for lev, lw in c["leverage_mix"].items():
            lev = float(lev)
            liq_long = close * (1 - 1 / lev + MMR)
            liq_short = close * (1 + 1 / lev - MMR)
            a_l, a_s = fut_min > liq_long, fut_max < liq_short
            levels += [liq_long[a_l], liq_short[a_s]]
            weights += [(w * long_share * lw)[a_l], (w * (1 - long_share) * lw)[a_s]]
        levels, weights = np.concatenate(levels), np.concatenate(weights)
        if len(levels) == 0:
            return []

        bin_size = price * c["bin_pct"] / 100
        s = pd.Series(weights).groupby(np.floor(levels / bin_size).astype(int)).sum()
        s = s / s.max()
        clusters = []
        for b, strength in s.items():
            lvl = (b + 0.5) * bin_size
            dist = (lvl - price) / price * 100
            if abs(dist) > c["range_pct"] or strength < c["min_strength"]:
                continue
            clusters.append({"price": float(lvl), "strength": float(strength),
                             "side": "above" if lvl > price else "below",
                             "dist_pct": float(abs(dist)), "source": "model"})
        out = []
        for side in ("above", "below"):
            side_c = sorted([x for x in clusters if x["side"] == side], key=lambda x: -x["strength"])
            out += side_c[: c["max_per_side"]]
        return out

    def _manual(self, price: float) -> list[dict]:
        """Levels typed in config.yaml plus those in levels.txt (re-read whenever the file changes).
        Levels very far from price are stale and ignored, so an old file never distorts the analysis."""
        raw = list(self.c.get("manual_levels") or []) + load_levels(self.c.get("levels_file", "levels.txt"))
        max_dist = 2 * float(self.c.get("range_pct", 6.0))
        out = []
        for m in raw:
            p = float(m["price"])
            dist = abs(p - price) / price * 100
            if dist > max_dist:
                continue
            out.append({"price": p, "strength": float(m.get("strength", 1.0)),
                        "side": "above" if p > price else "below", "dist_pct": dist, "source": "manual"})
        return out

    # ---------- sweep ----------
    def _detect_sweep(self, df: pd.DataFrame, clusters: list[dict], a: float) -> dict | None:
        """A sweep = price was on one side of a level, wicked THROUGH it inside the window, and closed back on the
        original side. Closing beyond the level (a breakout) is not a sweep."""
        sl = int(self.c["sweep_lookback"])
        if len(df) <= sl + 1:
            return None
        recent = df.tail(sl)
        pre = float(df["close"].iloc[-sl - 1])      # where price was before the window
        last_close = float(df["close"].iloc[-1])
        best = None
        for cl in clusters:
            if cl["strength"] < self.c["sweep_min_strength"]:
                continue
            p = cl["price"]
            if p > last_close:                      # level above: stops of shorts / sell-side targets
                hi = float(recent["high"].max())
                if hi > p and pre < p and (hi - p) <= 2 * a:
                    cand = {"direction": -1, "level": p, "extreme": hi, "strength": cl["strength"]}
                else:
                    continue
            else:                                   # level below
                lo = float(recent["low"].min())
                if lo < p and pre > p and (p - lo) <= 2 * a:
                    cand = {"direction": 1, "level": p, "extreme": lo, "strength": cl["strength"]}
                else:
                    continue
            if best is None or cand["strength"] > best["strength"]:
                best = cand
        return best

    # ---------- agent ----------
    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        df = snap.candles[self.tf].tail(int(self.c["lookback"]))
        price = snap.price
        a = float(atr(snap.candles[self.tf]).iloc[-1])
        clusters = self._manual(price) or self.build_clusters(df, snap.oi, price)
        above = sorted([x for x in clusters if x["price"] > price], key=lambda x: x["price"])
        below = sorted([x for x in clusters if x["price"] <= price], key=lambda x: -x["price"])
        for x in above + below:
            x["side"] = "above" if x["price"] > price else "below"
            x["dist_pct"] = abs(x["price"] - price) / price * 100
        sweep = self._detect_sweep(df, clusters, a)

        w_above = sum(x["strength"] / (1 + x["dist_pct"]) for x in above)
        w_below = sum(x["strength"] / (1 + x["dist_pct"]) for x in below)
        magnet = (w_above - w_below) / (w_above + w_below + 1e-9)

        if sweep:
            bias = sweep["direction"] * min(1.0, 0.5 + 0.5 * sweep["strength"])
            conf = 0.4 + 0.6 * sweep["strength"]
            word = "above" if sweep["direction"] < 0 else "below"
            summary = (f"Liquidity sweep {word} {sweep['level']:.1f} (strength {sweep['strength']:.2f}) "
                       f"and price rejected back -> {'SHORT' if sweep['direction'] < 0 else 'LONG'} bias")
        else:
            bias = 0.6 * magnet
            top = max([x["strength"] for x in (above[:1] + below[:1])] or [0.0])
            conf = 0.25 + 0.5 * top
            na = f"{above[0]['price']:.1f}" if above else "-"
            nb = f"{below[0]['price']:.1f}" if below else "-"
            summary = f"No fresh sweep. Nearest clusters: above {na}, below {nb}. Magnet {magnet:+.2f}"
        src = "manual levels" if self._manual(price) else "modelled estimate"
        return AgentReport(self.name, clip(bias), clip(conf, 0, 1), summary + f" [{src}]",
                           {"clusters": above + below, "sweep": sweep, "magnet": magnet, "atr": a})
