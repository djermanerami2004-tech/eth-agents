"""Data agent: gets candles, open interest, funding and long/short ratio (live Binance or synthetic demo)."""
from __future__ import annotations

import time

import pandas as pd
import requests

from core.indicators import resample
from core.models import MarketSnapshot
from core.synthetic import make_5m

SPOT_MIRROR = "https://data-api.binance.vision"
KLINE_COLS = ["open_time", "open", "high", "low", "close", "volume", "close_time",
              "quote_vol", "trades", "taker_buy_base", "taker_buy_quote", "ignore"]


class DataAgent:
    name = "data"

    def __init__(self, cfg: dict, demo: bool = False, seed: int = 7, demo_end=None):
        self.cfg = cfg
        self.m = cfg["market"]
        self.demo = demo
        self.seed = seed
        self.demo_end = demo_end
        self.fallback_used: str | None = None

    # ---------- public ----------
    def snapshot(self, limit: int | None = None) -> MarketSnapshot:
        limit = limit or self.m["candles"]
        return self._demo(limit) if self.demo else self._live(limit)

    # ---------- live ----------
    def _get(self, path: str, params: dict, retries: int = 3, base: str | None = None):
        url = (base or self.m["exchange_url"]).rstrip("/") + path
        last = None
        for i in range(retries):
            try:
                r = requests.get(url, params=params, timeout=10)
                if r.status_code == 451:
                    raise RuntimeError("HTTP 451: Binance blocks this country/IP (try a VPN or another exchange_url)")
                r.raise_for_status()
                return r.json()
            except Exception as e:
                last = e
                time.sleep(0.6 * (i + 1))
        raise RuntimeError(f"Request failed for {url}: {last}")

    def _klines(self, interval: str, limit: int, symbol: str | None = None) -> pd.DataFrame:
        params = {"symbol": symbol or self.m["symbol"], "interval": interval, "limit": min(limit, 1000)}
        try:
            rows = self._get("/fapi/v1/klines", params)
        except RuntimeError as e:
            # public spot mirror: same candle format (incl. taker-buy volume), slightly different price than perp
            rows = self._get("/api/v3/klines", params, base=self.m.get("fallback_url", SPOT_MIRROR))
            self.fallback_used = f"spot mirror ({e})"
        df = pd.DataFrame(rows, columns=KLINE_COLS)
        df.index = pd.to_datetime(df["open_time"], unit="ms", utc=True)
        for c in ("open", "high", "low", "close", "volume", "taker_buy_base"):
            df[c] = df[c].astype(float)
        return df[["open", "high", "low", "close", "volume", "taker_buy_base"]]

    def _live(self, limit: int) -> MarketSnapshot:
        now = pd.Timestamp.now(tz="UTC")
        tfs = {self.m["entry_tf"], self.m["htf"], *self.m.get("extra_tfs", [])}
        candles = {tf: self._klines(tf, limit) for tf in tfs}

        ref = None
        if self.m.get("ref_symbol"):          # BTC candles for the correlation agent; the desk works without them
            try:
                ref = {tf: self._klines(tf, limit, self.m["ref_symbol"]) for tf in (self.m["entry_tf"], self.m["htf"])}
            except Exception:
                ref = None

        oi = funding = ls = mark = None
        try:
            rows = self._get("/futures/data/openInterestHist",
                             {"symbol": self.m["symbol"], "period": self.m["entry_tf"], "limit": min(limit, 500)})
            oi = pd.DataFrame({"oi": [float(r["sumOpenInterest"]) for r in rows]},
                              index=pd.to_datetime([r["timestamp"] for r in rows], unit="ms", utc=True))
        except Exception:
            pass
        try:
            p = self._get("/fapi/v1/premiumIndex", {"symbol": self.m["symbol"]})
            mark, funding = float(p["markPrice"]), float(p["lastFundingRate"])
        except Exception:
            pass
        try:
            r = self._get("/futures/data/globalLongShortAccountRatio",
                          {"symbol": self.m["symbol"], "period": self.m["entry_tf"], "limit": 1})
            ls = float(r[-1]["longShortRatio"])
        except Exception:
            pass

        book = None
        if (self.cfg.get("orderbook", {}) or {}).get("enabled", True) and not self.fallback_used:
            try:   # top 1000 levels each side: only the area close to price (a fraction of a percent for ETH)
                d = self._get("/fapi/v1/depth", {"symbol": self.m["symbol"], "limit": 1000}, retries=1)
                book = {"bids": [[float(p), float(q)] for p, q in d["bids"]],
                        "asks": [[float(p), float(q)] for p, q in d["asks"]]}
            except Exception:
                pass

        source = "binance-live" if not self.fallback_used else "binance-spot-fallback"
        snap = MarketSnapshot(self.m["symbol"], 0.0, candles, oi, funding, ls, source, now, book, ref)
        return snap.until(now, price=mark)

    # ---------- demo ----------
    def _demo(self, limit: int) -> MarketSnapshot:
        n5 = 36000  # fixed: the same seed always gives the same price path, whatever `limit` is
        df5, oi, funding, ls, end = make_5m(n=n5, seed=self.seed, end=self.demo_end)
        candles = {}
        for tf in {self.m["entry_tf"], self.m["htf"], *self.m.get("extra_tfs", [])}:
            from core.models import tf_minutes
            candles[tf] = resample(df5, tf_minutes(tf)).tail(limit)
        ref = None
        if self.m.get("ref_symbol"):
            from core.models import tf_minutes
            from core.synthetic import make_ref_5m
            b5 = make_ref_5m(df5, self.seed)
            ref = {tf: resample(b5, tf_minutes(tf)).tail(limit) for tf in (self.m["entry_tf"], self.m["htf"])}
        snap = MarketSnapshot(self.m["symbol"], float(df5["close"].iloc[-1]), candles, oi, funding, ls,
                              f"synthetic(seed={self.seed})", end, None, ref)
        return snap.until(end, price=float(df5["close"].iloc[-1]))
