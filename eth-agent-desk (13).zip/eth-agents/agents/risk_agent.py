"""Risk agent: has veto power. Sizes the trade and enforces daily/total loss, session, RR and stop rules."""
from __future__ import annotations

import math

import pandas as pd

from core.models import AgentReport, RiskState, TradePlan


class RiskAgent:
    name = "risk"

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.r = cfg["risk"]
        self.acct = cfg["account"]

    def _in_session(self, now: pd.Timestamp) -> bool:
        sessions = self.r.get("allowed_sessions_utc") or []
        if not sessions:
            return True
        h = now.hour + now.minute / 60
        return any(s <= h < e for s, e in sessions)

    def evaluate(self, plan: TradePlan, news: AgentReport | None, state: RiskState,
                 now: pd.Timestamp) -> TradePlan:
        r, size_usd = self.r, self.acct["size"]
        v: list[str] = []

        if news is not None and news.veto:
            v.append(news.summary)
        if not self._in_session(now):
            v.append(f"Outside allowed trading hours ({r['allowed_sessions_utc']} UTC)")

        max_daily = size_usd * r["max_daily_loss_pct"] / 100
        max_dd = size_usd * r["max_total_drawdown_pct"] / 100
        if state.daily_pnl <= -max_daily:
            v.append(f"Daily loss limit reached ({state.daily_pnl:.0f} USD)")
        if state.total_pnl <= -max_dd:
            v.append(f"Total drawdown limit reached ({state.total_pnl:.0f} USD)")
        if state.open_trades >= r.get("max_open_trades", 1):
            v.append(f"A trade or pending order is already active ({state.open_trades})")
        if state.trades_today >= r["max_trades_per_day"]:
            v.append(f"Max trades per day reached ({state.trades_today})")
        if state.loss_streak >= r["max_consecutive_losses"]:
            v.append(f"{state.loss_streak} losses in a row today - stop for the day")

        dist = abs(plan.entry - plan.stop)
        if dist <= 0 or plan.atr <= 0:
            v.append("Invalid stop distance")
        else:
            stop_atr = dist / plan.atr
            if stop_atr > r["max_stop_atr"]:
                v.append(f"Stop too wide ({stop_atr:.1f} ATR > {r['max_stop_atr']})")
            if stop_atr < r["min_stop_atr"]:
                v.append(f"Stop too tight ({stop_atr:.1f} ATR)")
        if plan.rr < r["min_rr"]:
            v.append(f"Reward/risk {plan.rr:.2f} below minimum {r['min_rr']}")

        full_risk = size_usd * r["risk_per_trade_pct"] / 100
        remaining = min(max_daily, max_daily + state.daily_pnl)  # daily budget left
        risk_usd = min(full_risk, remaining * 0.9)
        if risk_usd < 0.25 * full_risk:
            v.append("Not enough daily risk budget left")

        size = 0.0
        if dist > 0 and risk_usd > 0:
            raw = risk_usd / (dist * self.acct["contract_size"])
            step = self.acct["lot_step"]
            size = math.floor(raw / step + 1e-9) * step
            max_lev = self.acct.get("max_leverage")
            if max_lev and plan.entry > 0:
                cap = math.floor(size_usd * max_lev / (plan.entry * self.acct["contract_size"]) / step + 1e-9) * step
                if size > cap:
                    plan.reasons.append(f"Size capped by max leverage {max_lev}x ({size:.2f} -> {cap:.2f} lots)")
                    size = cap
            if size < step:
                v.append("Position size below minimum lot")
        plan.size = round(size, 4)
        plan.risk_usd = round(size * dist * self.acct["contract_size"], 2)
        if size >= self.acct["lot_step"] and plan.risk_usd < 0.25 * full_risk:
            v.append(f"Leverage cap leaves only ${plan.risk_usd:.0f} of the intended ${full_risk:.0f} risk - skip, stop is too tight")
        plan.vetoes = v
        plan.approved = not v and plan.side != "NONE"
        return plan
