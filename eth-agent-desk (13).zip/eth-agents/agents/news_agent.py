"""News agent: scheduled-event blackout windows + simple headline sentiment from public RSS feeds."""
from __future__ import annotations

import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime

import numpy as np
import pandas as pd
import requests

from agents.base import BaseAgent, clip
from core.models import AgentReport, MarketSnapshot

POS = ["etf inflow", "inflows", "rally", "surge", "bullish", "adoption", "upgrade", "record high",
       "approval", "approves", "breakout", "accumulat", "soars", "gains"]
NEG = ["hack", "exploit", "lawsuit", "sues", "ban", "crackdown", "outflows", "plunge", "crash",
       "bearish", "liquidat", "dump", "selloff", "sell-off", "slumps", "drops", "fraud", "delay"]
DANGER = ["hack", "exploit", "halt", "emergency", "bankrupt"]


class NewsAgent(BaseAgent):
    name = "news"

    def __init__(self, cfg: dict, offline: bool = False):
        super().__init__(cfg)
        self.n = cfg["news"]
        self.offline = offline
        self._cal: list[dict] = []
        self._cal_at: pd.Timestamp | None = None
        self.calendar_status = "disabled"

    # ---------- economic calendar -> automatic blackout windows ----------
    @staticmethod
    def parse_calendar(items: list, countries: list, impacts: list, before: int, after: int) -> list[dict]:
        """Turn the weekly calendar JSON (title, country, date, impact) into blackout entries."""
        out = []
        for it in items or []:
            try:
                if it.get("country") not in countries or it.get("impact") not in impacts:
                    continue
                t = pd.Timestamp(it["date"])
                t = t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")
                out.append({"time": t.isoformat(), "before_min": before, "after_min": after,
                            "label": f"{it.get('country')} {it.get('title', 'event')}"})
            except Exception:
                continue
        return out

    def _calendar(self, now: pd.Timestamp) -> list[dict]:
        c = self.n.get("calendar") or {}
        if not c.get("enabled") or self.offline:
            self.calendar_status = "disabled" if not c.get("enabled") else "skipped (offline/demo)"
            return []
        if self._cal_at is not None and now - self._cal_at < pd.Timedelta(hours=6):
            return self._cal
        try:
            r = requests.get(c["url"], timeout=8, headers={"User-Agent": "eth-agents/1.0"})
            r.raise_for_status()
            self._cal = self.parse_calendar(r.json(), c.get("countries", ["USD"]), c.get("impacts", ["High"]),
                                            c.get("before_min", 30), c.get("after_min", 60))
            self.calendar_status = f"ok ({len(self._cal)} events this week)"
        except Exception as e:
            self.calendar_status = f"UNAVAILABLE ({type(e).__name__}) - add blackouts by hand!"
        self._cal_at = now
        return self._cal

    def blackout(self, now: pd.Timestamp) -> str | None:
        for b in (self.n.get("blackouts") or []) + self._calendar(now):
            t = pd.Timestamp(b["time"])
            t = t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")
            if t - pd.Timedelta(minutes=b.get("before_min", 30)) <= now <= t + pd.Timedelta(minutes=b.get("after_min", 60)):
                return b.get("label", "scheduled event")
        return None

    def _headlines(self, now: pd.Timestamp) -> list[str]:
        out = []
        cutoff = now - pd.Timedelta(hours=self.n["lookback_hours"])
        for url in self.n.get("rss", []):
            try:
                r = requests.get(url, timeout=8, headers={"User-Agent": "eth-agents/1.0"})
                r.raise_for_status()
                for item in ET.fromstring(r.content).iter("item"):
                    title = (item.findtext("title") or "").strip()
                    try:
                        dt = pd.Timestamp(parsedate_to_datetime(item.findtext("pubDate")))
                        dt = dt.tz_localize("UTC") if dt.tzinfo is None else dt.tz_convert("UTC")
                    except Exception:
                        continue
                    if dt >= cutoff and title:
                        out.append(title)
            except Exception:
                continue
        return out

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        now = snap.ts
        label = self.blackout(now)
        if label:
            return AgentReport(self.name, 0.0, 1.0, f"BLACKOUT: {label} - no new trades", {"blackout": label}, veto=True)
        if self.offline:
            return AgentReport(self.name, 0.0, 0.0, "News feed skipped (demo/offline)", {"headlines": []})
        heads = self._headlines(now)
        if not heads:
            return AgentReport(self.name, 0.0, 0.0, f"No recent headlines fetched | calendar: {self.calendar_status}",
                               {"headlines": []})
        pos = sum(any(k in h.lower() for k in POS) for h in heads)
        neg = sum(any(k in h.lower() for k in NEG) for h in heads)
        danger = sum(any(k in h.lower() for k in DANGER) for h in heads)
        bias = float(np.tanh((pos - neg) / 6) * 0.6)
        summary = f"{len(heads)} headlines last {self.n['lookback_hours']}h: {pos} positive, {neg} negative"
        summary += f" | calendar: {self.calendar_status}"
        if danger >= 2:
            summary += f" | WARNING: {danger} headlines mention hack/halt-type events"
        return AgentReport(self.name, clip(bias), 0.35, summary, {"headlines": heads[:15], "danger": danger})
