"""Manager agent: asks every enabled strategy for a setup, checks each against the agents' weighted consensus and the
higher-timeframe trend, picks the best one, builds the plan (entry, stop, two targets) and asks the risk agent."""
from __future__ import annotations

import math
from types import SimpleNamespace

import pandas as pd

from agents.risk_agent import RiskAgent
from core.indicators import atr
from core.models import MarketSnapshot, RiskState, TradePlan
from strategies import build_strategies

AGREE_FACTOR = {3: 1.0, 2: 0.82, 1: 0.6, 0: 0.4}


class ManagerAgent:
    name = "manager"

    def __init__(self, cfg: dict, risk: RiskAgent):
        self.cfg = cfg
        self.m = cfg["manager"]
        self.w = cfg["weights"]
        self.risk = risk
        self.tf = cfg["market"]["entry_tf"]
        self.strategies = build_strategies(cfg)

    def _limits(self, name: str) -> tuple[float, int]:
        p = (self.cfg.get("strategies", {}) or {}).get(name, {}) or {}
        return float(p.get("min_score", self.m["min_score"])), int(p.get("min_agree", self.m["min_agree"]))

    def _levels(self, s, a: float, reports: dict) -> tuple[float, float, float, float]:
        """Stop, TP1, TP2 and RR for a setup. TP1 = nearest liquidity cluster between min-RR and 3R, else 2R;
        TP2 = next cluster beyond TP1 (up to 6R), else at least 3.5R and always beyond TP1."""
        d = s.side
        buf = self.m["atr_stop_buffer"] * a
        stop = s.stop_ref - buf if d == 1 else s.stop_ref + buf
        min_dist = self.cfg["risk"]["min_stop_atr"] * a
        stop = min(stop, s.entry - min_dist) if d == 1 else max(stop, s.entry + min_dist)
        R = abs(s.entry - stop)
        min_rr = self.cfg["risk"]["min_rr"]
        clusters = reports["liquidity"].details.get("clusters", []) if "liquidity" in reports else []
        dists = sorted({round((c["price"] - s.entry) * d, 6) for c in clusters if (c["price"] - s.entry) * d > 0})
        offset = 0.05 * a / R if R > 0 else 0.0   # stay a hair in front of the level (in R)
        near = [x / R for x in dists if min_rr * R <= x <= 3 * R] if R > 0 else []
        tp1_r = max((near[0] - offset) if near else 2.0, min_rr)
        far = [x / R for x in dists if tp1_r + 0.5 <= x / R <= 6] if R > 0 else []
        tp2_r = max((far[0] - offset) if far else max(3.5, tp1_r + 1.0), tp1_r + 0.25)
        tgt = getattr(s, "target", None)             # a pattern's measured move, used when it gives enough reward
        if tgt is not None and R > 0 and (tgt - s.entry) * d > 0:
            t_r = abs(tgt - s.entry) / R
            if min_rr <= t_r <= 3:
                tp1_r = t_r
                tp2_r = max(tp2_r, tp1_r + 0.5)
            elif t_r > 3:
                tp2_r = max(tp1_r + 0.25, min(t_r, 6.0))
        tp1, tp2 = s.entry + d * tp1_r * R, s.entry + d * tp2_r * R
        rr = round(abs(tp1 - s.entry) / R, 2) if R > 0 else 0.0
        return stop, tp1, tp2, rr

    def _record(self, s, strat, a: float, reports: dict) -> dict:
        stop, tp1, tp2, rr = self._levels(s, a, reports)
        return {"strategy": s.name, "agents": list(strat.agents), "side": "LONG" if s.side > 0 else "SHORT",
                "entry_type": s.entry_type, "entry": round(s.entry, 2), "stop": round(stop, 2), "tp1": round(tp1, 2),
                "tp2": round(tp2, 2), "rr": rr, "quality": round(s.quality, 2), "note": s.note,
                "status": "found", "reason": ""}

    def decide(self, snap: MarketSnapshot, reports: dict, state: RiskState, now: pd.Timestamp) -> TradePlan:
        price = snap.price
        df = snap.candles[self.tf]
        a = float(reports["liquidity"].details.get("atr") or 0) if "liquidity" in reports else 0.0
        if a <= 0:
            a = float(atr(df).iloc[-1])

        num = den = 0.0
        for name, r in reports.items():
            if r.details.get("no_data"):      # e.g. order book in a backtest: leave it out instead of diluting the score
                continue
            wt = self.w.get(name, 0.0)
            num += wt * r.bias * (0.5 + 0.5 * r.confidence)
            den += wt
        score = num / den if den else 0.0
        main = [reports[n] for n in ("liquidity", "structure", "orderflow") if n in reports]

        plan = TradePlan(ts=pd.Timestamp(now).isoformat(), price=price, atr=a, score=round(score, 3))
        lines = [f"{r.agent}: {r.bias:+.2f} - {r.summary}" for r in reports.values()]
        ctx = SimpleNamespace(price=price, atr=a, df=df, score=score)

        # ---- 1) every strategy proposes, 2) each proposal is checked ----
        fit_map = reports["regime"].details.get("fit", {}) if "regime" in reports else {}   # which strategies suit this market
        block = float((self.cfg.get("mtf") or {}).get("block_against", 0) or 0)
        mtf = reports.get("mtf")
        found, ok, rejected, records = [], [], [], []
        for strat in self.strategies:
            try:
                s = strat.detect(snap, reports, ctx)
            except Exception as e:  # one broken strategy must never stop the desk
                rejected.append(("error", f"{strat.name} failed: {e}"))
                continue
            if s is None:
                continue
            found.append(s)
            rec = self._record(s, strat, a, reports)
            fit = float(fit_map.get(s.name, 1.0))
            if fit != 1.0:
                rec["regime_fit"] = fit
            records.append(rec)
            min_score, min_agree = self._limits(s.name)
            s_dir = score * s.side
            agree = sum(1 for r in main if r.bias * s.side >= 0.1)
            if block > 0 and mtf is not None and mtf.details.get("htf_bias", 0.0) * s.side <= -block:
                rejected.append(("trend", f"{s.name} {'long' if s.side > 0 else 'short'} is against the higher-timeframe "
                                          f"trend (bias {mtf.details['htf_bias']:+.2f}; {mtf.summary})"))
                rec.update(status="rejected", reason=f"against the higher-timeframe trend (bias {mtf.details['htf_bias']:+.2f})")
            elif s_dir < min_score:
                rejected.append(("score", f"{s.name} setup found but composite score {score:+.2f} in its direction "
                                          f"is below {min_score}"))
                rec.update(status="rejected", reason=f"composite score {s_dir:+.2f} in its direction is below the {min_score} needed")
            elif agree < min_agree:
                rejected.append(("agree", f"{s.name} setup found but only {agree} of {len(main)} core agents agree"))
                rec.update(status="rejected", reason=f"only {agree} of {len(main)} core agents agree (needs {min_agree})")
            else:
                ok.append((s.quality * fit + 0.5 * s_dir, s, agree))
                rec.update(status="passed", reason="passed the score, agreement and trend checks"
                           + (f"; ranked x{fit:.2f} for the {reports['regime'].details['regime']} market" if fit != 1.0 else ""))
        plan.setups = records

        if not ok:
            if rejected:
                order = {"trend": 0, "score": 1, "agree": 2, "error": 3}
                rejected.sort(key=lambda x: order[x[0]])
                head = "No trade: " + rejected[0][1]
            else:
                head = (f"No trade: no strategy found a setup (composite score {score:+.2f}, "
                        f"watching {', '.join(s.name for s in self.strategies)})")
            plan.reasons = [head] + [f"also: {r[1]}" for r in rejected[1:]] + lines
            return plan

        _, setup, agree = max(ok, key=lambda x: x[0])
        for rec in records:
            if rec["strategy"] == setup.name:
                rec.update(status="selected", reason="chosen as the trade (best of the setups that passed)")
        d = setup.side
        plan.side = "LONG" if d == 1 else "SHORT"
        plan.strategy = setup.name
        plan.entry_type, plan.entry = setup.entry_type, setup.entry

        plan.stop, plan.tp1, plan.tp2, plan.rr = self._levels(setup, a, reports)

        conf = 0.5 + 0.30 * math.tanh(2.2 * abs(score)) * AGREE_FACTOR[min(agree, 3)] + 0.1 * (setup.quality - 0.5)
        news = reports.get("news")
        if news and news.bias * d < -0.15:
            conf -= 0.05
        plan.confidence = round(min(max(conf, 0.0), 0.8), 2)

        others = [s.name for s in found if s is not setup]
        plan.reasons = [f"{plan.side} {plan.entry_type.lower()} - {setup.name}: {setup.note}; score {score:+.2f}, "
                        f"{agree}/{len(main)} core agents agree"
                        + (f"; other setups seen: {', '.join(others)}" if others else "")] + lines
        return self.risk.evaluate(plan, news, state, pd.Timestamp(now))
