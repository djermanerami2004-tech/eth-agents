from __future__ import annotations

import math

from core.models import AgentReport, MarketSnapshot


def clip(x: float, lo: float = -1.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def sgn(x: float) -> int:
    return (x > 0) - (x < 0)


class BaseAgent:
    """Every analysis agent takes a MarketSnapshot and returns an AgentReport."""
    name = "base"

    def __init__(self, cfg: dict):
        self.cfg = cfg

    def analyze(self, snap: MarketSnapshot) -> AgentReport:  # pragma: no cover
        raise NotImplementedError

    def safe_analyze(self, snap: MarketSnapshot) -> AgentReport:
        try:
            r = self.analyze(snap)
            if math.isnan(r.bias):
                raise ValueError("bias is NaN")
            return r
        except Exception as e:  # one broken agent must never kill the desk
            return AgentReport(self.name, 0.0, 0.0, f"{self.name} agent failed: {e}", {"error": str(e)})
