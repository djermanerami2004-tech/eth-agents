"""Order-flow agent: delta/CVD, VWAP and CVD divergence (funding and positioning live in the derivatives agent)."""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent, clip, sgn
from core.indicators import candle_delta, session_vwap
from core.models import AgentReport, MarketSnapshot


class OrderFlowAgent(BaseAgent):
    name = "orderflow"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.tf = cfg["market"]["entry_tf"]

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        df = snap.candles[self.tf].tail(200)
        d = candle_delta(df)
        cvd = d.cumsum()
        win = 24
        vol_w = float(df["volume"].tail(win).sum()) + 1e-9
        cvd_slope = float(cvd.iloc[-1] - cvd.iloc[-win]) / vol_w
        imbalance = float(d.tail(6).sum()) / (float(df["volume"].tail(6).sum()) + 1e-9)
        vwap = session_vwap(df)
        above_vwap = sgn(snap.price - float(vwap.iloc[-1]))

        # divergence: price makes a new extreme versus the previous window but CVD does not confirm
        p_now, p_prev = df["close"].tail(30), df["close"].iloc[-60:-30]
        c_now, c_prev = cvd.tail(30), cvd.iloc[-60:-30]
        div = 0
        if len(p_prev) == 30:
            if p_now.max() > p_prev.max() and c_now.max() < c_prev.max():
                div = -1
            elif p_now.min() < p_prev.min() and c_now.min() > c_prev.min():
                div = 1

        bias = 0.40 * np.tanh(cvd_slope * 6) + 0.30 * np.tanh(imbalance * 8) + 0.15 * above_vwap + 0.15 * div

        bias = clip(float(bias))
        conf = clip(0.3 + 0.6 * abs(bias), 0, 1)
        summary = (f"CVD slope {cvd_slope:+.2f}, recent imbalance {imbalance:+.2f}, "
                   f"price {'above' if above_vwap > 0 else 'below'} VWAP"
                   + (", divergence " + ("bullish" if div > 0 else "bearish") if div else ""))
        return AgentReport(self.name, bias, conf, summary,
                           {"cvd_slope": cvd_slope, "imbalance": imbalance, "vwap": float(vwap.iloc[-1]),
                            "divergence": div, "cvd": cvd.tail(120).tolist()})
