"""Volume profile agent: where has the volume traded lately?

Candles only carry total volume, so each candle's volume is spread evenly across its high-low range (an approximation
of a tick-based profile). From that: POC (price with the most volume), the value area (70% of the volume: VAL..VAH)
and the high/low volume nodes. Rules:
  * inside the value area: price tends to rotate back to the POC, a small lean toward it, stronger near the edges;
  * just back inside after a stretch outside (the "80% rule" idea): a failed move, leans toward the POC;
  * accepted outside (3+ closes beyond VAH/VAL): the market moved to a new value, leans with it.
Works on candles only, so it is also used in backtests."""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent, clip
from core.indicators import atr
from core.models import AgentReport, MarketSnapshot


def profile(df, bins: int):
    lo, hi = float(df["low"].min()), float(df["high"].max())
    edges = np.linspace(lo, hi, bins + 1)
    l, h, v = df["low"].values[:, None], df["high"].values[:, None], df["volume"].values[:, None]
    over = np.clip(np.minimum(h, edges[None, 1:]) - np.maximum(l, edges[None, :-1]), 0, None)
    vol = (over / np.maximum(h - l, 1e-9) * v).sum(axis=0)
    return edges, vol


class VolumeProfileAgent(BaseAgent):
    name = "volume_profile"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.c = cfg.get("volume_profile", {}) or {}
        self.tf = cfg["market"]["entry_tf"]

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        df = snap.candles[self.tf].tail(int(self.c.get("lookback", 192)))
        if len(df) < 60 or float(df["volume"].sum()) <= 0:
            return AgentReport(self.name, 0.0, 0.0, "Not enough candles for a volume profile", {"no_data": True})
        a = float(atr(snap.candles[self.tf]).iloc[-1])
        rng = float(df["high"].max() - df["low"].min())
        bins = int(np.clip(rng / max(0.25 * a, 1e-9), 30, 120))
        edges, vol = profile(df, bins)
        mid = (edges[:-1] + edges[1:]) / 2
        poc_i = int(vol.argmax())
        total, lo_i, hi_i, got = vol.sum(), poc_i, poc_i, vol[poc_i]
        while got < 0.7 * total and (lo_i > 0 or hi_i < len(vol) - 1):
            down = vol[lo_i - 1] if lo_i > 0 else -1
            up = vol[hi_i + 1] if hi_i < len(vol) - 1 else -1
            if up >= down:
                hi_i += 1; got += vol[hi_i]
            else:
                lo_i -= 1; got += vol[lo_i]
        poc, val, vah = float(mid[poc_i]), float(edges[lo_i]), float(edges[hi_i + 1])
        avg = vol.mean()
        smooth = np.convolve(vol, np.ones(3) / 3, mode="same")
        hvn = [float(mid[i]) for i in range(1, len(vol) - 1) if smooth[i] > smooth[i - 1] and smooth[i] >= smooth[i + 1] and smooth[i] > 1.3 * avg]
        lvn = [float(mid[i]) for i in range(1, len(vol) - 1) if smooth[i] < smooth[i - 1] and smooth[i] <= smooth[i + 1] and smooth[i] < 0.6 * avg]
        price = snap.price
        closes = df["close"].values
        outside_up = (closes > vah)[::-1]
        outside_dn = (closes < val)[::-1]
        run_up = int(np.argmin(outside_up)) if not outside_up.all() else len(outside_up)     # consecutive closes above VAH
        run_dn = int(np.argmin(outside_dn)) if not outside_dn.all() else len(outside_dn)
        recent_out = bool((closes[-8:-1] > vah).any() or (closes[-8:-1] < val).any())
        half = max((vah - val) / 2, 1e-9)
        bias = conf = 0.0
        if val <= price <= vah:
            if recent_out and (closes[-8:-1] > vah).any() != (closes[-8:-1] < val).any():
                side = "above" if (closes[-8:-1] > vah).any() else "below"
                bias = (-1 if side == "above" else 1) * 0.45
                conf, where = 0.45, f"back inside the value area after trading {side} it, a failed move: leans toward the POC {poc:.1f}"
                state = "reentered"
            else:
                bias = clip((poc - price) / half) * 0.4
                conf, where = 0.2 + 0.2 * abs(price - poc) / half, f"inside the value area {val:.1f}-{vah:.1f} (POC {poc:.1f}): leans back toward the POC"
                state = "inside"
        elif run_up >= 3 or run_dn >= 3:
            d = 1 if run_up >= 3 else -1
            bias, conf = d * 0.3, 0.35
            where = f"accepted {'above' if d > 0 else 'below'} the value area ({max(run_up, run_dn)} closes): the market is moving to a new value, leans with it"
            state = "accepted_above" if d > 0 else "accepted_below"
        else:
            where = f"just outside the value area ({val:.1f}-{vah:.1f}), not accepted yet"
            state = "outside"
            conf = 0.0
        node = next((n for n in sorted(hvn + lvn, key=lambda n: abs(n - price)) if abs(n - price) > 0.2 * a), None)
        details = {"poc": poc, "vah": vah, "val": val, "state": state, "hvn": sorted(hvn, key=lambda n: abs(n - price))[:4],
                   "lvn": sorted(lvn, key=lambda n: abs(n - price))[:4], "bins": bins, "bars": len(df)}
        rep = AgentReport(self.name, float(bias), float(conf), f"Price {price:.1f} is {where}", details)
        if state == "outside":
            rep.details["no_data"] = True            # no opinion: stays out of the composite score
        return rep
