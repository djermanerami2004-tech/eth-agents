"""Multi-timeframe agent: trend on every configured timeframe, weighted (higher timeframes count more),
plus an alignment score (do the timeframes agree?). The manager uses `htf_bias` to block trades that fight the
higher-timeframe trend."""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent, clip
from core.indicators import ema, swings
from core.models import AgentReport, MarketSnapshot, tf_minutes

MIN_CANDLES = 60


class MultiTimeframeAgent(BaseAgent):
    name = "mtf"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        m = cfg.get("mtf", {}) or {}
        self.tfs = m.get("timeframes", [cfg["market"]["entry_tf"], cfg["market"]["htf"]])
        self.w = {str(k): float(v) for k, v in (m.get("weights") or {}).items()}
        self.htf_min = tf_minutes(cfg["market"]["htf"])

    @staticmethod
    def trend(df) -> dict:
        c = df["close"]
        e20, e50 = ema(c, 20), ema(c, 50)
        ema_s = 0.5 * float(np.sign(c.iloc[-1] - e50.iloc[-1])) + 0.5 * float(np.sign(e20.iloc[-1] - e50.iloc[-1]))
        sh, sl = swings(df.tail(300), 3, 3)
        hi, lo = sh.dropna(), sl.dropna()
        struct = 0.0
        if len(hi) >= 2 and len(lo) >= 2:
            hh, hl = hi.iloc[-1] > hi.iloc[-2], lo.iloc[-1] > lo.iloc[-2]
            struct = 1.0 if (hh and hl) else -1.0 if (not hh and not hl) else 0.0
        score = 0.6 * ema_s + 0.4 * struct
        label = "up" if score > 0.3 else "down" if score < -0.3 else "range"
        return {"score": float(score), "ema": ema_s, "structure": struct, "label": label}

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        per, skipped = {}, []
        for tf in self.tfs:
            df = snap.candles.get(tf)
            if df is None or len(df) < MIN_CANDLES:
                skipped.append(tf)
                continue
            per[tf] = self.trend(df) | {"weight": self.w.get(tf, 1.0)}
        if not per:
            return AgentReport(self.name, 0.0, 0.0, "No timeframe has enough candles", {"per_tf": {}, "htf_bias": 0.0})

        wsum = sum(v["weight"] for v in per.values())
        bias = clip(sum(v["weight"] * v["score"] for v in per.values()) / wsum)
        agree = sum(v["weight"] for v in per.values() if np.sign(v["score"]) == np.sign(bias) and v["score"] != 0) / wsum
        hi = {tf: v for tf, v in per.items() if tf_minutes(tf) >= self.htf_min}
        hw = sum(v["weight"] for v in hi.values())
        htf_bias = clip(sum(v["weight"] * v["score"] for v in hi.values()) / hw) if hw else 0.0

        conf = clip(0.25 + 0.45 * abs(bias) + 0.30 * agree, 0, 1)
        parts = ", ".join(f"{tf} {v['label']}" for tf, v in per.items())
        summary = f"{parts} | alignment {agree:.0%}, higher-TF bias {htf_bias:+.2f}"
        if skipped:
            summary += f" (not enough data: {', '.join(skipped)})"
        return AgentReport(self.name, bias, conf, summary,
                           {"per_tf": per, "alignment": float(agree), "htf_bias": float(htf_bias)})
