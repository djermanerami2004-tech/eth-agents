"""Derivatives agent: funding rate, open interest vs price, and long/short positioning.

Funding and positioning are read as CROWDING (contrarian at extremes). Open interest is read together with price:
  price up + OI up   = new longs, trend confirmed        price down + OI up   = new shorts, downtrend confirmed
  price up + OI down = short covering, weak rally        price down + OI down = long liquidation, selling exhausting
"""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent, clip
from core.models import AgentReport, MarketSnapshot


class DerivativesAgent(BaseAgent):
    name = "derivatives"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.tf = cfg["market"]["entry_tf"]

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        parts, notes, details = [], [], {}

        if snap.funding is not None:
            f = float(snap.funding)
            s = -float(np.tanh(f / 0.0005))                    # +0.05% per 8h is already crowded
            parts.append((0.40, s))
            details["funding"] = f
            tag = "crowded long" if f > 0.0003 else "crowded short" if f < -0.0003 else "neutral"
            notes.append(f"funding {f:.4%}/8h ({f * 3 * 365:.0%}/yr) {tag}")

        if snap.oi is not None and len(snap.oi) > 14:
            df = snap.candles[self.tf]
            n = 12
            oi = snap.oi["oi"].reindex(df.index, method="nearest")
            oi_chg = float(oi.iloc[-1] / oi.iloc[-n] - 1)
            px_chg = float(df["close"].iloc[-1] / df["close"].iloc[-n] - 1)
            d_oi = snap.oi["oi"].pct_change().dropna().tail(100)
            z = float((d_oi.iloc[-1] - d_oi.mean()) / (d_oi.std() + 1e-12)) if len(d_oi) > 20 else 0.0
            s = 0.0
            if abs(px_chg) > 0.002 and abs(oi_chg) > 0.003:
                up = px_chg > 0
                if oi_chg > 0:
                    s, label = (0.7 if up else -0.7), "new longs" if up else "new shorts"
                else:
                    s, label = (-0.25 if up else 0.25), "short covering (weak rally)" if up else "long liquidation (selling exhausting)"
                notes.append(f"OI {oi_chg:+.1%} with price {px_chg:+.1%}: {label}")
            else:
                notes.append(f"OI {oi_chg:+.1%}, price {px_chg:+.1%}: no clear signal")
            if z > 2.5:
                notes.append("OI spike: leverage building, sweeps more likely")
            parts.append((0.45, s))
            details.update(oi_change=oi_chg, price_change=px_chg, oi_spike_z=z)

        if snap.long_short_ratio is not None:
            r = float(snap.long_short_ratio)
            parts.append((0.15, -float(np.tanh((r - 1.0) * 1.5))))
            details["long_short_ratio"] = r
            notes.append(f"L/S ratio {r:.2f}" + (" long-heavy" if r > 1.8 else " short-heavy" if r < 0.7 else ""))

        if not parts:
            return AgentReport(self.name, 0.0, 0.0, "No derivatives data (funding / OI / positioning unavailable)", details)
        wsum = sum(w for w, _ in parts)
        bias = clip(sum(w * s for w, s in parts) / wsum)
        conf = clip((0.25 + 0.6 * abs(bias)) * (wsum / 1.0) ** 0.5, 0, 1)
        return AgentReport(self.name, bias, conf, "; ".join(notes), details)
