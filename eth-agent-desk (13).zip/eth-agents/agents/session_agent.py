"""Session agent: previous-day high/low and the Asia / London / New York session ranges (UTC).
These are the obvious stop-loss pools every trader sees; a wick through one that closes back inside is a sweep."""
from __future__ import annotations

import pandas as pd

from agents.base import BaseAgent, clip
from core.indicators import atr
from core.models import AgentReport, MarketSnapshot

LABEL = {"newyork": "New York"}
DEFAULT_SESSIONS = {"asia": [0, 7], "london": [7, 13], "newyork": [13, 21]}


class SessionAgent(BaseAgent):
    name = "session"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.c = cfg.get("session", {}) or {}
        self.tf = cfg["market"]["entry_tf"]
        self.sessions = self.c.get("sessions", DEFAULT_SESSIONS)
        self.sweep_lookback = int(self.c.get("sweep_lookback", 6))

    # ---------- levels ----------
    def levels(self, df: pd.DataFrame, now: pd.Timestamp) -> list[dict]:
        """Previous-day high/low plus the most recent COMPLETED range of each session."""
        out = []
        day = now.normalize()
        prev = df[(df.index >= day - pd.Timedelta(days=1)) & (df.index < day)]
        if len(prev):
            f = day.isoformat()
            out.append({"name": "PDH", "price": float(prev["high"].max()), "weight": 0.85, "formed": f})
            out.append({"name": "PDL", "price": float(prev["low"].min()), "weight": 0.85, "formed": f})
        for sname, (h0, h1) in self.sessions.items():
            for back in (0, 1):  # today's session if it already ended, otherwise yesterday's
                d = day - pd.Timedelta(days=back)
                start, end = d + pd.Timedelta(hours=h0), d + pd.Timedelta(hours=h1)
                if end > now:
                    continue
                rng = df[(df.index >= start) & (df.index < end)]
                if len(rng) >= 3:
                    out.append({"name": f"{LABEL.get(sname, sname.title())} high", "price": float(rng["high"].max()), "weight": 0.65, "formed": end.isoformat()})
                    out.append({"name": f"{LABEL.get(sname, sname.title())} low", "price": float(rng["low"].min()), "weight": 0.65, "formed": end.isoformat()})
                    break
        return out

    # ---------- sweep ----------
    def sweep(self, df: pd.DataFrame, levels: list[dict], a: float) -> dict | None:
        """Fresh sweep of an INTACT level: nothing traded beyond it since it formed, then within the last few candles
        a wick went through it by at least min_wick_atr * ATR and the price closed back on the original side."""
        sl = self.sweep_lookback
        if len(df) <= sl + 1:
            return None
        recent = df.tail(sl)
        window_start = recent.index[0]
        pre = float(df["close"].iloc[-sl - 1])
        last = float(df["close"].iloc[-1])
        min_wick = float(self.c.get("min_wick_atr", 0.1)) * a
        best = None
        for lv in levels:
            p = lv["price"]
            between = df[(df.index >= pd.Timestamp(lv["formed"])) & (df.index < window_start)]
            if p > last:                                   # level above: buy-stops
                hi = float(recent["high"].max())
                intact = between.empty or float(between["high"].max()) <= p
                if intact and hi - p >= min_wick and hi > p and pre < p and (hi - p) <= 2 * a:
                    cand = {"direction": -1, "level": p, "extreme": hi, "name": lv["name"], "weight": lv["weight"]}
                else:
                    continue
            else:
                lo = float(recent["low"].min())
                intact = between.empty or float(between["low"].min()) >= p
                if intact and p - lo >= min_wick and lo < p and pre > p and (p - lo) <= 2 * a:
                    cand = {"direction": 1, "level": p, "extreme": lo, "name": lv["name"], "weight": lv["weight"]}
                else:
                    continue
            if best is None or cand["weight"] > best["weight"]:
                best = cand
        return best

    def analyze(self, snap: MarketSnapshot) -> AgentReport:
        df = snap.candles[self.tf]
        now = snap.ts
        a = float(atr(df).iloc[-1])
        lv = self.levels(df, now)
        for x in lv:
            x["side"] = "above" if x["price"] > snap.price else "below"
            x["dist_pct"] = abs(x["price"] - snap.price) / snap.price * 100
        sw = self.sweep(df, lv, a)
        if sw:
            word = "above" if sw["direction"] < 0 else "below"
            bias = sw["direction"] * 0.7
            conf = 0.35 + 0.4 * sw["weight"]
            summary = (f"Swept {sw['name']} {word} at {sw['level']:.1f} and closed back -> "
                       f"{'SHORT' if sw['direction'] < 0 else 'LONG'} bias")
        else:
            bias, conf = 0.0, 0.2
            above = min((x for x in lv if x["side"] == "above"), key=lambda x: x["price"], default=None)
            below = max((x for x in lv if x["side"] == "below"), key=lambda x: x["price"], default=None)
            na = f"{above['name']} {above['price']:.1f}" if above else "-"
            nb = f"{below['name']} {below['price']:.1f}" if below else "-"
            summary = f"No session sweep. Nearest: above {na}, below {nb}"
        return AgentReport(self.name, clip(bias), clip(conf, 0, 1), summary,
                           {"levels": lv, "sweep": sw, "atr": a})
