#!/usr/bin/env bash
# One-time setup on Linux / macOS (Python 3.10+).
set -e
cd "$(dirname "$0")/.."
python3 -m venv .venv
. .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
python main.py check
echo "Next: .venv/bin/python main.py dashboard"
