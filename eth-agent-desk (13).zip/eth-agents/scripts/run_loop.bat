@echo off
REM Runs the desk every 5 minutes, tracks paper trades, sends Telegram alerts if enabled. Close the window to stop.
cd /d "%~dp0.."
call .venv\Scripts\activate
python main.py loop --every 300
pause
