@echo off
REM One-time setup on Windows. Needs Python 3.10+ from python.org (tick "Add Python to PATH").
cd /d "%~dp0.."
python -m venv .venv || goto :error
call .venv\Scripts\activate || goto :error
python -m pip install --upgrade pip
pip install -r requirements.txt || goto :error
if not exist .env copy .env.example .env
echo.
echo Setup finished. Testing your connection:
python main.py check
echo.
echo Next: double-click scripts\run_dashboard.bat
pause
exit /b 0
:error
echo Something failed - read the messages above.
pause
exit /b 1
