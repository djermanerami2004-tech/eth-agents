"""Exit 0 if the desk loop finished a cycle recently (used by the Docker health check; also handy by hand)."""
import sys
import time
from pathlib import Path

beat = Path(__file__).resolve().parent.parent / "data" / "heartbeat"
MAX_AGE = 1200      # seconds: the loop runs every 300s, so 4 missed cycles = unhealthy
try:
    age = time.time() - float(beat.read_text())
except Exception:
    print("no heartbeat yet")
    sys.exit(1)
print(f"last cycle {age:.0f}s ago")
sys.exit(0 if age < MAX_AGE else 1)
